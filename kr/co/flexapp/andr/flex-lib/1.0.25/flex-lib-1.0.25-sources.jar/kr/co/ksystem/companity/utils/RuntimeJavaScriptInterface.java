package kr.co.ksystem.companity.utils;

import android.util.Log;
import android.view.Gravity;
import android.webkit.JavascriptInterface;


public class RuntimeJavaScriptInterface {


    private RuntimeEventListener eventListener;
    private android.os.Handler handler = new android.os.Handler();

    public RuntimeJavaScriptInterface(RuntimeEventListener listener) {

        this.eventListener = listener;
    }


    public interface RuntimeEventListener {
        void onPostMessage(String msg);
        void canMoveBack(boolean moveBack);
        void download(String url, String fileName);
        void fileChunk(String b64, String filename, String offset, String contentLength, String uniqueID);
        void fileComplete(String uniqueID, String filename);
        void initSave(String saveID, String filename);
    }

    @JavascriptInterface
    public void postMessage(final String msg) {
        handler.post(new Runnable() {
            public void run() {
                eventListener.onPostMessage(msg);
            }
        });

    }

    @JavascriptInterface
    public void canMoveBack(final boolean moveBack) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                eventListener.canMoveBack(moveBack);
            }
        });
    }

    @JavascriptInterface
    public void initSave(String url, String fileName) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                eventListener.initSave(url, fileName);
            }
        });
    }

    @JavascriptInterface
    public void fileChunk(String b64, String filename, String offset, String contentLength, String uniqueID) {
        Log.e("fileChunk: ", contentLength + ": " + offset+ ": "+b64);
        handler.post(new Runnable() {
            @Override
            public void run() {
                eventListener.fileChunk(b64, filename, offset, contentLength, uniqueID);
            }
        });
    }
    @JavascriptInterface
    public void fileComplete(String uniqueID, String filename) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                eventListener.fileComplete(uniqueID, filename);
            }
        });
    }

    @JavascriptInterface
    public void download(String url, String fileName) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                eventListener.download(url, fileName);
            }
        });
    }


}
