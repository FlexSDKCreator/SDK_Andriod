package kr.co.ksystem.companity;

import android.content.Context;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Registry;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.bumptech.glide.module.AppGlideModule;

import java.io.InputStream;

import androidx.annotation.NonNull;
import kr.co.ksystem.companity.org.glideloader.ReEncodingGifResourceEncoder;
import kr.co.ksystem.companity.org.glideloader.YlwPhotoDto;
import kr.co.ksystem.companity.org.glideloader.YlwPhotoLoader;

//import com.bumptech.glide.integration.gifencoder.ReEncodingGifResourceEncoder;

/**
 * Created by Subhaye on 27-Jun-18.
 */

@GlideModule
public class YlwGlideModule extends AppGlideModule {
    @Override
    public void registerComponents(@NonNull Context context, @NonNull Glide glide, @NonNull Registry registry) {
        registry.append(YlwPhotoDto.class, InputStream.class,
                new YlwPhotoLoader.Factory());
        registry.prepend(GifDrawable.class, new ReEncodingGifResourceEncoder(context, glide.getBitmapPool()));
        super.registerComponents(context, glide, registry);
    }

    @Override
    public boolean isManifestParsingEnabled() {
        return false;
    }
}
