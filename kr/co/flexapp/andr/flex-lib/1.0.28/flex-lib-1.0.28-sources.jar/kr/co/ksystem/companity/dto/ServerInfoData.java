package kr.co.ksystem.companity.dto;

public class ServerInfoData {
    private String serverIP, dsn_bis, dsn_oper, username, companyname;
    private int userSeq, companySeq, companyInfoID = -1, serverSettingId = -1;

    public ServerInfoData() {

    }

    public ServerInfoData(String serverIP,String dsn_bis,String dsn_oper,String username,String companyname) {
    this.serverIP = serverIP;
    this.dsn_bis = dsn_bis;
    this.dsn_oper = dsn_oper;
    this.username = username;
    this.companyname = companyname;

    }

    public String getServerIP() {
        return serverIP;
    }

    public void setServerIP(String serverIP) {
        this.serverIP = serverIP;
    }

    public String getDsn_bis() {
        return dsn_bis;
    }

    public void setDsn_bis(String dsn_bis) {
        this.dsn_bis = dsn_bis;
    }

    public String getDsn_oper() {
        return dsn_oper;
    }

    public void setDsn_oper(String dsn_oper) {
        this.dsn_oper = dsn_oper;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }

    public int getUserSeq() {
        return userSeq;
    }

    public void setUserSeq(int userSeq) {
        this.userSeq = userSeq;
    }

    public int getCompanySeq() {
        return companySeq;
    }

    public void setCompanySeq(int companySeq) {
        this.companySeq = companySeq;
    }

    public int getCompanyInfoID() {
        return companyInfoID;
    }

    public void setCompanyInfoID(int companyInfoID) {
        this.companyInfoID = companyInfoID;
    }

    public int getServerSettingId() {
        return serverSettingId;
    }

    public void setServerSettingId(int serverSettingId) {
        this.serverSettingId = serverSettingId;
    }
}
