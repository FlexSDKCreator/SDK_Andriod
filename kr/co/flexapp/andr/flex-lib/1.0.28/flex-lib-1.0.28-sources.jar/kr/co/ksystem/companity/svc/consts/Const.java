package kr.co.ksystem.companity.svc.consts;

import android.graphics.Color;

public class Const {

	// SharedPref
	public static final String PGM_METHOD_SEQ = "PgmMethodSeq";
	public static final String EXECUTE_SEQ = "ExecuteSeq";
	public static final String EVENT_SEQ = "EventSeq";
	// 16.06.03 dpjang
	public static final String PARSING_VERSION = "parsingVersion";
	// 16.07.26 dpjang
	public static final String IS_SEARCH_BLOCK = "IsSearchBlock";

	// 16.09.05 dpjang
	public static final String IS_USE_PATTERN = "IsUsePattern";

	// 17.01.23 dpjang
	public static final String IS_USE_PGM_SETTING_BLOCK = "IsUserPgmSettingBlock";


	// 17.09.28 skyung.kim
	public static final String BEACON_UPDATETIME_COLUMN = "BeaconUpdateTime";


	// 16.07.27 dpjang form info version
	public static final String SERVER_FROMINFO_VERSION = "ServerFormInfoVersion";
	public static final String CLIENT_FROMINFO_VERSION = "ClientFormInfoVersion";

	// 17.03.07 dpjang
	public static final String IS_CURR_FRM_DIALOG = "isCurrentFormDialog";

	// 17.10.24 dpjang
	public static final String IS_USE_COMPANITY = "IsUseCompanity";
	public static final String IS_USE_BOARD = "IsUseBoard";
	public static final String IS_USE_ORGCHART = "IsUseOrgChart";
	public static final String IS_USE_ATTENDANCE = "IsUseAttendance";

	/*
	*serverDllVersion = 1 : added password authentication so user can register pattern in lockscreen.
 	* serverDllVersion = 2 : added companity,added bio
 	* */

    // 17.09.20 skyung.kim
    public static final String SERVER_DLL_VERSION = "ServerDllVersion";
    public static final String IS_USE_PWDCHANGE = "IsUsePwdChange";

    //17.09.22 skyung.kim
    public static final String PWD_VALID_DAY = "PwdValidDay";
    public static final String USER_PWD_CHG_DATE = "UserPwdChgDate";
	public static final String PWD_INFO_DAY = "PwdInfoDay";
	public static final String _SCAGetLogin1 = "_SCAGetLogin1";

	// 17.11.15 dpjang
	public static final String USER_LIMIT_DATE = "UserlimitDate";

	// 17.12.01 dpjang
	public static final String FB_SESSION_TBL = "_FireBaseSession";
	public static final String FB_SESSION_COLUMN = "key";
	public static final String FB_SESSION_PREF = "FireBaseSession_KEY";

	// 17.12.14 dpjang
	public static final String FILE_SERVICE_URL = "FileServiceUrl";
	// 18.10.17 skyung.kim
	public static final String NOTI_SERVICE_URL = "NotiServiceUrl";
	// 18.03.16 dpjang
	public static final String GROUPWARE_SERVICE_URL = "GroupWareUrl";

	// 18.10.22 skyung.kim
	public static final String FIRST_VISIBLE_PGMSEQ = "FirstVisiblePgmSeq";

	// 18.05.31 dpjang
	public static final String PRODUCT_TYPE = "ProductType";

	// 18.02.20 dpjang
	/**
	 * <pre>
	 * 1112002 : ESS USER
	 * </pre>
	 */
	public static final String LICENSE_TYPE = "LicenseType";

	// 18.04.24 dpjang pref save isEssUser check
	public static final String IS_ESS_USER = "IsESSUser";
	// User execute ess Login
	public static final String ESS_STATUS = "ExecuteEssUserStatus";

	// 18.03.09 dpjang GroupWare
	public static final String GW_APP = "GWApp";
	public static final String GW_VIEW = "GWView";

	/**
	 * <pre>
	 * PATH : Util.writeFile() 
	 * true : save log, \n but false or else string : not save
	 * </pre>
	 */
	public static final String SAVE_SERVICE_LOG = "save_service_log";

	/**
	 * Setting
	 */
	public static final String CODEHELP_PAGE_COUNT = "CodehlepPageCount";

	/**
	 * MethodWebSvc. KWF&SQLWF LimitDataBlock
	 */
	public static final String LIMIT_DATABLOCK_LENGTH = "LimitDataBlock_Length";

	/**
	 * Used Table column and webservice param name KEY_DSN, KEY_USERSEQ,
	 * KEY_LANGUAGESEQ, KEY_SERVERIP, KEY_PGMSEQ
	 */
	// 14.10.24 Writer : dpjang webservice param name
	// public static final String KEY_DSN = "key_DSN";
	// public static final String KEY_USERSEQ = "key_UserSeq";
	// public static final String KEY_LANGUAGESEQ = "key_LanguageSeq";
	// public static final String KEY_SERVERIP = "key_ServerIP";
	// public static final String KEY_PGMSEQ = "key_PgmSeq";
	public static final String KEY_DSN = "key_DSN";
	public static final String KEY_USERSEQ = "key_UserSeq";
	public static final String KEY_LANGUAGESEQ = "key_LanguageSeq";
	public static final String KEY_SERVERIP = "key_ServerIP";
	public static final String KEY_PGMSEQ = "key_PgmSeq";

	public static final String URL = "Url";
	public static final String SOAP_ACTION = "soap_Action";

	// / end

	// 17.12.04 dpjang - ControlKey INFO
	public static final String CONTROL_KEY_ISC = "ISC";
	public static final String CONTROL_KEY_NOS = "NOS";
	public static final String CONTROL_KEY_NOQ = "NOQ";
	public static final String CONTROL_KEY_ICH = "ICH";
	public static final String CONTROL_KEY_CLC = "CLC";
	public static final String CONTROL_KEY_MCS = "MCS";
	public static final String CONTROL_KEY_NON = "NON";


	// 14.12.23 Writer : dpjang login info lastdatetime
	public static final String LOGIN_INFO_LASTDATETIME = "login_info_lastdatetime";
	public static final String LOGIN_DSN_OPER_VALUE = "login_dsnOper";
	public static final String LOGIN_DSN_BIS_VALUE = "login_dsnBis";
	
	//16.04.15 dpjang
	public static final String CONN_INFO_POSITION = "conn_info_position";

	public static final String LOGIN_LANGUAGE = "login_language";
	public static final String LOGIN_SERVER = "login_server";
	public static final String LOGIN_ID = "login_id";
	// public static final String LOGIN_PW = "login_pw";
	public static final String LOGIN_ISAUTO = "isAutoLogin";
	// 15.07.07 dpjang company selected
	public static final String LOGIN_COMPANYSEQ_IDX = "login_company_idx";

	public static final String LOGIN_COMPANYNAME = "login_companyname";
	public static final String LOGIN_COMPANYSEQ = "login_companyseq";
	public static final String SERVICE_QUERYEXECUTE = "QueryExecuteMobileApp";
	public static final String SERVICE_EXECUTESQLCOMMAND = "ExecuteSqlCommandMobileApp";
	public static final String SERVICE_GETFORMINFO = "GetFormInfoMobileApp";
	public static final String SERVICE_GETFORMINFO_SCHEMA = "GetFormInfoSchemaMobileApp";
	public static final String SERVICE_GETCERTLOGIN = "GetCertLoginMobileApp";
	public static final String SERVICE_GETLOGIN = "GetLoginMobileApp";

	//17.11.24 dpjang
	public static final String SERVICE_GETLOGINWITHFIREBASE = "GetLoginWithFbMobileApp";
	public static final String SERVICE_GETCERTLOGINWITHFIREBASE = "GetCertLoginWithFbMobileApp";

	public static final String SERVICE_SQLWF = "ExecuteMethodSQLWFMobileApp";
	public static final String SERVICE_KWF = "ExecuteMethodKWFMobileApp";
	// public static final String SERVICE_GETCODEHELP = "GetCodeHelp";
	public static final String SERVICE_GETCODEHELPFORMQUERYTITLE = "GetCodeHelpFormQueryTitleMobileApp";
	public static final String SERVICE_GETCODEHELPFORMQUERY = "GetCodeHelpFormQueryMobileApp";
	public static final String SERVICE_GETCODEHELPQUERY = "GetCodeHelpQueryMobileApp";
	public static final String SERVICE_LOGININFOANDMESSAGE = "LoginInfoAndMessageMobileApp";
	public static final String SERVICE_GETMAINMODULE = "GetMainModuleMobileApp";
	public static final String SERVICE_EXECUTEMETHODOPTION = "ExecuteMethodOptionMobileApp";

	// 17.07.17 dpjang
	public static final String SERVICE_EXECUTESENDMESSAGE = "ExecuteSendMessage";

	//16.05.03 dpjang - json service
	public static final String SERVICE_LOGININFOANDMESSAGE_JSON = "LoginInfoAndMessageMobileApp_json";
	public static final String SERVICE_SQLWF_JSON = "ExecuteMethodSQLWFMobileApp_json";
	public static final String SERVICE_KWF_JSON = "ExecuteMethodKWFMobileApp_json";
	public static final String SERVICE_QUERYEXECUTE_JSON = "QueryExecuteMobileApp_json";
	// 16.06.21 dpjang - json form info
	public static final String SERVICE_GETFORMINFO_JSON = "GetFormInfoMobileApp_json";

	// 17.09.05 dpjang
	public static final String SERVICE_EXECUTESQLCOMMAND_DBTYPE = "ExecuteSqlCommandDBTypeMobileApp";
	public static final String SERVICE_EXECUTESQLCOMMAND_DBTYPE_JSON = "ExecuteSqlCommandDBTypeMobileApp_json";
	public static final String SERVICE_EXECUTE_CHANGE_PASSWORD = "ExecuteChangePassWordMobileApp";
	public static final String SERVICE_EXECUTE_CHANGE_PASSWORD_JSON = "ExecuteChangePassWordMobileApp_json";
	// 18.01.23 dpjang
	public static final String SERVICE_EXECUTE_CHECKPASSWORD = "ExecuteCheckPassWordMobileApp";
	public static final String SERVICE_EXECUTE_CHECKPASSWORD_JSON = "ExecuteCheckPassWordMobileApp_json";

	// 18.07.23 dpjnag
	public static final String SERVICE_EXECUTE_DS = "ExecuteDsMobileApp";
	public static final String SERVICE_EXECUTE_DS_JSON = "ExecuteDsMobileApp_json";

	public static final String JSON_SEPARATOR = "<!--JSON--!>";
	public static final String SCHEMA_SEPARATOR = "<!--SPLIT--!>";
	
	
	// /** mServerIP : http://wbs.ksystem.co.kr:8888 */
	// public static final String SERVERIP_VALUE =
	// "http://wbs.ksystem.co.kr:8888";
	/** mURL : http://wbs.ksystem.co.kr:8888/AppBaseFramework.svc */
	public static final String FRAMEWORK_URL_VALUE = "/AppBaseFramework.svc";
	/** mServerIP : http://tempuri.org/IAppBaseFramework/ */
	public static final String FRAMEWORK_SOAPACTION_VALUE = "http://tempuri.org/IAppBaseFramework/";
	/** mURL : http://wbs.ksystem.co.kr:8888/AppBaseService.svc */
	public static final String METHODSVR_URL_VALUE = "/AppBaseService.svc";
	/** mServerIP : http://tempuri.org/IAppBaseService/ */
	public static final String METHODSVR_SOAPACTION_VALUE = "http://tempuri.org/IAppBaseService/";

	// 17.12.14 dpjang file server
	public static final String FILESERVICE_UPLOAD_URL_VALUE = "upload";
	public static final String FILESERVICE_UPLOAD_PROFILE_URL_VALUE = "uploadWithOverwrite";
	public static final String FILESERVICE_DOWNLOAD_URL_VALUE = "download";
	public static final String FILESERVICE_DOWNLOAD_PROFILE_URL_VALUE = "downloadWithInfo";
	public static final String FILESERVICE_DELETE_URL_VALUE = "delete";

	public static final String FILESERVICE_ORG_PROFILE_UPLOAD_PATH = "\\\\Org\\\\Profile\\\\";
	public static final String FILESERVICE_ORG_THUMB_UPLOAD_PATH = "\\\\Org\\\\Thumbnail\\\\";
	public static final String FILESERVICE_ORG_BACKGROUND_UPLOAD_PATH = "\\\\Org\\\\Background\\\\";
	// 16.10.20 dpjang ERROR REPORT - YLW GEN
	public static final String BUG_REPORT_SERVERIP_VALUE = "http://ylwout.ksystem.co.kr:8585/KSystemSvc/";
	public static final String BUG_REPORT_CONN_INFO = "ylwgn_bis" + "|" + 1 + "|"
			+ 0 + "|" + 1 + "|" + 0 + "|" + 0 + "|"
			+ "mobile : android_crashreport" + "||ylwgn_bis" + "|" + ""
			+ "/" + 0 + "/" + 0 + "/" + 0 + "/" + 0 + "/" + 0 + "/" + 0
			+ "/" + 0 + "/" + 0 + "/" + "ylwgn_oper" + "/" + "" + "/" + "" + "/"
			+ "" + "/" + "" + "/" + "" + "/";

	// 15.12.14 dpjang ERROR SCRIPT REPORT - WBS
	public static final String CRASH_SCRIPT_SERVERIP_VALUE = "http://wbs.ksystem.co.kr:8889";
	public static final String CRASH_SCRIPT_CONN_INFO = "wbs_bis" + "|" + 1 + "|"
			+ 50345 + "|" + 1 + "|" + 0 + "|" + 0 + "|"
			+ "mobile : android_crashreport" + "|dpjang|wbs_bis" + "|" + ""
			+ "/" + 1293 + "/" + 0 + "/" + 2041 + "/" + 0 + "/" + 0 + "/" + 0
			+ "/" + 0 + "/" + 0 + "/" + "wbs_oper" + "/" + "" + "/" + "" + "/"
			+ "" + "/" + "" + "/" + "" + "/";

	// String connInfo = "wbs_bis" + "|" + 1 + "|" + 50345 + "|" + 1 + "|" + 0
	// + "|" + 0 + "|" + 0 + "|dpjang|wbs_bis";
	// connInfo += "|" + "" + "/" + 1293 + "/" + 0 + "/" + 2041 + "/" + 0
	// + "/" + 0 + "/" + 0 + "/" + 0 + "/" + 0 + "/" + "wbs_oper"
	// + "/";
	// connInfo += "" + "/" + "" + "/" + "" + "/" + "" + "/" + "" + "/";
	public static final String CRASHSCRIPT_ENTER = "#_enter_#";
	
	/**
	 * login dataset. saved BaseFormClass.java
	 */
	public static final String BEGINNING_INFO = "BeginningInfo";
	public static final String BASE_FORM = "baseformclass_";

	/**
	 * CommonSvcCaller_QueryExecute SP name
	 */
	public static final String PGM_SEARCH_SP = "_SCARecentPgmQuery";
	public static final String DICTIONAY_MSG_SP = "_SCAGetDictionary";
	public static final String PGM_JUMP_SP = "_SCAGetPageJumpQuery";

	public static final String ACTION_SECU_SP = "_SCAGetActionSecuCheck";
	
	public static final String GET_PAGE_CODE_SECU_SP = "_SCAGetPageCodeSecu";

	// user�� message ���
	public static final String SHARE_QUERY_SP = "_SCAMobileMsgQuery";
	public static final String SHARE_SAVE_SP = "_SCAMobileMsgSave";

	// devtool ���� ���
	public static final String MOBILE_DEVPGM_SP = "_SDVDevToolAppQuery";

	// GetDictionary
	public static final String DICTIONARY_SP = "_SCAGetDictionary";

	// change pattern password
	public static final String CHANGE_PATTERN_PW_SP = "_SCAMobileAppChangePatternPW";
	// change pattern password
	public static final String CHANGE_LOGOUT_ISAUTO_SP = "_SCAMobileAppChangeLogOutIsAuto";

	//
	public static final String CONFIRM_PROC_SP = "_SWCOMConfirmProc";
	//
	public static final String STOP_PROC_SP = "_SWCOMStopProc";

	// 15.12.01 common svc
	public static final String GETPGMSEQ_BYPGMID = "_SCAMobileGetPgmSeq";

	/**
	 * CrashReportSvcCaller_QueryExecute SP name
	 */
	// 15.12.11 dpjang
	public static final String SAVE_SCRIPT_ERR_SP = "_SCASaveMobileAppScriptErrReport";

	// 16.10.20 dpjang - ONLY YLW Gen SERVER
	public static final String BUG_LIST_ACCESS_AUTH_CHECK_SP = "_SCAMobileBugListAccessAuthCheck";
	public static final String BUG_REPORT_QUERY_SP = "_SCAMobileBugReportQuery";
	public static final String BUG_REPORT_SAVE_SP = "_SCAMobileBugReportSave";
	public static final String BUG_RESPONSE_RESULT_SAVE_SP = "_SCAMobileBugResponseSave";
	// 16.10.20 dpjang - client server
	public static final String BUG_REPORT_QUERY_CLIENT_SP = "_SCAMobileBugReportQuery_Client";
	public static final String BUG_REPORT_SAVE_CLIENT_SP = "_SCAMobileBugReportSave_Client";
	public static final String BUG_RESPONSE_RESULT_SAVE_CLIENT_SP = "_SCAMobileBugResponseSave_Client";


	// 16.05.24 dpjang
	public static final String  GET_DIRECT_TABLE_SP = "_SCACustomSP_MobileApp";
	public static final String  GET_DEMO_SCENARIO_SP = "_SCAMobileDemoScenario";
	public static final String  GET_DEMO_MENULIST_SP = "_SCAMobileDemoMenuList";

	// 16.06.16 dpjang
	public static final String  GET_DEMO_HELP_SP = "_SCAMobileDemoPgmHelp_MobileApp";

	// 16.07.19 dpjang
	public static final String  GET_DEMO_SAVE_REVIEW_SP = "_SCAMobileDemoReviewResultSave";

	// 16.08.09 dpjang
	public static final String  GET_DEMO_FEATURE_LIST_SP = "_SCAMobileDemoMovieListQuery";

	// 16.09.19 dpjang
	public static final String  USER_CONFIG_PGM_SAVE = "_SCAUserConfigPgmSave_MobileApp";

	// 16.12.12 dpjang - demo TFT test version
	public static final String  GET_DEMO_SCENARIO_TEST_SP = "_SCAMobileDemoScenario_test";
	public static final String  GET_DEMO_MENULIST_TEST_SP = "_SCAMobileDemoMenuList_test";
	public static final String  GET_DEMO_FEATURE_LIST_TEST_SP = "_SCAMobileDemoMovieListQuery_test";

	// 17.03.07 dpjang
	public static final String GET_MOBILE_SECU_POLICY_SP = "_SCAMobileSecurityPolicyByUser";

	// 17.09.18 dpjang
	public static final String GET_BEACON_LIST_SP = "_SCAMobileBeaconList";


	//17.11.20 skyung.kim
	public static final String COMPANITY_SERVER_ID = "ServerID";
	public static final String COMPANITY_USERS = "Users";
	public static final String COMPANITY_TOKENS = "Tokens";
	public static final String COMPANITY_USERNAME = "userName";
	public static final String COMPANITY_PHONENO = "phoneNo";
	public static final String COMPANITY_USERPHOTO = "userPhoto";
	public static final String COMPANITY_EMAIL = "email";
	public static final String DEVICE_TOKEN = "DeviceToken";
	public static final String EMPINFO_LASTDATETIME = "EmpInfo_LastDateTime";
	public static final String COMPANITY_USERID = "userId";
	public static final String COMPANITY_USERSEQ = "userSeq";
	public static final String COMPANITY_STORAGE_PHOTO = "Photo";
	public static final String COMPANITY_STORAGE_THUMBNAIL = "Thumbnail";
	//17.12.01 skyung.kim
	public static final String COMPANITY_USERTODEVICE = "UserToDevice";
	public static final String SAVE_TOKEN_SP = "_SCAMobileDeviceTokenSave";
	public static final String GET_COMPANITY_USERINFO_SP = "_SCAMobileUserInfoQuery";
	//18.01.23 skyung.kim
	public static final String IS_USE_FB_AUTH = "IsUseFBAuth";
	public static final String SAVE_FBID_SP = "_SCAMobileSaveUserFbId";
	public static final String USER_FB_ID = "UserFBId";
	//18.02.08 skyung.kim
	public static final String QUERY_FB_ACCOUNT_SP ="_SCAMobileUserFbAccountSaveAndQuery";


	// LoginType
	public static final String PASSWORDLOGIN_TYPE = "1";
	public static final String AUTOLOGIN_TYPE = "2";
	public static final String PATTERNLOGIN_TYPE = "3";

	public static final String ZIP_KEY = "CAM+T/w4u+rB9ic3A2Ae";

	public static final String UTF_8 = "UTF-8";

	// 15.11.27 dpjang Login Mobile DEMO SITE
	public static final String IS_DEMO = "is_mobiledemo";
	public static final String DEMO_URL = "demo_url";

	public static final String DEMOSITE = "erp1demo";
	public static final String DEMOSITE_ID = "master";
	public static final String DEMOSITE_PW = "mobile";

	public static final String AUTO_SERVERSETTING_TAG = "MobileERPSetting://";

	// 15.12.11 dpjang baseType
	public static final int TYPE_BASE_SERVICE = 1;
	public static final int TYPE_BASE_FRAMEWORK = 2;
	// dpjang - WBS
	public static final int TYPE_BASE_CRASH_SCRIPT_REPORT = 3;
	// 16.10.04 dpjang YLW_GEN
	public static final int TYPE_BASE_CRASH_USER_REPORT = 4;

	public final String DatService = "130001"; // Data Service
	public final String BisService = "130002"; // Bis Service

	public static final String LOGIN_SUCCESS = "success";
	public static final String LOGIN_FAILURE = "failure";
	public static final String LOGIN_EXPIRED = "expired";
	// 17.11.15 dpjang
	public static final String LOGIN_TEMP_PW = "changePassWord";

    // 17.11.15 dpjang
	public static final String PW_SUCCESS = "success";
	public static final String PW_FAILURE = "failure";
	public static final String PW_TEMP_USER = "18002";
	public static final String PW_CHANGE_USER = "18003";
	public static final String PW_INVALID_USER = "18004";
    public static final String PW_RETIRED_USER = "18004";



    public static final String FORMLOAD_FAILURE = "failure";

	// 16.08.16 skkim demoTFT Activity
	public static final String TEMP_LOGIN_DSN_OPER_VALUE = "temp_login_dsnOper";
	public static final String TEMP_LOGIN_DSN_BIS_VALUE = "temp_login_dsnBis";
	public static final String TEMP_LOGIN_LANGUAGE = "temp_login_language";
	public static final String TEMP_LOGIN_SERVER = "temp_login_server";
	public static final String TEMP_LOGIN_COMPANYSEQ_IDX = "temp_login_company_idx";
	public static final String DIRECT_DEMO = "DIRECTDEMO";
	public static final String ACCESS_LOGIN = "ACCESSLOGIN";

	// 16.12.12 dpjang go to test version
	public static final String IS_TFTDEMO_TEST = "isTftDemoTest";

	//17.11.28 file service sp name dpjang
	public static final String ATTACHFILE_SAVE = "_SCAAttachFileSave";
	public static final String ATTACHFILE_CONST_QUERY = "_SCAAttachFileConstQuery";
	public static final String ATTACHFILE_DOWNHISTORY_SAVE = "_SCAAttachFileDownHistorySave";
	public static final String ATTACHFILE_QUERY = "_SCAAttachFileQuery";


	// 17.12.27 dpjang
	public  static final String DEVICE_TYPE_PHONE ="PHONE";
	public  static final String DEVICE_TYPE_PDA ="PDA";

	public  static final String DEVICE_PDA_PM80 ="PM80";
	public  static final String DEVICE_PDA_M3SM ="M3SM10_LTE";
	public  static final String DEVICE_PDA_CW50A ="CW50A";


	// ##########################################################################
	// ##########################################################################
	// ##########################################################################
	// ############################## Gen CODE #################################
	// ##########################################################################
	// ##########################################################################
	// ##########################################################################

	public final String ImgUri = "pack://application:,,,/AngKor.Ylw.DevStudio.DevUtil;component/Images/";

	public static int SSReadOnlyColor = Color.WHITE; // ��Ʈ- �б� ���Į��
	public final int SSHeader = 0;

	public final String NotUseChrBefore = "`!";
	public final String NotUseChrAfter = "&!^;";

	public static final String DATASCHEMACHAR = "`^"; // ��Ű���� ����Ÿ ������
	public static final String DATASQLTEXTCHAR = "`~"; // ���� SQL������ �ٿ��ش�.
	public static final String DATACOLCHAR = "`!"; // �÷� ������
	public static final String DATAROWCHAR = "`@"; // �ο� ������
	public static final String DATATABLECHAR = "`#"; // ���̺� ������

	public final String DATASP = "/"; // ������ ���ڿ��� ������
	public final String DATASPSUB = ","; // ������ ���ڿ��� ���� ������

	public final char DATATYPEString = '0'; // ����Ÿ type
	public final char DATATYPEINTEGER = '1'; // ����Ÿ type

	public static final String DATADBEXEERR = "ERR"; // Sp �Ķ��Ÿ ������
	public final String DATASPPARAMS = "~,"; // Sp �Ķ��Ÿ ������
	public static final String DATASKIPVALUE = "DATASKIPVALUE"; // linq����
																// ���Ҷ�
																// ���� ������
	// ǥ���ϴ� ���

	public final String DATAORGID = "_"; // ProControlSeq���� Org Key�� �����ϴ�
											// ������
	public final String DATAORGType = "-"; // ProControlSeq���� Item Type��
											// �����ϴ�
											// ������
	public final String DATASEPERATER = "_"; // �ܼ� �����ڷ� ���� ���

	// Url Request ������
	public final char URLCHARAND = '&'; // Url Request ������
	public final char URLCHAREQUAL = '='; // Url Request ������

	public final String TmTableKey = "_WT";
	public final String TmSaveType_SaveAndSchema = "1";
	public final String TmSaveType_SaveAndControl = "2";
	public final String TmSaveType_SaveAndSchemaCntl = "3";

	// ���ø� ������ �ε���
	public final int WP_None = -1;
	public final int WP_Template = 0;
	public final int WP_TemplateBase = 1;
	public final int WP_TemplateItem = 2;
	public final int WP_DesignerGrid = 3;

	public final char PARAMSP = '|'; // Property Params ������

	public static final String WT_ADD = "A"; // WorkingTag : Add
	public static final String WT_UPT = "U"; // WorkingTag : Update
	public static final String WT_DEL = "D"; // WorkingTag : Delete
	public static final String WT_EXT = "E"; // WorkingTag : Except
	public static final String WT_DEF = ""; // WorkingTag : Default


	//2017.09.15 skyung.kim - beacon

	public static final String BEACON_STATUS = "BEACON_STATUS";
	public static final boolean BEACON_STATUS_ENTER = true;
	public static final boolean BEACON_STATUS_EXIT = false;
	public static final String BEACONKEY = "_YLWBEACON_";


	//비콘List를 ClientDB에 저장해 놓은 날짜로 UpdateTime과 비교하여 BeaconUpdateTime이 이후에 저장되었으면 비콘List를 다시받아옴
	public static final String BEACON_LASTUPDATETIME = BEACONKEY + "LastUpdateTime";

	//ID가 Setting 될때 SecurityPolicy에 저장된 BeaconUpdateTime을 잠시넣어놓음
	public static final String BEACON_UPDATETIME =BEACONKEY + "UpdateTime";
	public static final String BEACON_LASTEVENT = BEACONKEY + "LastEvent";
	public static final String BEACON_TIMEKEYLIST = BEACONKEY + "TimeKeyList";
	public static final String BEACON_NOT_USING = "NULL";
	public static final int REQUEST_ENABLE_BT = 27;

	//18.02.08 skyung fb account
	public static final String FB_EMAIL = "FB_Email";
	public static final String FB_PASSWORD = "FB_Password";

	//17.12.20 skyung.kim
	public static final String IS_LOGOUT = "IsLogout";
	public static final String IS_LOGIN ="IsLoggedIn";
	public static final String IS_USE_BIO = "IsUseBio";
	public static final String IS_PATTERN_ENABLED = "IsPatternEnabled";
	public static final String IS_BIO_ENABLED = "IsBioEnabled";
	public static final String LOGIN_USERNAME = "UserName";
	public static final String IS_TFTDEMO = "Is_TFTDemo";
	//18.01.23
	public static final String  CHANGE_BIO_PW_SP = "_SCAMobileAppChangeBio";
	//18.04.26 device directory of organization employees profile photos.
	public static final String ORG_THUMBNAIL_DIR = "Download/MobileERP/Org/ThumbNail";
	public static final String ORG_PROFILE_DIR = "Download/MobileERP/Org/Profile";
	public static final String ORG_BACKGROUND_DIR = "Download/MobileERP/Org/Background";
	public static final String ORG_FILENAME = "EmpSeq_";
	public static final String JPG = ".Jpg";
	public static final String THUMB =  "THUMB";
	public static final String PROFILE = "PROFILE";
	public static final String BACKGROUND = "BACKGROUND";
	//사진이 업데이트 된 emplist중 가장 나중에 바꾼 emp의 lastdatetime
	public static final String ORG_PHOTOUPDATE_LASTDATETIME = "PhotoUpdateLastDateTime";
	public static final String ORG_BACKGROUNDUPDATE_LASTDATETIME= "BackgroundUpdateLastDateTime";

	public static final String USER_INFO_LASTDATETIME = "UserInfoLastDateTime";

	public static final String FILE_ENCRYPTED_ONLY = "OnlyEncrypted";

	public static final String FILE_ENCRYPTED_DECRYPTED = "BothFiles";
	public static final String REQUEST_VERIFICATION_SERVICE = "RequestVerificationMobileApp_json";
	public static final String VERIFY_CODE_SERVICE = "CheckVerificationMobileApp_json";
}
