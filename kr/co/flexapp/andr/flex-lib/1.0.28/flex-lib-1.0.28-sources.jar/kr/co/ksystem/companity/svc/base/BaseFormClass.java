package kr.co.ksystem.companity.svc.base;

import android.content.Context;
import android.util.Log;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import kr.co.ksystem.companity.svc.consts.Const;


public class BaseFormClass implements Serializable {
	private static final long serialVersionUID = 1985269050139398811L;

	//public boolean isOpened = false;

	/**
	 * @param args
	 */
	// '//'�� �ּ��� ������ ���� ������ ������ ���..
	public String AccUnit;
	public String AccUnitName;
	public String CompanyName;
	public int CompanySeq = 1;
	public int DevCustSeq;
	public String Dsn;
	public String EMail;
	public String EmpId;
	public String EmpName;
	public int EmpSeq;
	public String JpName;
	public int LanguageSeq;
	public String LoginDate;
	public int LoginDateDay;
	public int LoginDateMonth;
	public String LoginDateTime;
	public int LoginDateYear;
	public String Password;
	public String SiteInit;
	public String SlipUnit;
	public String SlipUnitName;
	public int SMUserType;
	public String UserID;
	public String UserName;
	public int UserSeq;

	public String ConnInfo; // ���̺� ���� Ȥ�� ���� ���� (BaseFormFramework)
	public String Message;// ���̺� ���� Ȥ�� ���� ���� _SCAGetLogin5

	// 17.07.17 dpjang
	public String ProductType = "0";

	public String BgtUnit;
	public String BizUnit;
	public String BizUnitName;
	public String CustName;
	public int CustSeq;
	public String DeptName;
	public String DeptSeq;
	public String FactUnit;
	public String HPNo;
	public String PosName;
	public int PosSeq;
	public String PuName;
	public int PuSeq;
	public String TaxName;
	public String TaxUnit;
	public String UMCostType;
	public String UMCostTypeName;
	public String WkDeptName;
	public String WkDeptSeq;
	public String url;
	public String session;






	// 16.12.05 dpjang
	private String Location;
	public void setMobileLocation(String Location){
		this.Location = Location;
	}
	public String getMobileLocation(){
		return Location;
	}

	// 16.12.05 dpjang
	private String Latitude;
	public void setMobileLatitude(String Latitude){
		this.Latitude = Latitude;
	}
	public String getMobileLatitude(){
		return Latitude;
	}

	// 16.12.05 dpjang
	private String Longitude;
	public void setMobileLongitude(String Longitude){
		this.Longitude = Longitude;
	}
	public String getMobileLongitude(){
		return Longitude;
	}

	// 17.04.11 dpjang PDA
	private String BarCodeString;
	public void setBarCodeString(String BarCodeString){this.BarCodeString = BarCodeString; }
	public String getBarCodeString() { return BarCodeString; }

	// 17.08.29 dpjang WebView result
	private String WebViewResultString;
	public void setWebViewResultString(String resultStr){
		this.WebViewResultString = resultStr;
	}
	public String getWebViewResultString(){
		return WebViewResultString;
	}

	/* _SCAGetLogin1dtData */

	private String LoginSeq;

	public String getLoginSeq() {
		return LoginSeq;
	}

	public void setLoginSeq(String loginSeq) {
		LoginSeq = loginSeq;
	}

	private String LoginID;

	public String getLoginID() {
		return LoginID;
	}

	public void setLoginID(String loginID) {
		LoginID = loginID;
	}

	/**
	 * dpjang edited _SCAGetLogin3DtData
	 */
	private String DsnOper;

	public String getDsnOper() {
		return DsnOper;
	}

	public void setDsnOper(String dsnOper) {
		DsnOper = dsnOper;
	}

	private String DsnBis;

	public String getDsnBis() {
		return DsnBis;
	}

	public void setDsnBis(String dsnBis) {
		DsnBis = dsnBis;
	}

	private String DsnEsm;

	public String getDsnEsm() {
		return DsnEsm;
	}

	public void setDsnEsm(String dsnEsm) {
		DsnEsm = dsnEsm;
	}

	private String DsnBpm;

	public String getDsnBpm() {
		return DsnBpm;
	}

	public void setDsnBpm(String dsnBpm) {
		DsnBpm = dsnBpm;
	}

	/**
	 * dpjang edited _SCOMGetLogin1DtData
	 */
	// ERP��뱹��
	private String ENV_Nation;

	public String getENV_Nation() {
		return ENV_Nation;
	}

	public void setENV_Nation(String eNV_Nation) {
		ENV_Nation = eNV_Nation;
	}

	// ȸ�籸�� Initial
	private String ENV_SiteInit;

	public String getENV_SiteInit() {
		return ENV_SiteInit;
	}

	public void setENV_SiteInit(String eNV_SiteInit) {
		ENV_SiteInit = eNV_SiteInit;
	}

	// ������(%)
	private Double ENV_CustomsTariff;

	public Double getENV_CustomsTariff() {
		return ENV_CustomsTariff;
	}

	public void setENV_CustomsTariff(Double eNV_CustomsTariff) {
		ENV_CustomsTariff = eNV_CustomsTariff;
	}

	// BOM���� ���� �Ҽ��� �Ʒ� �ڸ���
	private int ENV_DecLenBOM;

	public int getENV_DecLenBOM() {
		return ENV_DecLenBOM;
	}

	public void setENV_DecLenBOM(int eNV_DecLenBOM) {
		ENV_DecLenBOM = eNV_DecLenBOM;
	}

	// ���� ���� �Ҽ��� �Ʒ� �ڸ���
	private int ENV_DecLenMatQty;

	public int getENV_DecLenMatQty() {
		return ENV_DecLenMatQty;
	}

	public void setENV_DecLenMatQty(int eNV_DecLenMatQty) {
		ENV_DecLenMatQty = eNV_DecLenMatQty;
	}

	// ���� ��ȭ�ܰ� �Ҽ��� �Ʒ� �ڸ���
	private int ENV_DecLenMatCost;

	public int getENV_DecLenMatCost() {
		return ENV_DecLenMatCost;
	}

	public void setENV_DecLenMatCost(int eNV_DecLenMatCost) {
		ENV_DecLenMatCost = eNV_DecLenMatCost;
	}

	// ���� ��ȭ�ܰ� �Ҽ��� �Ʒ� �ڸ���
	private int ENV_DecLenMatCostFor;

	public int getENV_DecLenMatCostFor() {
		return ENV_DecLenMatCostFor;
	}

	public void setENV_DecLenMatCostFor(int eNV_DecLenMatCostFor) {
		ENV_DecLenMatCostFor = eNV_DecLenMatCostFor;
	}

	// ��ǰ/��ǰ ���� �Ҽ��� �Ʒ� �ڸ���
	private int ENV_DecLenGoodsQty;

	public int getENV_DecLenGoodsQty() {
		return ENV_DecLenGoodsQty;
	}

	public void setENV_DecLenGoodsQty(int eNV_DecLenGoodsQty) {
		ENV_DecLenGoodsQty = eNV_DecLenGoodsQty;
	}

	// ��ǰ/��ǰ ��ȭ�ܰ� �Ҽ��� �Ʒ� �ڸ���
	private int ENV_DecLenGoodsCost;

	public int getENV_DecLenGoodsCost() {
		return ENV_DecLenGoodsCost;
	}

	public void setENV_DecLenGoodsCost(int eNV_DecLenGoodsCost) {
		ENV_DecLenGoodsCost = eNV_DecLenGoodsCost;
	}

	// ��ǰ/��ǰ ��ȭ�ܰ� �Ҽ��� �Ʒ� �ڸ���
	private int ENV_DecLenGoodsCostFor;

	public int getENV_DecLenGoodsCostFor() {
		return ENV_DecLenGoodsCostFor;
	}

	public void setENV_DecLenGoodsCostFor(int eNV_DecLenGoodsCostFor) {
		ENV_DecLenGoodsCostFor = eNV_DecLenGoodsCostFor;
	}

	// ȯ�� �Ҽ��� �Ʒ� �ڸ���
	int ENV_DecLenExcRate;

	public int getENV_DecLenExcRate() {
		return ENV_DecLenExcRate;
	}

	public void setENV_DecLenExcRate(int eNV_DecLenExcRate) {
		ENV_DecLenExcRate = eNV_DecLenExcRate;
	}

	//
	int ENV_BasicForCurr;

	public int getENV_BasicForCurr() {
		return ENV_BasicForCurr;
	}

	public void setENV_BasicForCurr(int eNV_BasicForCurr) {
		ENV_BasicForCurr = eNV_BasicForCurr;
	}

	// ���ؿ�ȭ ȭ��
	String ENV_BasicForCurrName;

	public String getENV_BasicForCurrName() {
		return ENV_BasicForCurrName;
	}

	public void setENV_BasicForCurrName(String eNV_BasicForCurrName) {
		ENV_BasicForCurrName = eNV_BasicForCurrName;
	}

	//
	int ENV_BasicKorCurr;

	public int getENV_BasicKorCurr() {
		return ENV_BasicKorCurr;
	}

	public void setENV_BasicKorCurr(int eNV_BasicKorCurr) {
		ENV_BasicKorCurr = eNV_BasicKorCurr;
	}

	// ���ؿ�ȭ ȭ��
	String ENV_BasicKorCurrName;

	public String getENV_BasicKorCurrName() {
		return ENV_BasicKorCurrName;
	}

	public void setENV_BasicKorCurrName(String eNV_BasicKorCurrName) {
		ENV_BasicKorCurrName = eNV_BasicKorCurrName;
	}

	// ȸ�� ��ȭ �Ҽ��� �Ʒ� �ڸ���
	int ENV_DecLenFOR;

	public int getENV_DecLenFOR() {
		return ENV_DecLenFOR;
	}

	public void setENV_DecLenFOR(int eNV_DecLenFOR) {
		ENV_DecLenFOR = eNV_DecLenFOR;
	}

	// ȸ�� ��ȭ �Ҽ��� �Ʒ� �ڸ���
	int ENV_DecLenKOR;

	public int getENV_DecLenKOR() {
		return ENV_DecLenKOR;
	}

	public void setENV_DecLenKOR(int eNV_DecLenKOR) {
		ENV_DecLenKOR = eNV_DecLenKOR;
	}

	// ���� ��κ��� �Ҽ� �ڸ� ����
	int ENV_DecLenCostDivRate;

	// 18.03.13 dpjang
	// 전자결재 종류
	String SGroupWareType = "";

	public int getENV_DecLenCostDivRate() {
		return ENV_DecLenCostDivRate;
	}

	public void setENV_DecLenCostDivRate(int eNV_DecLenCostDivRate) {
		ENV_DecLenCostDivRate = eNV_DecLenCostDivRate;
	}

	// /rsave " ==> report toolbar��� locking
	String ReportDefSwitch;

	public String getReportDefSwitch() {
		return ReportDefSwitch;
	}

	public void setReportDefSwitch(String reportDefSwitch) {
		ReportDefSwitch = reportDefSwitch;
	}

	// �׷���� ��뿩��
	boolean GroupWareUse;

	public boolean isGroupWareUse() {
		return GroupWareUse;
	}

	public void setGroupWareUse(boolean groupWareUse) {
		GroupWareUse = groupWareUse;
	}

	//
	int ENV_DecLenManHour;

	public int getENV_DecLenManHour() {
		return ENV_DecLenManHour;
	}

	public void setENV_DecLenManHour(int eNV_DecLenManHour) {
		ENV_DecLenManHour = eNV_DecLenManHour;
	}

	/**
	 * 14.12.12 number&date set ���� ��¥ ���� dpjang
	 */
	private String NumPointType;

	public String getM_NumPointType() {
		return NumPointType;
	}

	public void setM_NumPointType(String m_NumPointType) {
		this.NumPointType = m_NumPointType;
	}

	private String NumSeparatorType;

	public String getNumSeparatorType() {
		return NumSeparatorType;
	}

	public void setNumSeparatorType(String numSeparatorType) {
		NumSeparatorType = numSeparatorType;
	}

	private String DateFormatType;

	public String getDateFormatType() {
		return DateFormatType;
	}

	public void setDateFormatType(String dateFormatType) {
		DateFormatType = dateFormatType;
	}

	private String DateSeparatorType;

	public String getDateSeparatorType() {
		return DateSeparatorType;
	}

	public void setDateSeparatorType(String dateSeparatorType) {
		DateSeparatorType = dateSeparatorType;
	}

	private String IsPgmEventSecu;

	public String getIsPgmEventSecu() {
		return IsPgmEventSecu;
	}

	public void setIsPgmEventSecu(String isPgmEventSecu) {
		IsPgmEventSecu = isPgmEventSecu;
	}

	private String IsServiceTimeLog;

	public String getIsServiceTimeLog() {
		return IsServiceTimeLog;
	}

	public void setIsServiceTimeLog(String isServiceTimeLog) {
		IsServiceTimeLog = isServiceTimeLog;
	}

	public String PgmId = "";
	public int PgmSeq;
	public String ActiveSheetControlName = ""; // ���̺� ���� Ȥ�� ���� ����
												// (BaseFormFramework)
	public String HomeDir = "";// ���̺� ���� Ȥ�� ���� ����
	public boolean IsJumpEventCancel;// ���̺� ���� Ȥ�� ���� ����
										// (BaseFormFramework)
	public boolean IsJumpInCancel_CloseButtonClick;// ���̺� ���� Ȥ�� ���� ����
													// (BaseFormFramework)
	public boolean IsOpen;// ���̺� ���� Ȥ�� ���� ���� (BaseFormFramework)

	public boolean PgmMethodEventCancel;// ���̺� ���� Ȥ�� ���� ����

	// public XmlData PgmSendXml;
	public String JumpPgmId = "";// ���̺� ���� Ȥ�� ���� ���� (BaseFormFramework)
	public String JumpPgmSeq = "";// ���̺� ���� Ȥ�� ���� ����
									// (BaseFormFramework)
	public String LinkCreateID = ""; // ���̺� ���� Ȥ�� ���� ����
										// (BaseFormFramework)
	public String RemoteAddress = "";// ���̺� ���� Ȥ�� ���� ����
										// (BaseFormFramework)
	public String JumpType = "";// ���̺� ���� Ȥ�� ���� ���� (BaseFormFramework)
	public int PgmMethodSeq;// ���̺� ���� Ȥ�� ���� ���� (BaseFormFramework)
	public int ServiceAffair;// ���̺� ���� Ȥ�� ���� ���� (BaseFormFramework)
	// public DataTable TimeOut;
	public String FactUnitName = "";
	public String BgtUnitName = "";

	public Context context;



	public String getAccUnit() {
		return AccUnit;
	}

	public void setAccUnit(String accUnit) {
		AccUnit = accUnit;
	}

	public String getAccUnitName() {
		return AccUnitName;
	}

	public void setAccUnitName(String accUnitName) {
		AccUnitName = accUnitName;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public int getCompanySeq() {
		return CompanySeq;
	}

	public void setCompanySeq(int companySeq) {
		CompanySeq = companySeq;
	}

	public int getDevCustSeq() {
		return DevCustSeq;
	}

	public void setDevCustSeq(int devCustSeq) {
		DevCustSeq = devCustSeq;
	}

	public String getDsn() {
		return Dsn;
	}

	public void setDsn(String dsn) {
		Dsn = dsn;
	}

	public String getEMail() {
		return EMail;
	}

	public void setEMail(String eMail) {
		EMail = eMail;
	}

	public String getEmpId() {
		return EmpId;
	}

	public void setEmpId(String empId) {
		EmpId = empId;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public int getEmpSeq() {
		return EmpSeq;
	}

	public void setEmpSeq(int empSeq) {
		EmpSeq = empSeq;
	}

	public String getJpName() {
		return "mobile";
	}

	public void setJpName(String jpName) {
		JpName = jpName;
	}

	public int getLanguageSeq() {
		return LanguageSeq;
	}

	public void setLanguageSeq(int languageSeq) {
		LanguageSeq = languageSeq;
	}

	public String getLoginDate() {
		return LoginDate;
	}

	public void setLoginDate(String loginDate) {
		LoginDate = loginDate;
	}

	public int getLoginDateDay() {
		return LoginDateDay;
	}

	public void setLoginDateDay(int loginDateDay) {
		LoginDateDay = loginDateDay;
	}

	public int getLoginDateMonth() {
		return LoginDateMonth;
	}

	public void setLoginDateMonth(int loginDateMonth) {
		LoginDateMonth = loginDateMonth;
	}

	public String getLoginDateTime() {
		return LoginDateTime;
	}

	public void setLoginDateTime(String loginDateTime) {
		LoginDateTime = loginDateTime;
	}

	public int getLoginDateYear() {
		return LoginDateYear;
	}

	public void setLoginDateYear(int loginDateYear) {
		LoginDateYear = loginDateYear;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getSiteInit() {
		return SiteInit;
	}

	public void setSiteInit(String siteInit) {
		SiteInit = siteInit;
	}

	public String getSlipUnit() {
		return SlipUnit;
	}

	public void setSlipUnit(String slipUnit) {
		SlipUnit = slipUnit;
	}

	public String getSlipUnitName() {
		return SlipUnitName;
	}

	public void setSlipUnitName(String slipUnitName) {
		SlipUnitName = slipUnitName;
	}

	public int getSMUserType() {
		return SMUserType;
	}

	public void setSMUserType(int sMUserType) {
		SMUserType = sMUserType;
	}

	public String getUserID() {
		return UserID;
	}

	public void setUserID(String userID) {
		UserID = userID;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public int getUserSeq() {
		return UserSeq;
	}

	public void setUserSeq(int userSeq) {
		UserSeq = userSeq;
	}

	public String getConnInfo() {
		return ConnInfo;
	}

	public void setConnInfo(String connInfo) {
		ConnInfo = connInfo;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		Message = message;
	}

	public String getBgtUnit() {
		return BgtUnit;
	}

	public void setBgtUnit(String bgtUnit) {
		BgtUnit = bgtUnit;
	}

	public String getBgtUnitName() {
		return BgtUnitName;
	}

	public void setBgtUnitName(String bgtUnitName) {
		BgtUnitName = bgtUnitName;
	}

	public String getBizUnit() {
		return BizUnit;
	}

	public void setBizUnit(String bizUnit) {
		BizUnit = bizUnit;
	}

	public String getBizUnitName() {
		return BizUnitName;
	}

	public void setBizUnitName(String bizUnitName) {
		BizUnitName = bizUnitName;
	}

	public String getCustName() {
		return CustName;
	}

	public void setCustName(String custName) {
		CustName = custName;
	}

	public int getCustSeq() {
		return CustSeq;
	}

	public void setCustSeq(int custSeq) {
		CustSeq = custSeq;
	}

	public String getDeptName() {
		return DeptName;
	}

	public void setDeptName(String deptName) {
		DeptName = deptName;
	}

	public String getDeptSeq() {
		return DeptSeq;
	}

	public void setDeptSeq(String deptSeq) {
		DeptSeq = deptSeq;
	}

	public String getFactUnit() {
		return FactUnit;
	}

	public void setFactUnit(String factUnit) {
		FactUnit = factUnit;
	}

	public String getHPNo() {
		return HPNo;
	}

	public void setHPNo(String hPNo) {
		HPNo = hPNo;
	}

	public String getPosName() {
		return PosName;
	}

	public void setPosName(String posName) {
		PosName = posName;
	}

	public int getPosSeq() {
		return PosSeq;
	}

	public void setPosSeq(int posSeq) {
		PosSeq = posSeq;
	}

	public String getPuName() {
		return PuName;
	}

	public void setPuName(String puName) {
		PuName = puName;
	}

	public int getPuSeq() {
		return PuSeq;
	}

	public void setPuSeq(int puSeq) {
		PuSeq = puSeq;
	}

	public String getTaxName() {
		return TaxName;
	}

	public void setTaxName(String taxName) {
		TaxName = taxName;
	}

	public String getTaxUnit() {
		return TaxUnit;
	}

	public void setTaxUnit(String taxUnit) {
		TaxUnit = taxUnit;
	}

	public String getUMCostType() {
		return UMCostType;
	}

	public void setUMCostType(String uMCostType) {
		UMCostType = uMCostType;
	}

	public String getUMCostTypeName() {
		return UMCostTypeName;
	}

	public void setUMCostTypeName(String uMCostTypeName) {
		UMCostTypeName = uMCostTypeName;
	}

	public String getWkDeptName() {
		return WkDeptName;
	}

	public void setWkDeptName(String wkDeptName) {
		WkDeptName = wkDeptName;
	}

	public String getWkDeptSeq() {
		return WkDeptSeq;
	}

	public void setWkDeptSeq(String wkDeptSeq) {
		WkDeptSeq = wkDeptSeq;
	}

	public String getPgmId() {
		return PgmId;
	}

	public void setPgmId(String pgmId) {
		PgmId = pgmId;
	}

	public int getPgmSeq() {
		return PgmSeq;
	}

	public void setPgmSeq(int pgmSeq) {
		PgmSeq = pgmSeq;
	}

	public String getActiveSheetControlName() {
		return ActiveSheetControlName;
	}

	public void setActiveSheetControlName(String activeSheetControlName) {
		ActiveSheetControlName = activeSheetControlName;
	}

	public String getHomeDir() {
		return HomeDir;
	}

	public void setHomeDir(String homeDir) {
		HomeDir = homeDir;
	}

	public boolean isIsJumpEventCancel() {
		return IsJumpEventCancel;
	}

	public void setIsJumpEventCancel(boolean isJumpEventCancel) {
		IsJumpEventCancel = isJumpEventCancel;
	}

	public boolean getIsJumpInCancel_CloseButtonClick() {
		return IsJumpInCancel_CloseButtonClick;
	}

	public void setIsJumpInCancel_CloseButtonClick(
			boolean isJumpInCancel_CloseButtonClick) {
		IsJumpInCancel_CloseButtonClick = isJumpInCancel_CloseButtonClick;
	}

	public boolean getIsOpen() {
		return IsOpen;
	}

	public void setIsOpen(boolean isOpen) {
		IsOpen = isOpen;
	}

	// public DataSet getJumpDs() {
	// return JumpDs;
	// }
	//
	// public void setJumpDs(DataSet jumpDs) {
	// JumpDs = jumpDs;
	// }

	public boolean isPgmMethodEventCancel() {
		return PgmMethodEventCancel;
	}

	public void setPgmMethodEventCancel(boolean pgmMethodEventCancel) {
		PgmMethodEventCancel = pgmMethodEventCancel;
	}




	// public XmlData getPgmSendXml() {
	// return PgmSendXml;
	// }
	//
	// public void setPgmSendXml(XmlData pgmSendXml) {
	// PgmSendXml = pgmSendXml;
	// }

	public String getJumpPgmId() {
		return JumpPgmId;
	}

	public void setJumpPgmId(String jumpPgmId) {
		JumpPgmId = jumpPgmId;
	}

	public String getJumpPgmSeq() {
		Log.e("testLog1", "getJumpPgmSeq : " + JumpPgmSeq);
		return JumpPgmSeq;
	}

	public void setJumpPgmSeq(String jumpPgmSeq) {
		Log.e("testLog1", "setJumpPgmSeq : " + JumpPgmSeq);
		JumpPgmSeq = jumpPgmSeq;
	}

	public String getLinkCreateID() {
		return LinkCreateID;
	}

	public void setLinkCreateID(String linkCreateID) {
		LinkCreateID = linkCreateID;
	}

	public String getRemoteAddress() {
		return RemoteAddress;
	}

	public void setRemoteAddress(String remoteAddress) {
		RemoteAddress = remoteAddress;
	}

	public String getJumpType() {
		return JumpType;
	}

	public void setJumpType(String jumpType) {
		JumpType = jumpType;
	}

	public int getPgmMethodSeq() {
		return PgmMethodSeq;
	}

	public void setPgmMethodSeq(int pgmMethodSeq) {
		PgmMethodSeq = pgmMethodSeq;
	}

	public int getServiceAffair() {
		return ServiceAffair;
	}

	public void setServiceAffair(int serviceAffair) {
		ServiceAffair = serviceAffair;
	}

	public String getDefaultDate() {
		long now = System.currentTimeMillis();
		Date date = new Date(now);
		String defaultDate = "";

		SimpleDateFormat CurYearFormat = new SimpleDateFormat("yyyy");
		SimpleDateFormat CurMonthFormat = new SimpleDateFormat("MM");
		SimpleDateFormat CurDayFormat = new SimpleDateFormat("dd");
		SimpleDateFormat CurHourFormat = new SimpleDateFormat("HH");
		SimpleDateFormat CurMinuteFormat = new SimpleDateFormat("mm");

		// ������ �������� String Ÿ�� ����
		String strCurYear = CurYearFormat.format(date);
		String strCurMonth = CurMonthFormat.format(date);
		String strCurDay = CurDayFormat.format(date);
		String strCurHour = CurHourFormat.format(date);
		String strCurMinute = CurMinuteFormat.format(date);

		defaultDate = strCurYear + strCurMonth + strCurDay + strCurHour
				+ strCurMinute;
		return defaultDate;
	}

	public String getCurrDate() {
		String inDate = new SimpleDateFormat("yyyy-MM-dd")
				.format(new Date());
		return inDate;
	}

	public String getCurrTime() {
		String inTime = new SimpleDateFormat("HH:mm:ss")
				.format(new Date());
		return inTime;
	}

	/* jump dpjang - 15.11.27 */
	public String ProgParamContainer;

	public String getProgParamContainer() {
		Log.e("testLog1", "BaseFormClass getProgParamContainer 수정 필요");
		return ProgParamContainer;
	}

	public void setProgParamContainer(String progParamContainer) {
		Log.e("testLog1", "BaseFormClass setProgParamContainer 수정 필요");
		ProgParamContainer = progParamContainer;
	}

	public int ProgTableSeq = 0;

	public int getProgTableSeq() {
		Log.e("testLog1", "BaseFormClass getProgTableSeq 수정 필요");
		return ProgTableSeq;
	}

	public void setProgTableSeq(int progTableSeq) {
		Log.e("testLog1", "BaseFormClass setProgTableSeq 수정 필요");
		ProgTableSeq = progTableSeq;
	}

	public String ProgJumpDataKey;

	public String getProgJumpDataKey() {
		Log.e("testLog1", "BaseFormClass getProgJumpDataKey 수정 필요");
		return ProgJumpDataKey;
	}

	public void setProgJumpDataKey(String progJumpDataKey) {
		Log.e("testLog1", "BaseFormClass setProgJumpDataKey 수정 필요");
		ProgJumpDataKey = progJumpDataKey;
	}

	/* end */

	// 16.01.08 dpjang pgmSecu START

	private int EventType;

	public int getEventType() {
		return EventType;
	}

	public void setEventType(int eventType) {
		EventType = eventType;
	}

	private int EventMethodType;

	public int getEventMethodType() {
		return EventMethodType;
	}

	public void setEventMethodType(int eventMethodType) {
		EventMethodType = eventMethodType;
	}

	// END

	// 17.06.20 dpjang
	// DeviceType : PHONE, PDA
	private String DeviceType;
	public String getDeviceType(){
		return DeviceType;
	}
	public void setDeviceType(String DeviceType){
		this.DeviceType = DeviceType;
	}

	// OS : ANDROID, IOS
	public String getOSType(){
		return "ANDROID";
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setSession(String session) {
		this.session = session;
	}

	public String getSession() {
		return session;
	}
}
