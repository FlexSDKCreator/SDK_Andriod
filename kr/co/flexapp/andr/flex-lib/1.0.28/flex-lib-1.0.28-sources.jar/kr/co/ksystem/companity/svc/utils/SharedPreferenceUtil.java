package kr.co.ksystem.companity.svc.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferenceUtil {

	private static final String PREF_NAME = "com.ylw.mobileerp";
	static Context mContext;

	public SharedPreferenceUtil(Context c) {
		if(c!=null)
		mContext = c;
	}

	public void put(String key, String value) {
		if (mContext != null) {
			SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,
					Activity.MODE_PRIVATE);
			SharedPreferences.Editor editor = pref.edit();

			editor.putString(key, value);
			editor.commit();
		}
	}

	public void put(String key, boolean value) {
		SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,
				Activity.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();

		editor.putBoolean(key, value);
		editor.commit();
	}

	// public void put(String key, int value) {
	// SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,
	// Activity.MODE_PRIVATE);
	// SharedPreferences.Editor editor = pref.edit();
	//
	// editor.putInt(key, value);
	// editor.commit();
	// }

	public String getValue(String key, String dftValue) {
		try {
			SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,
					Activity.MODE_PRIVATE);
			return pref.getString(key, dftValue);
		} catch (Exception e) {
			return dftValue;
		}

	}

	public int getValue(String key, int dftValue) {
		SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,
				Activity.MODE_PRIVATE);

		try {
			return pref.getInt(key, dftValue);
		} catch (Exception e) {
			return dftValue;
		}

	}

	public boolean getValue(String key, boolean dftValue) {
		SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,
				Activity.MODE_PRIVATE);

		try {
			return pref.getBoolean(key, dftValue);
		} catch (Exception e) {
			return dftValue;
		}
	}


	//17.10.11 skyung.kim
	public void remove(String key) {
		SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,Activity.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();

		editor.remove(key);
		editor.commit();
	}

	public void clearAll() {
		SharedPreferences pref = mContext.getSharedPreferences(PREF_NAME,Activity.MODE_PRIVATE);
		SharedPreferences.Editor editor = pref.edit();

		editor.clear();
		editor.commit();
	}
}
