package kr.co.ksystem.companity;

import static android.content.Context.NOTIFICATION_SERVICE;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;


import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import kr.co.ksystem.companity.consts.CompanityConstants;



public class CompanityUtils {
    private static Context mContext;

    public static void setContext(Context context) {
        mContext = context;
    }

    public static void notification(Context context, RemoteMessage remoteMessage, Class<?> intentClass) {

        RemoteMessage.Notification notification = remoteMessage.getNotification();
        Map<String, String> data = remoteMessage.getData();
        String body, title, tag;
        if (notification != null) {
            body = notification.getBody();
            title = notification.getTitle();
            tag = notification.getTag();
        } else if (data != null && data.containsKey("body")) {
            body = data.get("body");
            title = data.get("title");
            tag = data.get("tag");
        } else {
            return;
        }
        ApplicationInfo ai = null;
        try {
            ai = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return;
        }
        Bundle bundle = ai.metaData;
        String fcmNotiIconName = "com.google.firebase.messaging.default_notification_icon";
        int small_icon;
        if (bundle.containsKey(fcmNotiIconName)) {
            small_icon = bundle.getInt(fcmNotiIconName);
        } else {
            small_icon = ai.icon;
        }
        NotificationCompat.Builder mBuilder = new NotificationCompat
                .Builder(context, CompanityConstants.NOTI_CHANNEL_ID)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentText(body)
                .setContentTitle(title)
                //.Builder(this, NotificationCompat.CATEGORY_MESSAGE)
                .setSmallIcon(small_icon)
//                .setColor(context.getResources().getColor(R.color.green_color_transparency))
                .setAutoCancel(true);

        Intent notiIntent = new Intent(context, intentClass != null ? intentClass : MainActivity.class);
        //notiIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int id = tag == null ? kr.co.ksystem.companity.utils.Utils.generateIdForView() : 0;
        if (data != null) {
            Bundle dataBundle = new Bundle();
            for (Map.Entry<String, String> entry : data.entrySet()) {
                dataBundle.putString(entry.getKey(), entry.getValue());
            }
            notiIntent.putExtras(dataBundle);
        }
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addNextIntentWithParentStack(notiIntent);
        PendingIntent pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        mBuilder.setContentIntent(pendingIntent);
        NotificationManagerCompat mNotifyMgr = NotificationManagerCompat.from(context);
        assert mNotifyMgr != null;
        if (ActivityCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            mNotifyMgr.notify(tag, id, mBuilder.build());
        }
    }
}

