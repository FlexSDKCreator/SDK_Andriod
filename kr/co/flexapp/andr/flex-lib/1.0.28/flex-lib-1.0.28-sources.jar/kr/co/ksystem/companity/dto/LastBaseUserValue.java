package kr.co.ksystem.companity.dto;

public class LastBaseUserValue {
	public String SERVERIP_VALUE = "";
	public int LanguageSeq;// login conn �ʼ���.
	public int UserSeq;// login conn �ʼ���.
	public int CompanySeq;// login conn �ʼ���.

	public String DsnBis = "";// wbsmdev_bis
	public String DsnOper = "";// wbsmdev_oper

	public LastBaseUserValue() {

	}

	public String getSERVERIP_VALUE() {
		return SERVERIP_VALUE;
	}

	public void setSERVERIP_VALUE(String sERVERIP_VALUE) {
		SERVERIP_VALUE = sERVERIP_VALUE;
	}

	public int getLanguageSeq() {
		return LanguageSeq;
	}

	public void setLanguageSeq(int languageSeq) {
		LanguageSeq = languageSeq;
	}

	public int getUserSeq() {
		return UserSeq;
	}

	public void setUserSeq(int userSeq) {
		UserSeq = userSeq;
	}

	public int getCompanySeq() {
		return CompanySeq;
	}

	public void setCompanySeq(int companySeq) {
		CompanySeq = companySeq;
	}

	public String getDsnBis() {
		return DsnBis;
	}

	public void setDsnBis(String dsnBis) {
		DsnBis = dsnBis;
	}

	public String getDsnOper() {
		return DsnOper;
	}

	public void setDsnOper(String dsnOper) {
		DsnOper = dsnOper;
	}

}
