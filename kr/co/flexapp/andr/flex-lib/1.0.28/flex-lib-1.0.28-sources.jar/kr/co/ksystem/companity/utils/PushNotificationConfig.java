package kr.co.ksystem.companity.utils;

public class PushNotificationConfig {
    private static PushNotificationHandler pushNotificationHandler;

    public static void setPushNotificationHandler(PushNotificationHandler pushNotificationHandler) {
        PushNotificationConfig.pushNotificationHandler = pushNotificationHandler;
    }

    public static PushNotificationHandler getPushNotificationHandler() {
        return pushNotificationHandler;
    }
}
