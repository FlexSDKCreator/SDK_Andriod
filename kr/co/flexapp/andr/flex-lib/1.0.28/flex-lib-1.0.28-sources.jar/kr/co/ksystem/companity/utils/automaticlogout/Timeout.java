package kr.co.ksystem.companity.utils.automaticlogout;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import kr.co.ksystem.companity.consts.CommonConstants;

public class Timeout {
	private static final int REQUEST_ID = 0;
	public static long DEFAULT_TIMEOUT = 10 * 60 * 1000;

	private static PendingIntent buildIntent(Context ctx) {
		Intent intent = new Intent(CommonConstants.TIMEOUT);
//		PendingIntent sender = PendingIntent.getBroadcast(ctx, REQUEST_ID, intent, PendingIntent.FLAG_CANCEL_CURRENT);
		PendingIntent sender;
		if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			sender = PendingIntent.getBroadcast(ctx,0,intent,PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_CANCEL_CURRENT);
		}else {
			sender = PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		}
		return sender;
	}

	public static void start(Context ctx) {

		CommonConstants.lockcancel = false;
		long timeout = DEFAULT_TIMEOUT;

		if (timeout == -1) {
			// No timeout don't start timeout service
			return;
		}

		ctx.startService(new Intent(ctx, TimeoutService.class));

		long triggerTime = System.currentTimeMillis() + timeout;
		AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);

		am.set(AlarmManager.RTC, triggerTime, buildIntent(ctx));
	}

	public static void cancel(Context ctx) {
		CommonConstants.lockcancel = true;
		AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);

		am.cancel(buildIntent(ctx));

		ctx.stopService(new Intent(ctx, TimeoutService.class));

	}

}
