package kr.co.ksystem.companity.svc.base;

import android.util.Log;


public class BaseUserValue {

	/** mServerIP : http://wbs.ksystem.co.kr:8888 */
	public static String SERVERIP_VALUE = "";
	public static String SESSION_ID = "";

	public static int LanguageSeq;// login conn �ʼ���.
	public static int UserSeq;// login conn �ʼ���.

	// 18.03.12 dpjang
	public static String PassWord;

	public static int CompanySeq = 1;// login conn �ʼ���.
	public static int EmpSeq;
	public static String SlipUnit = "";
	public static String AccUnit = "";

	public static String FileServerDir = "";

	public static String ConnInfoWell = "";

	/* Dsn.. tmp value */
	public static String Dsn = "";// login conn �ʼ���.wbsmdev_oper

	public static String LoginSeq = "0";// login conn �ʼ���.
	public static String LoginID = "";
	public static String PasswordType = "";
	public static String DeptSeq = "";
	public static int PosSeq = 1;
	public static String WkDeptSeq = "";
	public static String FactUnit = "";
	public static String BizUnit = "";
	public static String DsnEsm = "";
	public static String DsnBpm = "";
	public static String DsnBis = "";// wbsmdev_bis
	public static String DsnOper = "";// wbsmdev_oper

	// 18.03.13 dpjang
	public static String SGroupWareType = ""; // 전자결재 종류

	/* ApplicationName */
	public static String HostNm = "android_default";// DPJANG
	/* 테이블에 없음. 셋팅 안함. */
	public static String HomeDir = "1";//
	public static String HostMacAddress = "1";//
	public static String HostCPU = "1";//

	/**
	 * ..Only get## _base... not to revise _base
	 */


	// dpjang 15.03.19...
	// �� �Լ��� BaseUtil.java �� �̵�
	// public static String getConntionInfo(String dsn) {
	// // 0.dsn | 1.lang | 2.UserSeq | 3.CompanySeq | 4.AccUnit | 5.LoginSeq |
	// // 6.LocalMachineName | 7.LoginID | 8.DsnBis
	// // | 9.(0.DsnBPM / 1.DeptSeq / 2.PosSeq / 3.EmpSeq / 4.WkDeptSeq) /
	// // 5.FactUnit) / 6.BizUnit) / 7.SlipUnit / 8.m_PCHomeDir / 9.m_DsnOper
	// // / 10.m_IsPgmEventSecu / 11.m_IsServiceTimeLog / 12.HostDeviceType /
	// // 13.HostMacAddress / 14.HostCPU ))
	// // | 10.HomeDir |
	//
	// String connInfo = dsn + "|" + LanguageSeq + "|" + UserSeq + "|"
	// + CompanySeq + "|" + AccUnit + "|" + LoginSeq + "|" + HostNm
	// + "|" + LoginID + "|" + DsnBis;
	// connInfo += "|" + "" + "/" + DeptSeq + "/" + PosSeq + "/" + EmpSeq
	// + "/" + WkDeptSeq + "/" + FactUnit + "/" + BizUnit + "/"
	// + SlipUnit + "/" + HomeDir.replace("/", "?") + "/" + DsnOper
	// + "/";
	// connInfo += "" + "/" + "" + "/" + "" + "/" + HostMacAddress + "/"
	// + HostCPU + "/";
	//
	// return connInfo;
	// }
}
