package kr.co.ksystem.companity.consts;

/**
 * The Class CommonConstants.
 */
public final class CommonConstants {
	
	public static final String TIMEOUT = "kr.co.ksystem.timeout";
	public static boolean relock = false;
	public static boolean lockcancel = false;
	public static boolean pgmHeaderLocked = false;
	public static boolean menuBtnPressed = false;
	public static boolean isLoggedIn = false;
	public static String localProfilePhotoPath;
	public static String localBackgroundPhotoPath;

	public static final String MESSAGETOVOTE = "MessageToVote";
	/**
	 * The crashStack variable is
	 */
	public static boolean crashStack = false;

	/** isUserPgmSettingBlock determines if user control setting is available or not
	 */
	public static boolean isUserPgmSettingBlock = false;

	public static boolean isFormToolbarVisible = true;

	/** The Constant USING_LOG for naming sharedPref File*/
	public static final String USING_LOG = "UsingLog";
	/** The Constant USING_ACTION to use as key for action capture in UsingLog*/
	public static final String USING_ACTION = "UsingAction";
	/** The Constant USING_CRASH to use as key for crash flag in UsingLog*/
	public static final String USING_CRASH = "UsingCrash";
	/** The Constant USING_ACTION_SEPARATOR to use as Using Action separator*/
	public static final String USING_ACTION_SEPARATOR = "~" + System.getProperty("line.separator");
	/** The Constant USING_LOAD to use as pattern seq for load*/
	public static final int USING_LOAD = 1;
	/** The Constant USING_EVENT to use as pattern seq for event*/
	public static final int USING_EVENT = 2;
	/** The Constant USING_CONTROL to use as pattern seq for control*/
	public static final int USING_CONTROL = 3;
	/** The Constant USING_SHEET to use as pattern seq for sheet*/
	public static final int USING_SHEET = 4;

	public static final String BUG_STATUS_WAITING = "0";
	public static final String BUG_STATUS_INPROGRESS = "1";
	public static final String BUG_STATUS_DONE_IMMEDIATELY = "3";
	public static final String BUG_STATUS_UNABLE_SUPPORT = "4";
	public static final String BUG_STATUS_CANNOOT_REPLICATE = "5";
	public static final String BUG_STATUS_DONE_OTHERS = "6";


	/**
	 * The Constant EVENT_TYPE_CLICK to use as ControlEventTypeSeq for
	 * Click, MouseDownLeft, MouseDownRight, KeyDown, ButtonClick (and CodeHelpBefore only for master controls)
	 */
	public static final int EVENT_TYPE_CLICK = 1;
	/**
	 * The Constant EVENT_TYPE_DBLCLICK to use as ControlEventTypeSeq for
	 * DblClick (dblClick btn in sheet and LongPress for master controls)
	 */
	public static final int EVENT_TYPE_DBLCLICK = 3;
	/**
	 * The Constant EVENT_TYPE_AFTER to use as ControlEventTypeSeq for
	 * LostFocus, MouseLeave, LeveCell, ComboSelChange, CodeHelpAfter, Changed, Change
	 */
	public static final int EVENT_TYPE_AFTER = 4;
	/**
	 * The Constant EVENT_TYPE_CODE_HELP_BEFORE to use as ControlEventTypeSeq for
	 * CodeHelpBefore (only used in sheet)
	 */
	public static final int EVENT_TYPE_CODE_HELP_BEFORE = 13;
    public static final int EVENT_TYPE_CODE_HELP_AFTER = 14;

	public static final int SHEET_COLUMNFIXED = 1;
	public static final int SHEET_COLUMNHIDDEN = 2;
	public static final int SHEET_COLUMNSELECTED = 3;
	public static final int SHEET_COLUMNDEFAULT = 4;
	public static final int SHEET_COLUMNSELECTEDHIDDEN = 5;

	/** The Constant ENTIRE_VIEW_WIDTH. */
	public static final String ENTIRE_VIEW_WIDTH = "EntireViewWidthKey";

	/** The Constant ENTIRE_VIEW_HEIGHT. */
	public static final String ENTIRE_VIEW_HEIGHT = "EntireViewHeightKey";

	public static final String KEYBOARD_HEIGHT_PORTRAIT = "KeyBoardHeightKeyPortrait";
	
	public static final String KEYBOARD_HEIGHT_LANDSCAPE = "KeyBoardHeightKeyLandscape";

	/** The Constant MyPREFERENCES. */
	public static final String MyPREFERENCES = "MyPrefs";

	/** The Constant SCALEFACTOR. */
	// public static final String SCALEFACTOR = "scaleFactor";

	/** The Constant COLUMN_COUNT. */
	public static final String COLUMN_COUNT_PORTRAIT = "ColumnCountPortrait";
	public static final String COLUMN_COUNT_LANDSCAPE = "ColumnCountLandscape";

	/** The Constant LINE_WIDTH. */
	// public static final String LINE_WIDTH = "lineWidth";

	public static final String IS_KEYBOARD_SHOWING = "isKeyboardShowing";

	public static String SS_QUERY = "";

	public static String SS_UPDATE = "U";

	public static String SS_INSERT = "A";

	public static String SS_DELETE = "D";

	public static String SS_CUT = "X";

	public enum enumCellType {
		enText(0), enFloat(1), enCodeHelp(2), enMask(3), EnCheck(4), enButton(5), enDate(6), enDateMonth(7), enDateDa(8), enDateYear(
				9), enDateYearMonth(10), enDateTime(11), enCurrency(12), enHyperLink(13), enPassword(14), enTextMulti(
				19), enWord(20), enCheckBoxSelect(26), enTime(30), enLabel(31), enOptionList(32), enImage(34), enChart(
				35), enProgressBar(39);
		private int value;

		private enumCellType(int value) {
			this.value = value;
		}

		public int getIntValue() {
			return value;
		}
	};

	/**
	 * The caller references the constants using <tt>Consts.EMPTY_STRING</tt>,
	 * and so on. Thus, the caller should be prevented from constructing objects
	 * of this class, by declaring this private constructor.
	 */
	private CommonConstants() {
		// this prevents even the native class from
		// calling this ctor as well :
		throw new AssertionError();
	}

	// ///////////////////////////////////////////CHANGED
	// STARTED///////////////////////////////////////////////////////////////////////

	public static final String ITEM_NAME = "Item Name";

	public static final String ITEM_CODE = "Item Code";

	public static final String SALES_QUANTITY = "Sales Quantity";

	public static final String SALES_PRICE = "Sales Price";

	public static final String ORIGINAL_PRICE = "Original Price";

	public static final String COST_PRICE = "Cost Price";

	// public static final String MARGIN = "Margin";

	public static final String PER_PRICE = "Per Price1";

	public static final String PER_MARGIN = "Per Margin";

	public static final String SOLD_DATE = "Sold Date";

	public static final String AXES_BUTTON_HEIGHT = "axesButtonHeight";
	// //////////////////////////////////////////CHANGED
	// ENDED//////////////////////////////////////////////////////////////////////////

	// UI Setting
	public static final String CODEHELPITEM_COUNT = "codeHelpItemCount";
	public static final String TEXT_SIZE = "textSize";
	public static final String ROWCOUNT_PER_PAGE = "sheetRowCountPerPage";
	public static final String COLUMNCOUNT_PER_PAGE = "columnCountPerPage";
	public static final String COLOR_SET = "colorSet";
	public static final String LOCKPATTERN_ENABLED = "lockpatternEnabled";

	public static final int THEME_ORANGE = 1;
	public static final int THEME_GREEN = 2;
	public static final int THEME_LIGHTGREEN = 3;
	public static final int THEME_LIGHTBLUE = 4;
	public static final int THEME_BLUE = 5;
	public static final int THEME_STRONGORANGE = 6;

	// CollapsedHeaderTable table in DB that holds the List of headers in the
	// PGM sequence that are collapsed
	// using their ControlSeq
	public static final String COLLAPSED_HEADER_TABLE = "CollapsedHeaderTable";

	
	public static final int SHEET_COLUMNSETTYPE = 0;
	public static final int BARCHART_COLUMNSETTYPE = 1;
	public static final int LINECHART_COLUMNSETTYPE = 2;
	public static final int PIECHART_COLUMNSETTYPE = 3;
	public static final int AREACHART_COLUMNSETTYPE = 4;
	public static final int BUBBLECHART_COLUMNSETTYPE = 5;

	// Database table name for charts
	public static final String barchartTable = "BarSelectionTable";
	public static final String linechartTable = "LineSelectionTable";
	public static final String piechartTable = "PieSelectionTable";
	public static final String bubblechartTable = "BubbleSelectionTable";
	
	public static final int QUANTITY_X = 1;
	public static final int QUANTITY_Y = 2;
	public static final int QUANTITY_Z = 3;
	
	public static final int xScale = 1;
	public static final int yScale = 2;

	//organization chart
	public static int orgChartLevelColors = 6;

	public static int moduleListRows = 6;
	public static int painListRows = 10;

	//for demo scenario where dialog is being shown
	public static boolean isDialogModule = false;

	//organization list
	public static final String ORG_BOOKMARKLIST = "Bookmark_EmpSeq";

	public static final String DTO_EMPLIST ="DTO_Emplist";
	public static final String ORG_RECENTLIST = "Recent_EmpSeq";

	public static final String LAST_DOWNLOAD_PHOTODATE = "LastDownloadTime";

	//multi mode action type
	public static final String ACTIONTYPE_SMS = "SMS";
	public static final String ACTIONTYPE_MAIL = "MAIL";
	public static final String ACTIONTYPE_CONTACT = "CONTACT";

	//BluetoothOn
	public static final String BLUETOOTH_ON_REJECT = "BluetoothOnRject";
	public static boolean ISTABLET;
	public static String USERID;

}
