package kr.co.ksystem.companity;

import kr.co.ksystem.companity.dto.CustomAction;

public class CustomFrag extends FlexFragment {

    @Override
    protected void onCustomAction(CustomAction customAction, PassResultToWeb passResultToWeb) {

    }
}
