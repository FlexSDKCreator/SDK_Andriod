package kr.co.ksystem.companity.svc.gps;

import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.widget.Toast;
import kr.co.ksystem.companity.R;

public class YlwGeocoder {
	Context ctx;

	public YlwGeocoder(Context ctx) {
		// TODO Auto-generated constructor stub
		this.ctx = ctx;
	}

	public String getYlwGeocoder(String language, double Latitude,
			double Longitude) {

		Locale locale;
		if (language.equals("kr")) {
			locale = Locale.KOREA;
		} else if (language.equals("en")) {
			locale = Locale.ENGLISH;
		} else if (language.equals("ch")) {
			locale = Locale.CHINESE;
		} else if (language.equals("jp")) {
			locale = Locale.JAPANESE;
		} else {
			locale = Locale.getDefault();
		}

		Geocoder geocoder = new Geocoder(ctx, locale);

		List<Address> list = null;

		try {
			list = geocoder.getFromLocation( Latitude, Longitude , 5);
		} catch (Exception e) {
			// TODO: handle exception
		}

		if ((list != null) && (list.size() > 0)) {
			Address address = list.get(0);

			String locations = "";
//			for (Address addr : list) {
//				for (int i = 0; i <= addr.getMaxAddressLineIndex(); i++) {
//					locations += address.getAddressLine(i) + "\n";
//				}
//			}

			locations = address.getAddressLine(0);

			locations = locations.replace("대한민국", "");
			locations = locations.replace("특별시", "");
			locations = locations.replace("광역시", "");

			locations += "~," + Latitude + "~," + Longitude;

			// Toast.makeText(ctx, "�ּ� : " + locations,
			// Toast.LENGTH_SHORT).show();
			return locations;
		} else {
			Toast.makeText(ctx, "현재 위치에 주소를 찾을 수 없습니다.",
					Toast.LENGTH_SHORT).show();

			// 15.07.31 Manoj Karki
			return " ~, ~, ";
		}

	}
}
