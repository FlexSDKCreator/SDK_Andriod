package kr.co.ksystem.companity.svc.webservice;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class AwsApiTask extends AsyncTask<String, Void, String> {
    private AwsApiResult awsApiResult;

    public AwsApiTask(AwsApiResult awsApiResult) {
        this.awsApiResult = awsApiResult;
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            String gatewayPath;
            if (strings.length == 3) {
                gatewayPath = strings[2];
            } else {
                gatewayPath = "v2/";
            }
            URL urlClient = new URL("https://api.flextudio.com/" + gatewayPath + strings[0]);
            try {
                HttpsURLConnection conn = (HttpsURLConnection) urlClient.openConnection();
                conn.setUseCaches(false);
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");

                OutputStreamWriter wr = null;
                wr = new OutputStreamWriter(conn.getOutputStream());

                wr.write(strings[1]);
                wr.close();

                if (conn.getResponseCode() == 200) {
                    StringBuilder result = new StringBuilder();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    String line;
                    while ((line = rd.readLine()) != null) {
                        result.append(line+ "\n");
                    }
                    rd.close();
                    return result.toString();
                } else {
                    return null;
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        awsApiResult.onAwsResult(result);
    }

    public interface AwsApiResult {
        void onAwsResult(String result);
    }
}
