package kr.co.ksystem.companity.grid;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class FrameLayoutWithChidOrder extends FrameLayout{
	public FrameLayoutWithChidOrder(Context context) {
		super(context);
		setChildrenDrawingOrderEnabled(true);
	}
	public FrameLayoutWithChidOrder(Context context, AttributeSet attrs) {
		super(context, attrs);
		setChildrenDrawingOrderEnabled(true);
	}

	public FrameLayoutWithChidOrder(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		setChildrenDrawingOrderEnabled(true);
	}
	
	@Override
	protected int getChildDrawingOrder(int childCount, int i) {
		return childCount - 1 - i;
	}
	

}
