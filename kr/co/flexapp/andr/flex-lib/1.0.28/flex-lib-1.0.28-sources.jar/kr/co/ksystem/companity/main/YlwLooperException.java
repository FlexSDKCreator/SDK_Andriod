package kr.co.ksystem.companity.main;

public class YlwLooperException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7135115197010416957L;
	
	public YlwLooperException() {
		super("Thrown to end looper");
	}

}
