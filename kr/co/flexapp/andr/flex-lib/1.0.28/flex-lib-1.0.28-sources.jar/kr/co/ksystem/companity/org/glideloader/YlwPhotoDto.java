package kr.co.ksystem.companity.org.glideloader;

/**
 * Created by Subhaye on 27-Jun-18.
 */
public class YlwPhotoDto {
    private String fileName;
    private String fileSvcUrl;
    private String category;

    public YlwPhotoDto(String fileName, String category, String fileSvcUrl) {
        this.fileName = fileName;
        this.category = category;
        this.fileSvcUrl = fileSvcUrl;
    }

    public String getFileName() {
        return fileName;
    }

    public String getFileSvcUrl() {
        return fileSvcUrl;
    }

    public String getCategory() {
        return category;
    }
}
