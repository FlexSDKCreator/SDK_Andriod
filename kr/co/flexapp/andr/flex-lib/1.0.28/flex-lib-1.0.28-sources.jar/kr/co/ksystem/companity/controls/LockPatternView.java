package kr.co.ksystem.companity.controls;

import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Handler;
import android.util.Log;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

import java.util.ArrayList;

import kr.co.ksystem.companity.R;

public class LockPatternView extends FrameLayout {

	private PatternListener patternListener;
	private int dimention;
	private int radius;
	private Paint mPaint = new Paint();
	private Paint pathPaint = new Paint();
	private boolean patternInProgress = false;
	private ArrayList<Integer> values = new ArrayList<Integer>();

	private int imgSize;
	// private int normalColor = Color.BLACK;
	// private int errorColor = Color.RED;
	// private int validColor = Color.CYAN;

	private int moveX;
	private int moveY;
	/**
	 * blockTouch flag is used to disable entry of new pattern while entered
	 * pattern is being processed.
	 */
	private boolean blockTouch = false;

	private Path mPath = new Path();
	private Runnable clearAllRunnable = new Runnable() {

		@Override
		public void run() {
			blockTouch = false;
			clear();
		}

	};

	public void setPatternListener(PatternListener patternListener) {
		this.patternListener = patternListener;
	}

	private Handler clearHandler = new Handler();
	public void setBlockTouch(boolean isBlockTouch) {
		blockTouch = isBlockTouch;
	}

	public LockPatternView(Context context, int dimention, int radius, int pathColor, int selectIconSize) {
		super(context);
		this.dimention = dimention;
		this.radius = radius;
		mPaint.setAntiAlias(true);
		mPaint.setDither(true);
		mPaint.setColor(getResources().getColor(R.color.dotColor));
		pathPaint.setAntiAlias(true);
		pathPaint.setDither(true);
//		pathPaint.setColor(pathColor);
		pathPaint.setColor(getResources().getColor(R.color.dotColor));
		pathPaint.setStyle(Paint.Style.STROKE);
		pathPaint.setStrokeJoin(Paint.Join.ROUND);
		pathPaint.setStrokeCap(Paint.Cap.ROUND);
//		pathPaint.setStrokeWidth(radius * 2);
		pathPaint.setStrokeWidth(getResources().getDimension(R.dimen.pattern_line_width));
		imgSize = selectIconSize;
		for (int i = 1; i <= 9; i++) {
			PatternPoint point = new PatternPoint(context, i);
			// point.setBackgroundResource(R.drawable.pattern_select_green);

			addView(point, new LayoutParams(imgSize, imgSize));
		}
		setWillNotDraw(false);

	}

	public void reset() {
		blockTouch = false;
		clear();
	}

	private void clear() {

		Log.i("skTest","clear");
		patternInProgress = false;
		// pathPaint.setColor(normalColor);
		// mPaint.setColor(normalColor);
		for (Integer val : values) {
			getChildAt(val - 1).setSelected(false);
			getChildAt(val - 1).setBackgroundResource(0);
		}
		moveX = 0;
		moveY = 0;
		values.clear();
		mPaint.setColor(getResources().getColor(R.color.dotColor));
		invalidate();
	}

	public void setError() {
		blockTouch = true;
		// pathPaint.setColor(errorColor);
		// mPaint.setColor(errorColor);
//		for (Integer val : values) {
			// getChildAt(val - 1).setSelected(false);
			// getChildAt(val -
			// 1).setBackgroundResource(R.drawable.pattern_select_red);
		Log.i("skTest","setError");
		mPaint.setColor(getResources().getColor(R.color.pattern_error_color));
		pathPaint.setColor(getResources().getColor(R.color.pattern_error_color));
//
		if(values.size() == 1) {
		//	mPaint.setColor(getResources().getColor(R.color.pattern_error_color));
			clear();
			return;
		}
		clearHandler.removeCallbacks(clearAllRunnable);
		clearHandler.postDelayed(clearAllRunnable, 1000);

		for (int i = 0; i < values.size(); i++) {
			int val = values.get(i);
			getChildAt(val - 1).setSelected(false);
//			if (i != values.size() - 1) {
//				mPaint.setColor(getResources().getColor(R.color.pattern_error_color));
//				pathPaint.setColor(getResources().getColor(R.color.pattern_error_color));
////				getChildAt(val - 1).setBackgroundResource(R.drawable.pattern_select_red_arrow);
//			} else {
//				mPaint.setColor(getResources().getColor(R.color.pattern_error_color));
//				pathPaint.setColor(getResources().getColor(R.color.pattern_error_color));
////				getChildAt(val - 1).setBackgroundResource(R.drawable.pattern_select_red);
//			}

		}
		invalidate();
	}

	public void setWait() {
		// pathPaint.setColor(validColor);
		// mPaint.setColor(validColor);
		// for (Integer val : values) {
		// getChildAt(val - 1).setSelected(false);
		// getChildAt(val -
		// 1).setBackgroundResource(R.drawable.pattern_select_green);
		// }
		// invalidate();

		clearHandler.removeCallbacks(clearAllRunnable);
		blockTouch = true;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		if (values.size() > 0) {
			mPath.rewind();
			PatternPoint startPoint = (PatternPoint) getChildAt(values.get(0) - 1);
			mPath.moveTo(startPoint.getCenterX(), startPoint.getCenterY());
			for (int i = 1; i < values.size(); i++) {
				PatternPoint point = (PatternPoint) getChildAt(values.get(i) - 1);
				mPath.lineTo(point.getCenterX(), point.getCenterY());
			}
			if (patternInProgress) {
				mPath.lineTo(moveX, moveY);
			}
			canvas.drawPath(mPath, pathPaint);
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (blockTouch) {
			return false;
		}
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			patternListener.doDown();
			doDown(event);
			return true;
		case MotionEvent.ACTION_UP:
			patternListener.doUp();
			doUp(event);
			performClick();
			return true;
		case MotionEvent.ACTION_MOVE:
			doMove(event);
			return true;
		case MotionEvent.ACTION_CANCEL:
			doUp(event);
			return true;
		default:
			return false;
		}
	}

	private void doDown(MotionEvent event) {
		pathPaint.setColor(getResources().getColor(R.color.dotColor));
		// pathPaint.setColor(normalColor);
		// mPaint.setColor(normalColor);
		int downX = (int) event.getX();
		int downY = (int) event.getY();
		int index = downX / (dimention / 3) + (downY / (dimention / 3)) * 3;
		for (Integer val : values) {
			getChildAt(val - 1).setSelected(false);
			getChildAt(val - 1).setBackgroundResource(0);
		}
		moveX = 0;
		moveY = 0;
		values.clear();
		clearHandler.removeCallbacks(clearAllRunnable);

		if (index < 9) {
			PatternPoint point = (PatternPoint) getChildAt(index);
			int centerThreshold = this.radius * 3;
			if ((downX < point.getCenterX() + centerThreshold && downX > point.getCenterX() - centerThreshold)
					&& (downY < point.getCenterY() + centerThreshold && downY > point.getCenterY() - centerThreshold)) {
				moveX = point.getCenterX();
				moveY = point.getCenterY();
				patternInProgress = true;
				point.setSelected(true);
				values.add(point.getValue());
				mPaint.setColor(getResources().getColor(R.color.dotColor));
//				point.setBackgroundResource(R.drawable.pattern_select_green);
				if (patternListener != null) {
					patternListener.onPatternStarted();
				}
			} else {
				patternInProgress = false;
			}

		} else {
			patternInProgress = false;
		}
	}

	private void doMove(MotionEvent event) {
		moveX = (int) event.getX();
		moveY = (int) event.getY();

		int index = moveX / (dimention / 3) + (moveY / (dimention / 3)) * 3;
		if (index < 9 && index > -1 && !values.contains(index + 1)) {
			PatternPoint point = (PatternPoint) getChildAt(index);
			int centerThreshold = this.radius * 3;
			if ((moveX < point.getCenterX() + centerThreshold && moveX > point.getCenterX() - centerThreshold)
					&& (moveY < point.getCenterY() + centerThreshold && moveY > point.getCenterY() - centerThreshold)) {
				if (values.size() > 0) {
					PatternPoint prevPoint = (PatternPoint) getChildAt(values.get(values.size() - 1) - 1);
					int midX = (prevPoint.getCenterX() + point.getCenterX()) / 2;
					int midY = (prevPoint.getCenterY() + point.getCenterY()) / 2;
					int midIndex = midX / (dimention / 3) + (midY / (dimention / 3)) * 3;
					PatternPoint midPoint = (PatternPoint) getChildAt(midIndex);
					if (midPoint.getValue() != point.getValue() && !values.contains(midPoint.getValue())
							&& midPoint.getCenterX() == midX && midPoint.getCenterY() == midY) {
						midPoint.setSelected(true);
//						midPoint.setBackgroundResource(R.drawable.pattern_select_green);
						int angle = getAngle(midPoint, prevPoint);
						prevPoint.setRotation(angle - 90);
						values.add(midPoint.getValue());
//						prevPoint.setBackgroundResource(R.drawable.pattern_select_green_arrow);
					}
				} else {
					patternInProgress = true;
					if (patternListener != null) {
						patternListener.onPatternStarted();
					}
				}
				point.setSelected(true);
				if (values.size() > 0) {
					PatternPoint prevPoint = ((PatternPoint) getChildAt(values.get(values.size() - 1) - 1));
//					prevPoint.setBackgroundResource(R.drawable.pattern_select_green_arrow);
					int angle = getAngle(point, prevPoint);
					prevPoint.setRotation(angle - 90);
				}
//				point.setBackgroundResource(R.drawable.pattern_select_green);
				values.add(point.getValue());
			}
		}
		invalidate();
	}

	private int getAngle(PatternPoint currentPoint, PatternPoint prevPoint) {
		double p = prevPoint.getCenterY() - currentPoint.getCenterY();
		double b = prevPoint.getCenterX() - currentPoint.getCenterX();
		int angle;
		if (b == 0) {
			if (p < 0) {
				angle = 90;
			} else {
				angle = 270;
			}
		} else {
			angle = (int) (Math.toDegrees(Math.atan2(p, b)) + 180);
		}
		return angle;
	}

	private void doUp(MotionEvent event) {



		if (patternInProgress) {
			clearHandler.removeCallbacks(clearAllRunnable);
			clearHandler.postDelayed(clearAllRunnable, 1000);
			if (values.size() > 0 && patternListener != null) {
				int patternValue = 0;
				for (Integer val : values) {
					patternValue = patternValue * 10 + val;
				}
				patternListener.onPatternSet(String.valueOf(patternValue));
			}
			patternInProgress = false;
			Log.i("skTest","doUp");
			invalidate();
		}

	}

	private class PatternPoint extends View implements AnimatorUpdateListener {
		private float radiusFactor = 1;
		private int value;
		private int col;
		private int row;
		private boolean isSelected = false;

		private ValueAnimator anim;

		public PatternPoint(Context context, int value) {
			super(context);
			this.value = value;
			col = (value - 1) % 3;
			row = (value - 1) / 3;
			setX(getCenterX() - imgSize / 2);
			setY(getCenterY() - imgSize / 2);
		}

		@Override
		protected void onDraw(Canvas canvas) {
			super.onDraw(canvas);
			// if (isSelected) {
			// mPaint.setColor(Color.GREEN);
			// } else {
			// mPaint.setColor(Color.BLACK);
			// }
			canvas.drawCircle(imgSize / 2, imgSize / 2, radius * radiusFactor, mPaint);
		}

		public void setSelected(boolean isSelected) {
			this.isSelected = isSelected;
			if (isSelected) {
				performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY,
						HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING
								| HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
				PropertyValuesHolder animateCircle = PropertyValuesHolder.ofFloat("AnimateCircle", 1, 2);
				anim = ValueAnimator.ofPropertyValuesHolder(animateCircle);
				anim.setInterpolator(new DecelerateInterpolator());
				anim.setRepeatCount(1);
				anim.setRepeatMode(ValueAnimator.REVERSE);
				anim.setDuration(150);
				anim.addUpdateListener(this);
				anim.start();

			}

			invalidate();
		}

		public int getCenterX() {
			return col * dimention / 3 + dimention / 6;
		}

		public int getCenterY() {
			return row * dimention / 3 + dimention / 6;
		}

		public int getValue() {
			return value;
		}

		@Override
		public void onAnimationUpdate(ValueAnimator animation) {
			radiusFactor = ((Float) animation.getAnimatedValue("AnimateCircle"));
			invalidate();

		}
	}

	public interface PatternListener {
		void doDown();

		void doUp();

		void onPatternStarted();

		void onPatternSet(String patternValue);
	}

}
