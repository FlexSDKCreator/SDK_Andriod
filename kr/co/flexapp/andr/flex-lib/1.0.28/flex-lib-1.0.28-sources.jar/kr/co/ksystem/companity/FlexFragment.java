package kr.co.ksystem.companity;


import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaScannerConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.util.Xml;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.webkit.WebViewAssetLoader;

import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.target.Target;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;

//import org.altbeacon.beacon.BeaconManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlSerializer;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import kr.co.ksystem.companity.MLKitScanner.MLKitScanActivity;
import kr.co.ksystem.companity.consts.CompanityConstants;
import kr.co.ksystem.companity.dialogs.CommonYLWDialog;
import kr.co.ksystem.companity.dialogs.ResultPasserInterface;
import kr.co.ksystem.companity.dto.CustomAction;
import kr.co.ksystem.companity.utils.BluetoothHelper;
import kr.co.ksystem.companity.utils.FileDownloadService;
import kr.co.ksystem.companity.utils.RuntimeJavaScriptInterface;
import kr.co.ksystem.companity.utils.Utils;
import kr.co.ksystem.companity.svc.base.BaseUserValue;
import kr.co.ksystem.companity.svc.gps.GPSTracker;
import kr.co.ksystem.companity.svc.gps.YlwGeocoder;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;

import static android.app.Activity.RESULT_OK;
import static android.content.ContentValues.TAG;
import static android.content.Context.DOWNLOAD_SERVICE;
import static android.content.Context.WIFI_SERVICE;

import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.firebase.installations.FirebaseInstallations;
import com.google.firebase.messaging.FirebaseMessaging;

import android.os.CancellationSignal;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import java.io.FileInputStream;

/**
 * A simple {@link Fragment} subclass.
 */
public abstract class FlexFragment extends Fragment implements RuntimeJavaScriptInterface.RuntimeEventListener {

    private WebView webView;
    private WebView MSWebView;
    private FrameLayout MSContainer;
    private ImageButton closeBtnMSWebView;
    private WebViewBack webViewBack;
//    private BeaconManager beaconManager;
    private final static int FILECHOOSER_RESULTCODE = 1;
    private ValueCallback<Uri> mUploadMessage;
    private static final int INPUT_FILE_REQUEST_CODE = 1;
    private static final int GPS_REQUEST = 2;
    private ValueCallback<Uri[]> mFilePathCallback;
    private WebChromeClient.FileChooserParams mFileChooserParams;
    private String mCameraPhotoPath;
    private String mCurrentPhotoAbsolutePath;
    private Uri mCapturedImageURI = null;
    private CountDownTimer scenarioLoadTimer;
    private GPSTracker.GPSResult gpsResult;
    private boolean isGPSAccurate;

    private CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
    private static final String ERROR_NO_PERMISSION = "noGPSAuth";
    private static final String ERROR_MOCK_PROVIDER = "mockprovider";
    private static final String ERROR_GPS_OFF = "gpsoff";
    private static final String ERROR_GPS = "gpserror";
    private static final String ERROR_NO_PRECISION = "noprecision";
    private BroadcastReceiver codeBroadcastReceiver;
    private ScannerResult scannerResult;
    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter[] intentFiltersArray;
    private String[][] techListsArray;
    private String nfcCallbackFunc;
    private String erpAuthToken, erpAppID;
    private CustomAuthListener customAuthListener;

    private ActivityResultLauncher<String[]> locationPermissionRequest = registerForActivityResult(new ActivityResultContracts
                    .RequestMultiplePermissions(), result -> {
                Boolean fineLocationGranted = null;
                Boolean coarseLocationGranted = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                    fineLocationGranted = result.getOrDefault(
                            Manifest.permission.ACCESS_FINE_LOCATION, false);
                    coarseLocationGranted = result.getOrDefault(
                            Manifest.permission.ACCESS_COARSE_LOCATION, false);

                } else {
                    coarseLocationGranted = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
                    fineLocationGranted = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED;

                }
                if ((fineLocationGranted != null && fineLocationGranted) ||
                        (!isGPSAccurate && coarseLocationGranted != null && coarseLocationGranted)) {
                    turnOnGps(gpsResult, isGPSAccurate);
                } else {
                    boolean preciseNeeded = coarseLocationGranted != null && coarseLocationGranted;
                    gpsResult.OnGPSReturnVal(0, 0, false, preciseNeeded ? ERROR_NO_PRECISION : ERROR_NO_PERMISSION);
                    linkToSetting(preciseNeeded);
                }
            }
    );

    private ActivityResultLauncher storagePermissionReq = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        @Override
        public void onActivityResult(Map<String, Boolean> result) {
            fileCameraChooser(mFileChooserParams, ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED);
        }
    });

    private ActivityResultLauncher notiPermissionReq = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        @Override
        public void onActivityResult(Map<String, Boolean> result) {

        }
    });

    private JSONObject bluetoothReqObj;
    private Map<String, BluetoothHelper> bluetoothHelperMap = new HashMap<>();
    private ActivityResultLauncher btPermissionReq = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        @Override
        public void onActivityResult(Map<String, Boolean> result) {
            boolean permissionGranted = true;
            for (Boolean value : result.values()) {
                if (!Boolean.TRUE.equals(value)) {
                    permissionGranted = false;
                    break;
                }
            }
            if (permissionGranted) {
                bluetoothTurnOn();
            } else if (bluetoothReqObj != null) {
                try {
                    JSONObject callback = bluetoothReqObj.getJSONObject("callback");
                    String interfaceFunc = callback.getString("function");
                    String errMsg = getString(R.string.bluetooth_permission_info);
                    JSONObject param = bluetoothReqObj.getJSONObject("param");
                    String interfaceID = param.getString("interface");
                    sendBtError(interfaceID, interfaceFunc, errMsg);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                bluetoothReqObj = null;
            }
        }
    });
    BluetoothHelper.BluetoothResults bluetoothResults = new BluetoothHelper.BluetoothResults() {
        @Override
        public void onSearchResult(String interfaceId, String callbackFn, String error, HashMap<String, String> le, HashMap<String, String> classic) {
            if (error != null) {
                sendBtError(interfaceId, callbackFn, error);
            } else {
                try {
                    JSONArray deviceList = new JSONArray();
                    for (String address : classic.keySet()) {
                        String deviceName = classic.get(address);
                        JSONObject deviceInfo = new JSONObject();
                        deviceInfo.put("Address", address);
                        deviceInfo.put("Name", deviceName);
                        deviceList.put(deviceInfo);
                    }
                    for (String address : le.keySet()) {
                        String deviceName = le.get(address);
                        if (deviceName == null) {
                            continue;
                        }
                        JSONObject deviceInfo = new JSONObject();
                        deviceInfo.put("Address", address);
                        deviceInfo.put("Name", deviceName);
                        deviceList.put(deviceInfo);
                    }
                    webView.loadUrl("javascript: " + callbackFn + "('"+interfaceId +"', null, " + (deviceList.toString()) + ")");
                }  catch (JSONException e) {
                    e.printStackTrace();
                    sendBtError(interfaceId, callbackFn, e.getMessage());
                }
            }
        }

        @Override
        public void onResult(String interfaceId, String callbackFn, String error) {
            getActivity().runOnUiThread(() -> {
                if (error != null) {
                    sendBtError(interfaceId, callbackFn, error);
                } else {
                    webView.loadUrl("javascript: " + callbackFn + "('"+interfaceId+"', null, true)");
                }
            });
        }

        @Override
        public void onMessage(String interfaceId, String callbackFn, String data, String uuid) {
            getActivity().runOnUiThread(() -> {
                webView.loadUrl("javascript: " + callbackFn + "('"+ interfaceId + "', '"+ data + (uuid == null ? "')" : "', '" + uuid + "')"));
            });
        }
    };

    private ActivityResultLauncher<Intent> fileChooserActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                int resultCode = result.getResultCode();
                Intent data = result.getData();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    Uri[] results = null;
                    // Check that the response is a good one
                    if (resultCode == Activity.RESULT_OK) {
                        if (data == null || (data.getClipData() == null && data.getDataString() == null)) {
                            // If there is not data, then we may have taken a photo
                            if (mCameraPhotoPath != null) {
                                results = new Uri[]{Uri.parse(mCameraPhotoPath)};
                                MediaScannerConnection.scanFile(getContext(), new String[]{mCurrentPhotoAbsolutePath}, null, null);
                            }
                        } else {
                            if (data.getClipData() != null) {
                                ClipData clipData = data.getClipData();
                                int count = clipData.getItemCount();
                                results = new Uri[count];
                                for (int i = 0; i < count; i++) {
                                    results[i] = clipData.getItemAt(i).getUri();
                                }
                            }
                            else {
                                String dataString = data.getDataString();
                                if (dataString != null) {
                                    results = new Uri[]{Uri.parse(dataString)};
                                }
                            }
                            if (mCurrentPhotoAbsolutePath != null) {
                                File fileToDelete = new File(mCurrentPhotoAbsolutePath);
                                if (fileToDelete.exists()){
                                    fileToDelete.delete();
                                }
                            }
                        }
                    } else if (mCurrentPhotoAbsolutePath != null) {
                        File fileToDelete = new File(mCurrentPhotoAbsolutePath);
                        if (fileToDelete.exists()){
                            fileToDelete.delete();
                        }
                    }
                    if (mFilePathCallback != null) {
                        mFilePathCallback.onReceiveValue(results);
                        mFilePathCallback = null;
                        mFileChooserParams = null;
                    }
                }
            }
    );
    private ActivityResultLauncher<Intent> scannerActivityResaultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                boolean success = result.getResultCode() == RESULT_OK;
                Intent data = result.getData();
                scannerResult.OnScannerResult(success, success ? data.getStringExtra("rawvalue") : null, success ? null : (data != null && data.hasExtra("message") ? data.getStringExtra("message") : getString(R.string.scanner_dismissed)));
//                if (result.getResultCode() == RESULT_OK) {
//                    Toast.makeText(DemoFragment.this.getContext(), result.getData().getStringExtra("rawvalue"), Toast.LENGTH_LONG);
//                }
            }
    );
    private ActivityResultLauncher<Intent> turnOnBluetoothLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                boolean success = result.getResultCode() == RESULT_OK;
                if (success) {
                    if (bluetoothReqObj != null) {
                        processBtRequest();
                    }
                } else if (bluetoothReqObj != null) {
                    try {
                        JSONObject param = bluetoothReqObj.getJSONObject("param");
                        String interfaceID = param.getString("interface");
                        JSONObject callback = bluetoothReqObj.getJSONObject("callback");
                        String interfaceFunc = callback.getString("function");
                        String errMsg = getString(R.string.no_bluetooth);
                        sendBtError(interfaceID, interfaceFunc, errMsg);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    bluetoothReqObj = null;
                }
            }
    );
    PermissionRequest wkAudioRequest;
    private ActivityResultLauncher micPermissionReq = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback<Map<String, Boolean>>() {
        @Override
        public void onActivityResult(Map<String, Boolean> result) {
            Boolean permissionGranted = false;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                permissionGranted = result.getOrDefault(Manifest.permission.RECORD_AUDIO, false);
            } else {
                permissionGranted = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            }
            if (permissionGranted) {
                wkAudioRequest.grant(wkAudioRequest.getResources());
            } else {
                wkAudioRequest.deny();
            }
            wkAudioRequest = null;
        }
    });
    BluetoothAdapter bluetoothAdapter;
    JSONObject s3downParam;
    JSONObject s3rangeParam;
    JSONObject fileDwlParam;
    JSONObject fileDataDwlParam;
    String s3downFn;
    String s3rangeFn;
    String fileDwlFn;
    String filedataDwlFn;
    ActivityResultLauncher<Intent> downloadActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                int resultCode = result.getResultCode();
                if (resultCode == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        Uri uri = Uri.parse(dataString);
                        downloadFile(uri);
                    }
                }
            }
    );
    private final Map<String, FileSession> sessions = new HashMap<>();
    private final Deque<String> pendingSaveIDs = new ArrayDeque<>();
    ActivityResultLauncher<Intent> base64ResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                String saveID = pendingSaveIDs.pollLast();
                int resultCode = result.getResultCode();
                if (resultCode == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    assert data != null;
                    String dataString = data.getDataString();
                    if (dataString != null && saveID != null) {
                        try {
                            Uri uri = Uri.parse(dataString);
                            Context context = getContext();
                            assert context != null;
                            ParcelFileDescriptor pfd = context.getContentResolver().openFileDescriptor(uri, "rw");
                            assert pfd != null;
                            FileOutputStream out = new FileOutputStream(pfd.getFileDescriptor());
                            sessions.put(saveID, new FileSession(uri, pfd, out));
                            webView.post(() -> {
                                webView.evaluateJavascript("onSaveReady('"+ saveID +"')", null);
                            });
                            return;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                webView.post(() -> {
                    webView.evaluateJavascript("onSaveCancel('"+ saveID +"')", null);
                });
            }
    );

    private void downloadFile(Uri uri) {
        if (s3downParam != null) {
            try {
                JSONArray partUrls = s3downParam.getJSONArray("partUrls");
                //int partsCount = messageObject.getInt("partsCount");
                int parallelDownloadCount = s3downParam.getInt("parallelDownloadCount");
                JSONArray partPositions = s3downParam.getJSONArray("partPositions");
                String contentType = s3downParam.has("contentType") ? s3downParam.getString("contentType") : null;
                new S3Downloader(partUrls, partPositions, parallelDownloadCount, s3downFn, contentType, uri, getContext());
            } catch (JSONException e) {
                e.printStackTrace();
                deleteFailedDownload(getContext(), uri);
                if (s3downFn != null) {
                    webView.loadUrl("javascript: " + s3downFn + "(false,'" + "Invalid params" + "')");
                }
            } finally {
                s3downParam = null;
                s3downFn = null;
            }

        } else if (s3rangeParam != null) {
            try {
                String key = s3rangeParam.getString("key");
                JSONArray ranges = s3rangeParam.getJSONArray("rangeArr");
                JSONArray partPositions = s3rangeParam.getJSONArray("partPositions");
                int parallelDownloadCount = s3rangeParam.getInt("parallelDownloadCount");
                String contentType = s3rangeParam.has("contentType") ? s3rangeParam.getString("contentType") : null;
                new S3Downloader(key, ranges, partPositions, parallelDownloadCount, s3rangeFn, contentType, uri, getContext());
            } catch (JSONException e) {
                e.printStackTrace();
                deleteFailedDownload(getContext(), uri);
                if (s3rangeFn != null) {
                    webView.loadUrl("javascript: " + s3rangeFn + "(false,'" + "Invalid params" + "')");
                }
            } finally {
                s3rangeParam = null;
                s3rangeFn = null;
            }
        } else if (fileDwlParam != null) {
            String idVal;
            try {
                idVal = fileDwlParam.has("id") ? fileDwlParam.getString("id") : "";
            } catch (JSONException e) {
                e.printStackTrace();
                idVal = "";
            }
            String id = idVal;
            try {
                String filepath = fileDwlParam.has("filePath") ? fileDwlParam.getString("filePath") : "";
                String serviceURL = fileDwlParam.has("serviceURL") ? fileDwlParam.getString("serviceURL") : "";
                String bis = fileDwlParam.has("bis") ? fileDwlParam.getString("bis") : "";
                String contentType = fileDwlParam.has("contentType") ? fileDwlParam.getString("contentType") : null;
                WebInterfaceDownload webDownload = new WebInterfaceDownload(new DownloadResult() {
                    @Override
                    public void onSuccess() {
                        if (fileDwlFn != null && !fileDwlFn.isEmpty()) {
                            webView.loadUrl("javascript: " + fileDwlFn + "('" + id + "', {'status' : {'succeed' : true,'code' : ''}})");
                        }


                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(uri, contentType != null && contentType != "null" ? contentType : "*/*");
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                            final int takeFlags = (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                            getContext().getContentResolver().takePersistableUriPermission(uri, takeFlags);
                        }
                        PackageManager packageManager = getActivity().getPackageManager();
                        if (intent.resolveActivity(packageManager) != null) {
                            startActivity(intent);
                        } else {
                            Toast.makeText(getActivity(), R.string.no_app_for_file, Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onError(String error) {
                        deleteFailedDownload(getContext(), uri);
                        if (fileDwlFn != null && !fileDwlFn.isEmpty()) {
                            webView.loadUrl("javascript: " + fileDwlFn + "('" + id + "', {'status' : {'succeed' : false,'code' : '" + error + "'}})");
                        }
                    }
                }, uri);
                webDownload.execute(serviceURL, bis, filepath, "filename");
            } catch (JSONException e) {
                e.printStackTrace();
                deleteFailedDownload(getContext(), uri);
                if (fileDwlFn != null && !fileDwlFn.isEmpty()) {
                    webView.loadUrl("javascript: " + fileDwlFn + "('" + id + "', {'status' : {'succeed' : false,'code' : '" + e.getMessage() + "'}})");
                }
            } finally {
                fileDwlParam = null;
                fileDwlFn = null;
            }
        } else if (fileDataDwlParam != null) {
            String idVal;
            try {
                idVal = fileDataDwlParam.has("id") ? fileDataDwlParam.getString("id") : "";
            } catch (JSONException e) {
                e.printStackTrace();
                idVal = "";
            }
            String id = idVal;
            try {
                String url = fileDataDwlParam.has("url") ? fileDataDwlParam.getString("url") : "";
                String xmlns = fileDataDwlParam.has("xmlns") ? fileDataDwlParam.getString("xmlns") : "";
                String filePath = fileDataDwlParam.has("filePath") ? fileDataDwlParam.getString("filePath") : "";
                String token = fileDataDwlParam.has("token") ? fileDataDwlParam.getString("token") : null;
                String ext = fileDataDwlParam.has("contentType") ? fileDataDwlParam.getString("contentType") : "";
                XmlSerializer serializer = Xml.newSerializer();
                StringWriter writer = new StringWriter();
                serializer.setOutput(writer);
                serializer.startDocument("UTF-8", true);
                serializer.startTag(null, "FileData");
                serializer.attribute(null, "xmlns", xmlns);

                serializer.startTag(null, "path");
                serializer.text(filePath);
                serializer.endTag(null, "path");

                serializer.startTag(null, "token");
                serializer.text(token);
                serializer.endTag(null, "token");

                serializer.endTag(null, "FileData");
                serializer.endDocument();
                String xmlPayload = writer.toString();

                OkHttpClient client = new OkHttpClient();
                RequestBody body = RequestBody.create(
                        MediaType.get("application/xml; charset=utf-8"),
                        xmlPayload);
                Request request = new Request.Builder()
                        .url(url)
                        .post(body)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        requireActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (filedataDwlFn != null && !filedataDwlFn.isEmpty()) {
                                    webView.loadUrl("javascript: " + filedataDwlFn + "('" + id + "', {'status' : {'succeed' : false,'code' : '" + e.getLocalizedMessage() + "'}})");
                                }
                            }
                        });
                    }

                    @Override
                    public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                        //int code = response.code();
                        if (response.isSuccessful()) {
                            ResponseBody responseBody = response.body();
                            int bufferSize = 1024 * 2;
                            BufferedInputStream inputStream = new BufferedInputStream(responseBody.byteStream(), bufferSize);

                            OutputStream os = getContext().getContentResolver().openOutputStream(uri);
                            if (os != null) {
                                int bytesRead;
                                byte[] data = new byte[bufferSize];
                                while ((bytesRead = inputStream.read(data)) != -1) {
                                    os.write(data, 0, bytesRead);
                                }
                                os.flush();
                                os.close();
                            }
                            inputStream.close();
                            requireActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (filedataDwlFn != null && !filedataDwlFn.isEmpty()) {
                                        webView.loadUrl("javascript: " + filedataDwlFn + "('" + id + "', {'status' : {'succeed' : true,'code' : ''}})");
                                    }
                                    Intent intent = new Intent(Intent.ACTION_VIEW);
                                    String contentType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                                    intent.setDataAndType(uri, contentType != null && contentType != "null" ? contentType : "*/*");
                                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                        final int takeFlags = (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                                        getContext().getContentResolver().takePersistableUriPermission(uri, takeFlags);
                                    }
                                    PackageManager packageManager = getActivity().getPackageManager();
                                    if (intent.resolveActivity(packageManager) != null) {
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(getActivity(), R.string.no_app_for_file, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        } else {
                            requireActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (filedataDwlFn != null && !filedataDwlFn.isEmpty()) {
                                        webView.loadUrl("javascript: " + filedataDwlFn + "('" + id + "', {'status' : {'succeed' : false,'code' : '파일을 다운로드할 수 없습니다.'}})");
                                    }
                                }
                            });
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                deleteFailedDownload(getContext(), uri);
                if (filedataDwlFn != null && !filedataDwlFn.isEmpty()) {
                    webView.loadUrl("javascript: " + filedataDwlFn + "('" + id + "', {'status' : {'succeed' : false,'code' : '" + e.getLocalizedMessage() + "'}})");
                }
            } finally {
                fileDataDwlParam = null;
                filedataDwlFn = null;
            }
        }
    }

    private void deleteFailedDownload(Context context, Uri uri) {
        try {
            DocumentsContract.deleteDocument(context.getContentResolver(), uri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }


    public FlexFragment() {
        // Required empty public constructor
    }

    private ImageView loadingView;
    private View loadingContainer;
    private WebViewAssetLoader assetLoader;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_demo, container, false);
        RuntimeJavaScriptInterface javaScriptInterface = new RuntimeJavaScriptInterface(this);
        webView = view.findViewById(R.id.webview);
        MSWebView = view.findViewById(R.id.MSWebview);
        MSContainer = view.findViewById(R.id.MSLoginContainer);
        closeBtnMSWebView = view.findViewById(R.id.close_MSWebView);
        WebSettings webViewSettings = webView.getSettings();
        // Setting this off for security. Off by default for SDK versions >= 16.
        webViewSettings.setAllowFileAccessFromFileURLs(false);
        // Off by default, deprecated for SDK versions >= 30.
        webViewSettings.setAllowUniversalAccessFromFileURLs(false);
        // Keeping these off is less critical but still a good idea, especially if your app is not
        // using file:// or content:// URLs.
        webViewSettings.setAllowFileAccess(false);
        webViewSettings.setAllowContentAccess(false);
        loadingContainer = view.findViewById(R.id.loadingContainer);
        loadingView = view.findViewById(R.id.loading_view);
        //loadingView.animateView();
        codeBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String code = intent.getStringExtra("code");
                webView.loadUrl("javascript: verificationObj.codeReceived(" + code + ")");
            }
        };
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(codeBroadcastReceiver, new IntentFilter(CompanityConstants.SMS_CODE_BROADCAST));

        GlideApp.with(getContext())
                .asGif()
                .format(DecodeFormat.PREFER_ARGB_8888)
                .load(R.drawable.loadingdot)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .override(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)
                .into(loadingView);
        Bundle bundle = getArguments();
        String appId = bundle.getString("appId");
        String url = "https://" + (appId != null ? (appId + ".app.flextudio.com/") : "app.flextudio.com/");
        String linkParam = bundle.getString("linkParam");
        if (linkParam != null) {
            url += "?"+linkParam;
        }
        webView.setWebViewClient(new CustomWebClientView());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.addJavascriptInterface(javaScriptInterface, "bridge");
        MSWebView.setWebViewClient(new WebViewClient());
        MSWebView.getSettings().setJavaScriptEnabled(true);
        MSWebView.getSettings().setDomStorageEnabled(true);
        MSWebView.addJavascriptInterface(javaScriptInterface, "bridge");

        closeBtnMSWebView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideMSLoginContainer();
            }
        });
        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain("app.flextudio.com")
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(getContext()))
                .build();
        if (bundle.containsKey("cookieData")) {
            CookieManager cookieManager = CookieManager.getInstance();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.setAcceptThirdPartyCookies(webView, true);
            } else {
                cookieManager.setAcceptCookie(true);
            }
            try {
                JSONObject cookieData = new JSONObject(bundle.getString("cookieData"));
                Iterator<String> keys = cookieData.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    cookieManager.setCookie(".flextudio.com", key + "=" + cookieData.getString(key) + "; path=/; Secure; HttpOnly;");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        webView.loadUrl(url);
        webView.setWebChromeClient(new ChromeClient());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            boolean permission = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            if (!permission) {
                //ask permission
                if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    Snackbar.make(webView, R.string.noti_permission_info, Snackbar.LENGTH_INDEFINITE)
                            .setAction(R.string.ok, new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent();
                                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                                    intent.setData(uri);
                                    startActivity(intent);
                                }
                            }).show();
                }

                notiPermissionReq.launch(new String[]{Manifest.permission.POST_NOTIFICATIONS});
            }
        }
        //hideLoadingView();
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof WebViewBack) {
            webViewBack = (WebViewBack) context;
        }
        if (context instanceof CustomAuthListener) {
            customAuthListener = (CustomAuthListener) context;
        }
    }

    @Override
    public void onDetach() {
        cancellationTokenSource.cancel();
        super.onDetach();
    }


    @Override
    public void onPostMessage(String msg) {
        if (isAdded()) {
            try {
                JSONObject messageObject = new JSONObject(msg);
                String action = messageObject.getString("action");
                JSONObject param = null;
                JSONObject callback = null;
                if (messageObject.has("param")) {
                    param = messageObject.getJSONObject("param");
                }
                if (messageObject.has("callback")) {
                    callback = messageObject.getJSONObject("callback");
                }
                final String id = messageObject.has("id") ? messageObject.getString("id") : "";
                switch (action) {
                    case "openmenu":
                        openDrawer(true);
                        break;
                    case "statusbar":
                        if (param.length() > 1) {
                            webStatusBarColor(param.getString("color"), param.getString("systemColor"));
                        } else {
                            webStatusBarColor(param.getString("color"));
                        }

                        break;
                    case "initdata":
                        if (callback != null && callback.has("function")) {
                            webView.loadUrl("javascript: " + callback.getString("function") + "(" + Utils.readFromFile("userInfo", getContext()) + ")");
                        }
                        break;
                    case "loadgps":
                        loadgps(param, callback, id, false);
                        break;
                    case "loadgpsnavigation":
                        loadgps(param, callback, id, true);
                        break;
                    case "loadbarcode":
                        loadbarcode(param, callback, id);
                        break;
                    case "filedownload":
                        fileDwlFn = null;
                        if (callback != null && callback.has("function")) {
                            fileDwlFn = callback.getString("function");
                        }
                        try {
                            String filepath = param.has("filePath") ? param.getString("filePath") : "";
                            String contentType = param.has("contentType") ? param.getString("contentType") : null;
                            param.put("id", id);
                            fileDwlParam = param;
                            String filename = filepath.substring(filepath.lastIndexOf("\\") + 1);
                            if (contentType == null || contentType == "null" ) {
                                int dotIndex = filename.lastIndexOf('.');
                                String extension = dotIndex > 0 ? filename.substring(dotIndex + 1).toLowerCase() : "";
                                contentType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
                                if (contentType == null) {
                                    contentType = "*/*";
                                }
                            }
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                Intent downloadIntent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                downloadIntent.addCategory(Intent.CATEGORY_OPENABLE);
                                downloadIntent.setType(contentType);
                                downloadIntent.putExtra(Intent.EXTRA_TITLE, filename);
                                downloadActivityResultLauncher.launch(downloadIntent);
                            }
                            else {
                                String appFolderName = getAppName(requireContext());
                                Uri uri = createDownloadUri(requireContext(), appFolderName, filename, contentType);
                                downloadFile(uri);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            if (fileDwlFn != null && fileDwlFn.isEmpty()) {
                                webView.loadUrl("javascript: " + fileDwlFn + "('" + id + "', {'status' : {'succeed' : false,'code' : '" + e.getMessage() + "'}})");
                            }
                        }
                        break;
                    case "downloadfiledata":
                        filedataDwlFn = null;
                        assert param != null;
                        if (param.has("fileName")) {
                            String fileName = param.getString("fileName");
                            if (callback != null && callback.has("function")) {
                                filedataDwlFn = callback.getString("function");
                            }
                            String ext = param.has("contentType") ? param.getString("contentType") : "";
                            String contentType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                            if (contentType == null) {
                                contentType = "*/*";
                            }
                            param.put("id", id);
                            fileDataDwlParam = param;
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                Intent downloadIntent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                downloadIntent.addCategory(Intent.CATEGORY_OPENABLE);
                                downloadIntent.setType(contentType);
                                downloadIntent.putExtra(Intent.EXTRA_TITLE, fileName);
                                downloadActivityResultLauncher.launch(downloadIntent);
                            }
                            else {
                                String appFolderName = getAppName(requireContext());
                                Uri uri = createDownloadUri(requireContext(), appFolderName, fileName, contentType);
                                downloadFile(uri);
                            }
                        }
                        break;
                    case "s3down":
                        s3downFn = null;
                        if (callback != null && callback.has("function")) {
                            s3downFn = callback.getString("function");
                        }
                        try {
                            String filename = param.getString("filename");
                            String contentType = param.has("contentType") ? param.getString("contentType") : null;
                            s3downParam = param;
                            if (contentType == null || contentType == "null" ) {
                                int dotIndex = filename.lastIndexOf('.');
                                String extension = dotIndex > 0 ? filename.substring(dotIndex + 1).toLowerCase() : "";
                                contentType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
                                if (contentType == null) {
                                    contentType = "*/*";
                                }
                            }
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                Intent partIntent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                partIntent.addCategory(Intent.CATEGORY_OPENABLE);
                                partIntent.setType(contentType);
                                partIntent.putExtra(Intent.EXTRA_TITLE, filename);
//                                intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, pickerInitialUri);
                                downloadActivityResultLauncher.launch(partIntent);
                            }
                            else {
                                String appFolderName = getAppName(requireContext());
                                Uri uri = createDownloadUri(requireContext(), appFolderName, filename, contentType);
                                downloadFile(uri);
                            }

                        } catch (JSONException e) {
                            if (s3downFn != null && !s3downFn.isEmpty()) {
                                webView.loadUrl("javascript: " + s3downFn + "(false,'" + "Invalid params" + "')");
                            }
                        }
                        break;
                    case "s3range":
                        s3rangeFn = null;
                        if (callback != null && callback.has("function")) {
                            s3rangeFn = callback.getString("function");
                        }
                        try {
                            String filename = param.getString("filename");
                            String contentType = param.has("contentType") ? param.getString("contentType") : null;
                            if (contentType == null || contentType == "null" ) {
                                int dotIndex = filename.lastIndexOf('.');
                                String extension = dotIndex > 0 ? filename.substring(dotIndex + 1).toLowerCase() : "";
                                contentType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
                                if (contentType == null) {
                                    contentType = "*/*";
                                }
                            }
                            s3rangeParam = param;
                            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                Intent rangeIntent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                                rangeIntent.addCategory(Intent.CATEGORY_OPENABLE);
                                rangeIntent.setType(contentType != null && contentType != "null" ? contentType : "*/*");
                                rangeIntent.putExtra(Intent.EXTRA_TITLE, filename);
                                downloadActivityResultLauncher.launch(rangeIntent);
                            }
                            else {
                                String appFolderName = getAppName(requireContext());
                                Uri uri = createDownloadUri(requireContext(), appFolderName, filename, contentType);
                                downloadFile(uri);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            if (s3rangeFn != null && !s3rangeFn.isEmpty()) {
                                webView.loadUrl("javascript: " + s3rangeFn + "(false,'" + "Invalid params" + "')");
                            }
                        }
                        break;
                    case "clearbadge":
                        NotificationManager notificationManager = (NotificationManager) getActivity().getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
                        int timestamp = param.has("timestamp") ? param.getInt("timestamp") : -1;
                        if (timestamp == -1) {
                            notificationManager.cancelAll();
                        } else {
                            notificationManager.cancel(""+timestamp, 0);
                        }
                        break;
                    case "closeloading":
                        hideLoadingView();
                        if (callback != null && callback.has("function")) {
                            webView.loadUrl("javascript: " + callback.getString("function") + "()");
                        }
                        break;
                    case "logout":
                        if (webViewBack != null) {
                            webViewBack.onWebLogout();
                        }
                        break;
                    case "nosession":
                        if (webViewBack != null) {
                            webViewBack.onWebNoSession();
                        }
                        break;
                    case "localip":
                        if (callback != null && callback.has("function")) {
                            webView.loadUrl("javascript: " + callback.getString("function") + "(" + getDeviceipWiFiData() + ")");
                        }
                        break;
                    case "invitedpackageid":
                        if (callback != null && callback.has("function")) {
                            String inviteFunc = callback.getString("function");
                            webView.loadUrl("javascript: " + inviteFunc +"(false, '" + (getContext().getPackageName()/*BuildConfig.APPLICATION_ID*/) +"')");
                        }
                        break;
                    case "listenforsms":
                        SmsRetrieverClient smsRetrieverClient = SmsRetriever.getClient(getContext());
                        Task<Void> task = smsRetrieverClient.startSmsRetriever();
                        task.addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.e("Sms listen", "Success");
                            }
                        });
                        task.addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("Sms listen fail", e.getMessage());
                            }
                        });
                        break;
                    case "loginnotitoken":
                        if (callback != null && callback.has("function")) {
                            final String finalFunc = callback.getString("function");
                            try {
                                FirebaseMessaging.getInstance().getToken()
                                        .addOnCompleteListener(task1 -> {
                                            String pushToken;
                                            if (!task1.isSuccessful()) {
                                                Log.w(TAG, "Fetching FCM registration token failed", task1.getException());
                                                pushToken = null;
                                            } else {
                                                pushToken = task1.getResult();
                                            }
                                            FirebaseInstallations.getInstance().getId()
                                                    .addOnCompleteListener(fbidTask -> {
                                                        if (fbidTask.isSuccessful()) {
                                                            String fbid = fbidTask.getResult();
                                                            webView.loadUrl("javascript: " + finalFunc + "(" + (pushToken != null ? ("'" + pushToken + "', '") : "null, '")  + fbid + "')");
                                                        } else {
                                                            webView.loadUrl("javascript: " + finalFunc + "(" + (pushToken != null ? ("'" + pushToken + "'") : "null") );
                                                        }
                                                    });
                                        });
                            } catch (IllegalStateException e) {
                                webView.loadUrl("javascript: " + finalFunc + "()");
                            }
                        }
                        break;
                    case "getDeviceList":
                    case "connectToDevice":
                        if (callback != null && callback.has("function")) {
                            String interfaceFunc = callback.getString("function");
                            if (bluetoothReqObj == null) {
                                bluetoothReqObj = messageObject;
                                bluetoothPermission();
                            } else {
                                String errMsg = "another request in process";
                                String interfaceID = param.getString("interface");
                                sendBtError(interfaceID, interfaceFunc, errMsg);
                            }
                        }
                        break;
                    case "sendToDevice":
                        if (callback != null && callback.has("function")) {
                            String interfaceFunc = callback.getString("function");
                            String interfaceName = null;
                            if (param != null && param.has("interface")) {
                                interfaceName = param.getString("interface");
                            }
                            BluetoothHelper bluetoothHelper;
                            if (bluetoothHelperMap.containsKey(interfaceName)) {
                                bluetoothHelper = bluetoothHelperMap.get(interfaceName);
                                String data = null;
                                if (param.has("data")) {
                                    data = param.getString("data");
                                }
                                if (data != null) {
                                    bluetoothHelper.send(data, interfaceFunc);
                                } else {
                                    sendBtError(interfaceName, interfaceFunc, "no data param");
                                }
                            } else {
                                sendBtError(interfaceName, interfaceFunc, "connection hasn't been made");
                            }
                        }
                        break;
                    case "disconnectBluetooth":
                        if (callback != null && callback.has("function")) {
                            String interfaceFunc = callback.getString("function");
                            String interfaceName = null;
                            if (param != null && param.has("interface")) {
                                interfaceName = param.getString("interface");
                            }
                            BluetoothHelper bluetoothHelper;
                            if (bluetoothHelperMap.containsKey(interfaceName)) {
                                bluetoothHelper = bluetoothHelperMap.get(interfaceName);
                                bluetoothHelper.disconnect(interfaceFunc);
                            } else {
                                sendBtError(interfaceName, interfaceFunc, "connection hasn't been made");
                            }
                        }
                        break;
                    case "nfcScan":
                        if (callback != null && callback.has("function")) {
                            String nfcCallbackFunc = callback.getString("function");
                            Activity activity = getActivity();
                            nfcAdapter = NfcAdapter.getDefaultAdapter(activity);
                            if (nfcAdapter == null) {
                                String runJS = "javascript: " + nfcCallbackFunc + "('" +"NFC is not supported on this device."+ "')";
                                webView.loadUrl(runJS);
                            } else if (!nfcAdapter.isEnabled()) {
                                String runJS = "javascript: " + nfcCallbackFunc + "('" +"NFC is disabled. Please enable NFC in settings."+ "')";
                                webView.loadUrl(runJS);
                                Intent intent = new Intent(Settings.ACTION_NFC_SETTINGS);
                                startActivity(intent);
                            } else {

                                pendingIntent = PendingIntent.getActivity(
                                        activity, 0, new Intent(activity, activity.getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_MUTABLE);
                                IntentFilter ndef = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
                                try {
                                    ndef.addDataType("*/*");
                                } catch (IntentFilter.MalformedMimeTypeException e) {
                                    Log.e("ndef dataType:", e.getMessage());
                                    String runJS = "javascript: " + nfcCallbackFunc + "('" +"Failed to add MIME type."+ "')";
                                    webView.loadUrl(runJS);
                                }
                                //IntentFilter tag = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
                                //IntentFilter tech = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
                                this.nfcCallbackFunc = nfcCallbackFunc;
                                intentFiltersArray = new IntentFilter[]{ndef};//, tag, tech};
                                techListsArray = new String[][]{new String[]{Ndef.class.getName()}};
                                nfcAdapter.enableForegroundDispatch(getActivity(), pendingIntent, intentFiltersArray, techListsArray);
                            }
                        }
                        break;
                    case "appShare":
                        if (param != null && param.has("text")) {
                            String textToShare = param.getString("text");
                            Intent sendIntent = new Intent();
                            sendIntent.setAction(Intent.ACTION_SEND);
                            sendIntent.putExtra(Intent.EXTRA_TEXT, textToShare);
                            sendIntent.setType("text/plain");
                            Intent shareIntent = Intent.createChooser(sendIntent, null);
                            startActivity(shareIntent);
                        }
                        break;
                    case "loadBeacon":
                        break;
                    case "OpenLinkApp":
                        if (param != null && param.length() > 0) {
                            String urlPath = param.has("andr") ? param.getString("andr") : null;
                            if (urlPath != null) {
                                if (urlPath.startsWith("https://entra.flextudio.com/oidc/")) {
                                    getActivity().runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            MSWebView.loadUrl(urlPath);
                                            MSContainer.setVisibility(View.VISIBLE);
                                        }
                                    });
                                }
                                else {
                                    Uri uri = Uri.parse(urlPath);
                                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, uri);
//                                PackageManager packageManager = getActivity().getPackageManager();
//                                List<ResolveInfo> activities =
//                                        packageManager.queryIntentActivities(mapIntent, 0);
//                                boolean isIntentSafe = activities.size() > 0;
//                                if (isIntentSafe) {
//                                    startActivity(mapIntent);
//                                }
                                    try {
                                        startActivity(mapIntent);
                                    } catch (ActivityNotFoundException e) {
                                        Toast.makeText(getActivity(), "Unable to open link. No app found.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        }
                        break;
                    case "closeApp":
                        if (getActivity() != null) {
                            getActivity().finishAffinity();
                        }
                        break;
                    case "initLogin":
                        if (erpAuthToken != null && erpAppID != null) {
                            initYlwAuth(erpAuthToken, erpAppID);
                        } else if (customAuthListener != null){
                            customAuthListener.onAuthTokenRequest(this);
                        }
                        break;
                    case "entraAuthClose":
                        hideMSLoginContainer();
                        break;
                    default:
                        CustomAction appDoParam = new CustomAction(action);
                        if (param != null) {
                            Map params = appDoParam.getParam();
                            Iterator<String> keys = param.keys();
                            while (keys.hasNext()) {
                                String key = keys.next();
                                params.put(key, param.get(key));
                            }
                        }
                        PassResultToWeb passResultToWeb = null;
                        if (callback != null) {
                            JSONObject finalCallback = callback;
                            passResultToWeb = (error, result) -> {
                                try {
                                    String callbackFunc = finalCallback.getString("function");
                                    String runFunction = finalCallback.getString("runFunction");
                                    String runJS = "javascript: " + callbackFunc + "('" + runFunction + (error == null ? "', null, " : "', '" + error + "', ")
                                            + (result == null ? "null)" : "'" + result + "')");
                                    webView.loadUrl(runJS);
                                } catch (JSONException e) {
                                    throw new RuntimeException(e);
                                }
                            };
                        }
                        onCustomAction(appDoParam, passResultToWeb);
                }
                if (callback != null && callback.has("script")) {
                    webView.loadUrl("javascript: " + callback.getString("script"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        Log.i("onPostMessage", msg);
    }

    @Override
    public void download(String url, String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            fileName = url.substring(url.lastIndexOf("/") + 1);
        }
        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url))//.setMimeType(mimeType)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
        try {
            Activity activity = getActivity();
            if (activity != null) {
                DownloadManager dm = (DownloadManager) getActivity().getSystemService(DOWNLOAD_SERVICE);
                dm.enqueue(req);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initSave(String uniqueID, String filename) {
        int dotIndex = filename.lastIndexOf('.');
        String extension = dotIndex > 0 ? filename.substring(dotIndex + 1).toLowerCase() : "";
        String contentType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        if (contentType == null) {
            contentType = "*/*";
        }
        Intent downloadIntent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        downloadIntent.addCategory(Intent.CATEGORY_OPENABLE);
        downloadIntent.setType(contentType);
        downloadIntent.putExtra(Intent.EXTRA_TITLE, filename);
        pendingSaveIDs.addLast(uniqueID);
        base64ResultLauncher.launch(downloadIntent);
    }

    @Override
    public void fileChunk(String b64, String filename, String offset, String contentLength, String uniqueID) {
        FileSession s = sessions.get(uniqueID);
        if (s == null) return;
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            s.out.write(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void fileComplete(String uniqueID, String filename) {
        FileSession s = sessions.remove(uniqueID);
        if (s == null) return;
        try {
            s.out.close();
            s.pfd.close();
            Context context = getContext();
            if (context != null) {
                try (Cursor cursor = context.getContentResolver().query(s.uri,
                        new String[]{ OpenableColumns.DISPLAY_NAME },
                        null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) {
                        int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        String displayName = cursor.getString(idx);
                        webView.evaluateJavascript("showFileToast('"+ displayName +"')", null);
                    }
                } catch (Exception e) {
                    Log.e("fileComplete", e.getMessage());
                }
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    Intent scan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    scan.setData(s.uri);
                    context.sendBroadcast(scan);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void printPdf(String b64, String jobName) {
        Activity activity = getActivity();
        if (activity == null || b64 == null || b64.isEmpty()) return;
        try {
            byte[] pdf = Base64.decode(b64, Base64.DEFAULT);
            final File file = new File(activity.getCacheDir(), "ozprint_" + System.currentTimeMillis() + ".pdf");
            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(pdf);
            }
            final String name = (jobName == null || jobName.isEmpty()) ? "document.pdf" : jobName;

            PrintDocumentAdapter adapter = new PrintDocumentAdapter() {
                @Override
                public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                                     CancellationSignal cancellationSignal, LayoutResultCallback callback, Bundle extras) {
                    if (cancellationSignal.isCanceled()) {
                        callback.onLayoutCancelled();
                        return;
                    }
                    PrintDocumentInfo info = new PrintDocumentInfo.Builder(name)
                            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                            .build();
                    callback.onLayoutFinished(info, !newAttributes.equals(oldAttributes));
                }

                @Override
                public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                                    CancellationSignal cancellationSignal, WriteResultCallback callback) {
                    try (FileInputStream in = new FileInputStream(file);
                         FileOutputStream out = new FileOutputStream(destination.getFileDescriptor())) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            if (cancellationSignal.isCanceled()) {
                                callback.onWriteCancelled();
                                return;
                            }
                            out.write(buf, 0, n);
                        }
                        callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                    } catch (IOException e) {
                        callback.onWriteFailed(e.getMessage());
                    }
                }

                @Override
                public void onFinish() {
                    //noinspection ResultOfMethodCallIgnored
                    file.delete();
                }
            };

            PrintManager printManager = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
            printManager.print(name, adapter, new PrintAttributes.Builder().build());
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(activity, "인쇄 준비 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
        }
    }

    protected abstract void onCustomAction(CustomAction customAction, PassResultToWeb passResultToWeb);

    protected void runJS(String script) {
        webView.loadUrl("javascript: "+script);
    }

    public void logOut() {
        webView.loadUrl("javascript: logOut()");
    }

    public void initYlwAuth(String authToken, String appID) {
        if (webView != null) {
            webView.evaluateJavascript("(function() { try { initYlwAuth('"+authToken+"', '"+appID+"'); return 'success'; } catch (e) { return 'error: ' + e.message; } })();", new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String s) {
                    if (s.equals("\"success\"")) {
                        erpAuthToken = null;
                        erpAppID = null;
                    } else {
                        erpAuthToken = authToken;
                        erpAppID = appID;
                        Log.d("initYlwAuth", "JS Execution Result: " + s);
                    }
                }
            });
        } else {
            erpAuthToken = authToken;
            erpAppID = appID;
        }
    }

    private void sendBtError(String interfaceId, String interfaceFunc, String errMsg) {
        JSONObject btError = new JSONObject();
        try {
            btError.put("succeed", false);
            btError.put("message", errMsg);
            webView.loadUrl("javascript: " + interfaceFunc + "('"+interfaceId+"', " + (btError.toString()) + ")");
        }  catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private boolean hasCameraPermission() {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else if (shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
            Snackbar.make(webView, R.string.camera_permission_info, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.ok, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent = new Intent();
                            intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                        }
                    }).show();
            fileCameraChooser(mFileChooserParams, false);
            /*if (mFilePathCallback != null) {
                mFilePathCallback.onReceiveValue(null);
                mFilePathCallback = null;
                mFileChooserParams = null;
            }*/
        } else {
            storagePermissionReq.launch(new String[]{Manifest.permission.CAMERA});
        }
        return false;
    }

    private void loadgps(JSONObject param, JSONObject callback, String id, boolean isAccurate) throws JSONException {
        if (callback != null && callback.has("function")) {
            final String gpsFunction = callback.getString("function");
            final JSONObject gpsParam = param;
            GPSTracker.GPSResult gpsResult = new GPSTracker.GPSResult() {
                @Override
                public void OnGPSReturnVal(double latitude, double longitude, boolean is, String errType) {

                    if (!isAdded()) {
                        return;
                    }

                    YlwGeocoder geo = new YlwGeocoder(getActivity());
                    String address = geo.getYlwGeocoder("kr", latitude,
                            longitude);
                    String[] addressArr = address.split("~,");
                    //        String[]gpsValArr = new String[3];
                    //        gpsValArr[0] = String.valueOf(latitude);
                    //        gpsValArr[1] = String.valueOf(longitude);
                    //        gpsValArr[2] = String.valueOf(address);


                    if (gpsFunction != null) {

                        JSONObject gpsResult = new JSONObject();
                        try {
                            JSONObject status = new JSONObject();
                            status.put("succeed", is);
                            JSONObject gpsObj = new JSONObject();
                            gpsObj.put("latitude", String.valueOf(latitude));
                            gpsObj.put("longitude", String.valueOf(longitude));
                            gpsObj.put("address", addressArr[0]);
                            if (is) {
                                gpsResult.put("afterEventName", gpsParam != null && gpsParam.has("afterEventName") ? gpsParam.getString("afterEventName") : "");
                            } else {
                                String message;
                                //status.put("error", errType);
                                switch (errType) {
                                    case ERROR_MOCK_PROVIDER:
                                        message = getString(R.string.mocked_location);
                                        break;
                                    case ERROR_GPS_OFF:
                                        message = getString(R.string.gps_off);
                                        break;
                                    case ERROR_NO_PRECISION:
                                        message = getString(R.string.no_precision);
                                        break;
                                    default:
                                        message = errType;
                                        break;
                                }
                                status.put("message", message);
                                gpsObj.put("afterEventName", gpsParam != null && gpsParam.has("afterEventName") ? gpsParam.getString("afterEventName") : "");
                            }
                            gpsResult.put("status", status);
                            gpsResult.put("data", gpsObj);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        webView.loadUrl("javascript: "+ gpsFunction +"(\"" + id + "\", " + gpsResult.toString() +  ")");

                    }
                }
            };

           if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
               this.gpsResult = gpsResult;
               this.isGPSAccurate = isAccurate;
               if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                   gpsResult.OnGPSReturnVal(0, 0, false, ERROR_NO_PERMISSION);
                   linkToSetting(isAccurate);
               } else {
                   locationPermissionRequest.launch(new String[] {
                           Manifest.permission.ACCESS_FINE_LOCATION,
                           Manifest.permission.ACCESS_COARSE_LOCATION
                   });
               }
           } else if (!isAccurate || ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
               //GPSTracker gps = new GPSTracker(getActivity(), gpsResult);
               //gps.getGPSLocation();
               turnOnGps(gpsResult, isAccurate);
           } else {
               this.gpsResult = gpsResult;
               this.isGPSAccurate = isAccurate;
               if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                   gpsResult.OnGPSReturnVal(0, 0, false, ERROR_NO_PRECISION);
                   linkToSetting(isAccurate);
               } else {
                   locationPermissionRequest.launch(new String[] {
                           Manifest.permission.ACCESS_FINE_LOCATION
                   });
               }
           }
        }
    }

    private void loadbarcode(JSONObject param, JSONObject callback, String id) throws JSONException {
        if (callback != null && callback.has("function")) {
            final String scnrFunction = callback.getString("function");
            final String afterEventName = param != null && param.has("afterEventName") ? param.getString("afterEventName") : null;
            String options = param != null && param.has("options") ? param.getString("options") : null;
            boolean isMulti;
            try {
                JSONObject eventAfterObj = new JSONObject(afterEventName);
                isMulti = eventAfterObj.has("ismulti") ? eventAfterObj.getBoolean("ismulti") : false;
            } catch (JSONException e) {
                isMulti = false;
            }
            int height = 0;
            int width = 0;
            boolean isHeightPer = false;
            boolean isWidthPer = false;
            boolean closeBtnOnVideo = false;
            boolean isQR = false;
            boolean isUserFacing = false;
            if (options != null) {
                try {
                    JSONObject optionsObj = new JSONObject(options);
                    if (optionsObj.has("maxHeight")) {
                        Object maxHeight = optionsObj.get("maxHeight");
                        if (maxHeight instanceof String) {
                            String heightStr = maxHeight.toString().toLowerCase();
                            if (heightStr.endsWith("px")) {
                                heightStr = heightStr.substring(0, heightStr.length() - 2);
                                height = Integer.parseInt(heightStr);
                            } else if (heightStr.endsWith("%")) {
                                heightStr = heightStr.substring(0, heightStr.length() - 1);
                                height = Integer.parseInt(heightStr);
                                isHeightPer = true;
                            }
                        } else if (maxHeight instanceof Number) {
                            height = (int) maxHeight;
                        }
                    }
                    if (optionsObj.has("maxWidth")) {
                        Object maxWidth = optionsObj.get("maxWidth");
                        if (maxWidth instanceof String) {
                            String widthStr = maxWidth.toString().toLowerCase();
                            if (widthStr.endsWith("px")) {
                                widthStr = widthStr.substring(0, widthStr.length() - 2);
                                width = Integer.parseInt(widthStr);
                            } else if (widthStr.endsWith("%")) {
                                widthStr = widthStr.substring(0, widthStr.length() - 1);
                                width = Integer.parseInt(widthStr);
                                isWidthPer = true;
                            }
                        } else if (maxWidth instanceof Number) {
                            width = (int) maxWidth;
                        }
                    }
                    if (optionsObj.has("closeBtnOnVideo")) {
                        closeBtnOnVideo = optionsObj.getBoolean("closeBtnOnVideo");
                    }
                    if (optionsObj.has("isQR")) {
                        isQR = optionsObj.getBoolean("isQR");
                    }
                    if (optionsObj.has("facingMode")) {
                        Object facingMode = optionsObj.get("facingMode");
                        if (facingMode instanceof String) {
                            isUserFacing = facingMode.toString().equalsIgnoreCase("user");
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            scannerResult = new ScannerResult() {
                @Override
                public void OnScannerResult(boolean success, String code, String errMessage) {
                    if (scnrFunction != null) {
                        JSONObject scnrResult = new JSONObject();
                        try {
                            JSONObject status = new JSONObject();
                            status.put("succeed", success);
                            if (success) {
                                scnrResult.put("data", code);
                                scnrResult.put("afterEventName", afterEventName != null ? afterEventName : "");
                            } else {
                                status.put("message", errMessage);
                                JSONObject dataObj = new JSONObject();
                                dataObj.put("afterEventName", afterEventName != null ? afterEventName : "");
                                dataObj.put("options", options != null ? options : "");
                                scnrResult.put("data", dataObj);
                            }
                            scnrResult.put("status", status);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        webView.loadUrl("javascript: " + scnrFunction + "(\"" + id + "\", " + scnrResult.toString() + ")");

                    }
                }
            };
            Intent intent = new Intent(getActivity(), MLKitScanActivity.class);
            intent.putExtra("isMulti", isMulti);
            intent.putExtra("height", height);
            intent.putExtra("width", width);
            intent.putExtra("isHeightPer", isHeightPer);
            intent.putExtra("isWidthPer", isWidthPer);
            intent.putExtra("closeBtnOnVideo", closeBtnOnVideo);
            intent.putExtra("isQR", isQR);
            intent.putExtra("isUserFacing", isUserFacing);
            scannerActivityResaultLauncher.launch(intent);
        }
    }

    private void hideMSLoginContainer() {
        MSWebView.stopLoading();
        MSWebView.loadUrl("about:blank");
        MSContainer.setVisibility(View.GONE);
    }

    private void linkToSetting(boolean preciseNeeded) {
        Snackbar.make(webView, preciseNeeded ? R.string.no_precision : R.string.location_permission_info, Snackbar.LENGTH_INDEFINITE)
                .setAction(R.string.ui_setting_text, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent();
                        intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                        intent.setData(uri);
                        startActivity(intent);
                    }
                }).show();
    }

    private Uri createDownloadUri(Context context, String folderName, String fileName, String mimeType) {
        String uniqueName = buildUniqueFileName(context, folderName, fileName);
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, uniqueName);
        values.put(MediaStore.Downloads.MIME_TYPE, mimeType != null ? mimeType : "*/*");
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + folderName);

        Uri uri = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        }
        if (uri == null) {
            throw new IllegalStateException("MediaStore insert failed");
        }
        return uri;
    }

    private String getAppName(Context context) {
        try {
            CharSequence label = context.getPackageManager()
                    .getApplicationLabel(context.getApplicationInfo());
            String name = label != null ? label.toString() : "App";
            return name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        } catch (Exception e) {
            return "Flex";
        }
    }

    private boolean existsInDownloads(Context context, String folderName, String fileName) {
        Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;

        String relativePath = Environment.DIRECTORY_DOWNLOADS + "/" + folderName + "/";

        String[] projection = new String[]{ MediaStore.Downloads._ID };
        String selection = MediaStore.Downloads.RELATIVE_PATH + "=? AND " + MediaStore.Downloads.DISPLAY_NAME + "=?";
        String[] selectionArgs = new String[]{ relativePath, fileName };

        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(collection, projection, selection, selectionArgs, null);
            return cursor != null && cursor.moveToFirst();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private String buildUniqueFileName(Context context, String folderName, String originalName) {
        String base = originalName;
        String ext = "";

        int dot = originalName.lastIndexOf('.');
        if (dot > 0) {
            base = originalName.substring(0, dot);
            ext = originalName.substring(dot);
        }

        if (!existsInDownloads(context, folderName, originalName)) {
            return originalName;
        }

        int i = 1;
        while (true) {
            String candidate = base + "(" + i + ")" + ext;
            if (!existsInDownloads(context, folderName, candidate)) {
                return candidate;
            }
            i++;
        }
    }

    @Override
    public void onDestroy() {
        LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(codeBroadcastReceiver);
        super.onDestroy();
    }

    class CustomWebClientView extends WebViewClient {

        String startUrl;
        String errorUrl;

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Nullable
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return assetLoader.shouldInterceptRequest(request.getUrl());
        }

        @Override
        @SuppressWarnings("deprecation") // for API < 21
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            return assetLoader.shouldInterceptRequest(Uri.parse(url));
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return super.shouldOverrideUrlLoading(view, url);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (uri != null && uri.toString().startsWith("intent:")) {
                try {
                    Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                    if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                        startActivity(intent);
                    } else {
                        String fallbackUrl = intent.getStringExtra("browser_fallback_url");
                        if (fallbackUrl != null) {
                            view.loadUrl(fallbackUrl);
                        }
                    }
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (request.hasGesture() && uri != null && uri.toString().startsWith("http") && uri.getHost() != null && !uri.getHost().contains("flextudio.com")) {
                Intent viewIntent = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(viewIntent);
                    return true;
                } catch(ActivityNotFoundException e) {
                    e.printStackTrace();
                }
            }
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            startUrl = url;
            errorUrl = null;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            //super.onPageFinished(view, url);
            //startTimer();
            flushCookies();
            if (startUrl != null && !startUrl.equals(errorUrl)) {
                hideLoadingView();
            } else {
                webView.setVisibility(View.GONE);
            }
        }

        private void flushCookies() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                CookieManager.getInstance().flush();
            } else {
                CookieSyncManager.getInstance().sync();
            }
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            Uri url = request.getUrl();
            String path = url.getPath();
            handleError(url.toString(), path);
        }

        @Override
        @SuppressWarnings("deprecation") // for API < 21
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            try {
                String path = new URL(failingUrl).getPath();
                handleError(failingUrl, path);
            } catch (MalformedURLException e) {
                e.printStackTrace();
                super.onReceivedError(view, errorCode, description, failingUrl);
            }
        }

        private void handleError(String url, String path) {
            if (url.equals(startUrl)) {
                errorUrl = url;
                webView.evaluateJavascript("(function() { return !window.navigator.onLine && (typeof verificationObj === 'undefined' && typeof _interface === 'undefined' ? true : false); })();", new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String s) {
                        if (s.equals("true")) {
                            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
                            if (activeNetwork != null && activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                                webView.loadUrl("https://app.flextudio.com/assets/msgWifi.html");
                            } else {
                                webView.loadUrl("https://app.flextudio.com/assets/msgLTE.html");
                            }
                        } else {
                            hideLoadingView();
                            showFailMessage();
                        }
                    }
                });
            } else if (!path.equals("/favicon.ico")) {
                onDestroy();
//                showFailMessage();
            }
        }
    }

    public void webStatusBarColor(String hexString) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getActivity().getWindow().setStatusBarColor(Color.parseColor(hexString));
            }
            getView().setBackgroundColor(Color.parseColor(hexString));

        } catch (Exception e) {
            Log.i("WebStatusBarColor", e.getLocalizedMessage());
        }
    }

    public void webStatusBarColor(String hexString, String fontColor) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getActivity().getWindow().setStatusBarColor(Color.parseColor(hexString));
            }
//            getView().setBackgroundColor(Color.parseColor(hexString));

            if (fontColor.equals("black")) {
                getView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            } else if (fontColor.equals("white")) {
                getView().setSystemUiVisibility(0);
            }

        } catch (Exception e) {
            Log.i("WebStatusBarColor", e.getLocalizedMessage());
        }

    }

    public void openDrawer(boolean open) {
        DrawerLayout drawerLayout = getActivity().findViewById(R.id.drawer_layout);
        if (drawerLayout != null) {

            if (open) {
                drawerLayout.openDrawer(Gravity.LEFT);
            } else {
                drawerLayout.closeDrawer(Gravity.LEFT);
            }
        }
    }

    public String getDeviceipWiFiData() {
        android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getActivity().getApplicationContext().getSystemService(WIFI_SERVICE);
        @SuppressWarnings("deprecation")
        String ip = android.text.format.Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
        return ip;
    }

    private void startTimer() {
        if (scenarioLoadTimer == null) {
            scenarioLoadTimer = new CountDownTimer(5000, 5000) {

                @Override
                public void onTick(long l) {

                }

                @Override
                public void onFinish() {
                    scenarioLoadTimer = null;
                    if (loadingView.getVisibility() == View.VISIBLE) {
                        hideLoadingView();
                        showFailMessage();
                    }
                }
            }.start();
        } else {
            scenarioLoadTimer.cancel();
            scenarioLoadTimer.start();
        }
    }

    private void hideLoadingView() {
        webView.setVisibility(View.VISIBLE);
        loadingView.setVisibility(View.GONE);
        loadingContainer.setVisibility(View.GONE);
        if (scenarioLoadTimer != null) {
            scenarioLoadTimer.cancel();
            scenarioLoadTimer = null;
        }
    }

    private void showFailMessage() {
        final CommonYLWDialog dlg = new CommonYLWDialog(getActivity());
        final ResultPasserInterface rpInterface = new ResultPasserInterface() {
            @Override
            public void setResultValue(int resultValue) {
                if (webViewBack != null) {
                    webViewBack.onLoadScenarioFail();
                }
            }
        };
        dlg.setMessage(getString(kr.co.ksystem.companity.R.string.scanarioLoadFailed));
        dlg.setInterface(rpInterface);
        dlg.setMessageBoxType("MsgBoxTypeOK");
        dlg.setDialogCancelable(false);
        dlg.showDialog(getActivity());
    }

    private void turnOnGps(GPSTracker.GPSResult gpsResult, boolean isAccurate) {
        if (isAdded()) {
            new GPSUtil(getActivity()).turnGPSOn(gpsResult, isAccurate);
        }
    }

    private void getCurrentLocation(GPSTracker.GPSResult gpsResult, boolean isAccurate) {
        if (isAdded()) {
            FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());
            Task<Location> currentLocationTask = fusedLocationClient.getCurrentLocation(isAccurate ? LocationRequest.PRIORITY_HIGH_ACCURACY : LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY, cancellationTokenSource.getToken());
            currentLocationTask.addOnCompleteListener((@NonNull Task<Location> task) -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    if (task.getResult().isFromMockProvider()) {
                        gpsResult.OnGPSReturnVal(task.getResult().getLatitude(), task.getResult().getLongitude(), false, ERROR_MOCK_PROVIDER);
                    } else {
                        gpsResult.OnGPSReturnVal(task.getResult().getLatitude(), task.getResult().getLongitude(), true, null);
                    }
                } else {
                    gpsResult.OnGPSReturnVal(0, 0, false, ERROR_GPS);
                }
            });
        }
    }

    public void bluetoothPermission() {
        boolean hasFineLocationPerm = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { // Android 12 and above
            boolean hasBtPerm = hasBluetoothPermissions();
            if (!hasBtPerm || !hasFineLocationPerm) {
                if (shouldShowsBluetoothRationale()) {
                    Snackbar.make(webView, R.string.bluetooth_permission_info, Snackbar.LENGTH_INDEFINITE)
                            .setAction(R.string.ok, new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent();
                                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                                    intent.setData(uri);
                                    startActivity(intent);
                                }
                            }).show();
                } else {
                    btPermissionReq.launch(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION });
                }
            } else {
                bluetoothTurnOn();
            }
        } else {
            if (!hasFineLocationPerm) {
                if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    Snackbar.make(webView, R.string.location_permission_info, Snackbar.LENGTH_INDEFINITE)
                            .setAction(R.string.ok, new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent();
                                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                    Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                                    intent.setData(uri);
                                    startActivity(intent);
                                }
                            }).show();
                } else {
                    btPermissionReq.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
                }
            } else {
                bluetoothTurnOn();
            }
        }
    }

    public void bluetoothTurnOn() {
        BluetoothManager bluetoothManager = getContext().getSystemService(BluetoothManager.class);
        //BluetoothAdapter.getDefaultAdapter();
        bluetoothAdapter = bluetoothManager.getAdapter();
        if (bluetoothAdapter == null) {
            // Device doesn't support Bluetooth
            if (bluetoothReqObj != null) {
                try {
                    JSONObject callback = bluetoothReqObj.getJSONObject("callback");
                    String interfaceFunc = callback.getString("function");
                    String errMsg = getString(R.string.no_bluetooth);
                    JSONObject param = bluetoothReqObj.getJSONObject("param");
                    String interfaceID = param.getString("interface");
                    sendBtError(interfaceID, interfaceFunc, errMsg);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                bluetoothReqObj = null;
            }
        } else if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            turnOnBluetoothLauncher.launch(enableBtIntent);
        } else if (bluetoothReqObj != null) {
            processBtRequest();
        }
    }

    public void processBtRequest() {
        try {
            JSONObject callback = bluetoothReqObj.getJSONObject("callback");
            String interfaceFunc = callback.getString("function");
            String action = bluetoothReqObj.getString("action");
            String interfaceName = null;
            JSONObject param = null;
            if (bluetoothReqObj.has("param")) {
                param = bluetoothReqObj.getJSONObject("param");
                if (param.has("interface")) {
                    interfaceName = param.getString("interface");
                }
            }
            if (interfaceName == null) {
                Log.e("processBtRequest", "interface param missing");
                bluetoothReqObj = null;
                return;
            }
            BluetoothHelper bluetoothHelper;
            if (bluetoothHelperMap.containsKey(interfaceName)) {
               bluetoothHelper = bluetoothHelperMap.get(interfaceName);
            } else {
                bluetoothHelper = new BluetoothHelper(getActivity(), bluetoothResults, interfaceName);
                bluetoothHelperMap.put(interfaceName, bluetoothHelper);
            }
            if ("getDeviceList".contains(action)) {
                bluetoothHelper.bluetoothSearch(interfaceFunc);
            } else if ("connectToDevice".equals(action)) {
                String deviceAddr = null;
                if (param.has("address")) {
                    deviceAddr = param.getString("address");
                }
                if (deviceAddr == null) {
                    String errMsg = "device address missing";
                    sendBtError(interfaceName, interfaceFunc, errMsg);
                } else {
                    String receiveMessage = null;
                    if (param.has("receiveMessage")) {
                        receiveMessage = param.getString("receiveMessage");
                    }
                    bluetoothHelper.connect(deviceAddr, interfaceFunc, receiveMessage);
                }
            }
            bluetoothReqObj = null;
            //String errMsg = getString(R.string.no_bluetooth);
            //sendBtError(interfaceFunc, errMsg);
        } catch (JSONException e) {
            bluetoothReqObj = null;
            e.printStackTrace();
        }
    }

    private boolean hasBluetoothPermissions() {
        return ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }
    private boolean shouldShowsBluetoothRationale() {
        return shouldShowRequestPermissionRationale(Manifest.permission.BLUETOOTH_SCAN)
                || shouldShowRequestPermissionRationale(Manifest.permission.BLUETOOTH_CONNECT)
                || shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private String getAndroidId(Context context) {
        //SAId: Secure Android Id
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    @Override
    public void onDestroyView() {
        //stopBluetoothDiscovery(getActivity());
        super.onDestroyView();
    }
    @Override
    public void canMoveBack(boolean moveBack) {
        if (moveBack) {
            webView.loadUrl("javascript: moveToBackStep('back');");
        } else if (webViewBack != null) {
            webViewBack.onWebViewBackPressed();
        }
    }

    public void moveToBackStep() {
        if (MSContainer.getVisibility() == View.VISIBLE) {
            hideMSLoginContainer();
            return;
        }
        webView.evaluateJavascript("(function() { return (typeof onBackPressed === \"function\"); })();", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String s) {
                if (s.equals("false")) {
                    canMoveBack(false);
                } else {
                    webView.loadUrl(("javascript: onBackPressed();"));
                }
            }
        });
    }

    public boolean canGoBack() {
        return webView.canGoBack();
    }

    @Override
    public void onResume() {
        super.onResume();
        webView.loadUrl("javascript: onForeground();");
        if (nfcAdapter != null && pendingIntent!=null) {
            nfcAdapter.enableForegroundDispatch(getActivity(), pendingIntent, intentFiltersArray, techListsArray);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        webView.loadUrl("javascript: onBackground();");
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(getActivity());
        }
    }

    public void onNewIntent(Intent intent) {
        //super.onActivityResult(getTargetRequestCode(), getActivity().RESULT_OK, intent);
        String action = intent.getAction();
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_TECH_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)) {
            Tag tag;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag.class);
            } else {
                tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            }
            if (tag != null) {
                String tagId = bytesToHex(tag.getId());
                Log.d("NFC_TAG", "Tag ID: " + tagId);
                // Get the NDEF instance for the tag
                Ndef ndef = Ndef.get(tag);
                if (ndef != null) {
                    // Get the NDEF message from the tag
                    NdefMessage ndefMessage = ndef.getCachedNdefMessage();

                    if (ndefMessage != null) {
                        JSONArray recordList = new JSONArray();
                        // Process each NDEF record in the message
                        for (NdefRecord ndefRecord : ndefMessage.getRecords()) {
                            short tnf = ndefRecord.getTnf();
                            if (tnf == NdefRecord.TNF_WELL_KNOWN) {
                                // If the NDEF record is of well-known type and is a text record
                                String message;
                                if (Arrays.equals(ndefRecord.getType(), NdefRecord.RTD_TEXT)) {
                                    message = getTextFromNdefRecord(ndefRecord);
                                } else if (Arrays.equals(ndefRecord.getType(), NdefRecord.RTD_URI)){
                                    message = ndefRecord.toUri().toString();
                                } else {
                                    byte[] payload = ndefRecord.getPayload();
                                    message = new String(payload, ((payload[0] & 0x80) == 0) ? StandardCharsets.UTF_8 : StandardCharsets.UTF_16);
                                }
                                //Log.d("NFC_TAG", "NDEF Message: " + message);
                                recordList.put(message);
                            } else if (tnf == NdefRecord.TNF_ABSOLUTE_URI) {
                                // Handle Absolute URI records
                                String uri = new String(ndefRecord.getPayload(), StandardCharsets.UTF_8);
                                //Log.d("NFC_TAG", "Absolute URI: " + uri);
                                recordList.put(uri);
                            } else if (tnf == NdefRecord.TNF_MIME_MEDIA) {
                                // Handle MIME Media records
                                String mimeType = new String(ndefRecord.getType(), StandardCharsets.UTF_8);
                                //byte[] payload = ndefRecord.getPayload();
                                //Log.d("NFC_TAG", "MIME Type: " + mimeType);
                                //Log.d("NFC_TAG", "Payload: " + Arrays.toString(payload));
                                // Additional handling based on MIME type
                                recordList.put("media: "+mimeType);
                            } else {
                                recordList.put("unsupported: "+ndefRecord.describeContents());
                            }
                        }
                        String runJS = "javascript: " + nfcCallbackFunc + "(null, " +recordList.toString()+ ")";
                        webView.loadUrl(runJS);
                    } else {
                        String runJS = "javascript: " + nfcCallbackFunc + "('" +"No NDEF messages found on this tag."+ "')";
                        webView.loadUrl(runJS);
                    }
                } else {
                    String runJS = "javascript: " + nfcCallbackFunc + "('" +"Tag is not NDEF formatted."+ "')";
                    webView.loadUrl(runJS);
                }
            } else {
                String runJS = "javascript: " + nfcCallbackFunc + "('" +"Tag is null."+ "')";
                webView.loadUrl(runJS);
            }
            pendingIntent = null;
            nfcAdapter = null;
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

private String getTextFromNdefRecord(NdefRecord ndefRecord) {
    try {
        byte[] payload = ndefRecord.getPayload();

        // Get the Text Encoding
        String textEncoding = ((payload[0] & 0x80) == 0) ? "UTF-8" : "UTF-16";

        // Get the Language Code
        int languageCodeLength = payload[0] & 0x3F;
        String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");

        // Get the Text
        return new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);
    } catch (UnsupportedEncodingException e) {
        Log.e("NFC_TAG", "Unsupported Encoding", e);
        return null;
    }
}


@Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GPS_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {
                getCurrentLocation(gpsResult, isGPSAccurate);
            } else {
                gpsResult.OnGPSReturnVal(0, 0, false, ERROR_GPS_OFF);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (requestCode != INPUT_FILE_REQUEST_CODE || mFilePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            // Check that the response is a good one
            if (resultCode == Activity.RESULT_OK) {
                if (data == null) {
                    // If there is not data, then we may have taken a photo
                    if (mCameraPhotoPath != null) {
                        results = new Uri[]{Uri.parse(mCameraPhotoPath)};
                        MediaScannerConnection.scanFile(getContext(), new String[]{mCurrentPhotoAbsolutePath}, null, null);
                    }
                } else {
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                    if (mCurrentPhotoAbsolutePath != null) {
                        File fileToDelete = new File(mCurrentPhotoAbsolutePath);
                        if (fileToDelete.exists()){
                            fileToDelete.delete();
                        }
                    }
                }
            } else if (mCurrentPhotoAbsolutePath != null) {
                File fileToDelete = new File(mCurrentPhotoAbsolutePath);
                if (fileToDelete.exists()){
                    fileToDelete.delete();
                }
            }
            if (mFilePathCallback != null) {
                mFilePathCallback.onReceiveValue(results);
                mFilePathCallback = null;
            }
        } else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
            if (requestCode != FILECHOOSER_RESULTCODE || mUploadMessage == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            if (requestCode == FILECHOOSER_RESULTCODE) {
                if (null == this.mUploadMessage) {
                    return;
                }
                Uri result = null;
                try {
                    if (resultCode != RESULT_OK) {
                        result = null;
                    } else {
                        // retrieve from the private variable if the intent is null
                        result = data == null ? mCapturedImageURI : data.getData();
                    }
                } catch (Exception e) {
                    Toast.makeText(getContext(), "activity :" + e,
                            Toast.LENGTH_LONG).show();
                }
                mUploadMessage.onReceiveValue(result);
                mUploadMessage = null;
            }
        }
        return;
    }

    public interface WebViewBack {
        void onWebViewBackPressed();
        void onLoadScenarioFail();
        void onWebLogout();
        void onWebNoSession();
    }

    public interface CustomAuthListener {
        void onAuthTokenRequest(FlexFragment flexFragment);
    }

    public interface PassResultToWeb {
        void onResult(String error, String result);
    }

    class WebInterfaceDownload extends AsyncTask<String, String, String> {
        private DownloadResult downloadResult;
        private Uri uri;

        WebInterfaceDownload(DownloadResult downloadResult, Uri uri) {
            this.downloadResult = downloadResult;
            this.uri = uri;
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                String serviceURL = strings[0], bis = strings[1], filepath = strings[2];
                String fileurl_str = serviceURL + "/FlexSvc/api/FileDownload";
                String get_param = "?SessionId="+BaseUserValue.SESSION_ID+"&ServerId="+bis+"&FileFullPath="+filepath;
                //get_param = URLEncoder.encode(get_param, "UTF-8");
                fileurl_str = fileurl_str + get_param;
                BufferedInputStream inputStream = new BufferedInputStream(new URL(fileurl_str).openStream());
                OutputStream os = getContext().getContentResolver().openOutputStream(uri);

                if (os != null) {
                    byte[] data = new byte[1024];
                    int byteContent;
                    while ((byteContent = inputStream.read(data, 0, 1024)) != -1) {
                        os.write(data, 0, byteContent);
                    }
                    os.flush();
                    os.close();
                }
                inputStream.close();
                // update external storage dir as required for api level 29+
                /*File root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File targetFile = new File(root, filename);
                //create new file if name already exists
                if  (targetFile.exists()) {
                    filename =  "01" + filename;
                    targetFile = new File(root, filename);
                }
                FileOutputStream fileOS = new FileOutputStream(targetFile);
                byte data[] = new byte[1024];
                int byteContent;
                while ((byteContent = inputStream.read(data, 0, 1024)) != -1) {
                    fileOS.write(data, 0, byteContent);
                }*/
                return "Success";
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                return e.getMessage();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                return e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                return e.getMessage();
            } catch (Exception e) {
                e.printStackTrace();
                return e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String s) {
            //super.onPostExecute(s);
            if ("Success".equals(s)) {
                downloadResult.onSuccess();
            } else {
                downloadResult.onError(s);
            }
        }
    }

    public void deleteFileFromContentUri(Context context, Uri contentUri) {
        try {
            DocumentsContract.deleteDocument(context.getContentResolver(), contentUri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    class S3Downloader {
        JSONArray partPositions;
        Uri uri;
        Context context;
        String contentType;
        int totalParts = 0;
        int pendingDownloads = 0;
        int addedIndex = -1;
        JSONArray ranges;
        JSONArray downloadUrls;
        String key;
        String function;
        Handler handler = new Handler(Looper.getMainLooper());
        int threadPoolSize = 0;
        ExecutorService rangeExecutor;

        public S3Downloader(JSONArray downloadUrls, JSONArray partPositions, int parallelDownloadCount, String function, String contentType, Uri uri, Context context) {
            this.partPositions = partPositions;
            this.downloadUrls = downloadUrls;
            this.function = function;
            this.contentType = contentType;
            this.uri = uri;
            this.context = context;
            totalParts = partPositions.length();
            pendingDownloads = totalParts;
            addedIndex = Math.min(totalParts, parallelDownloadCount);
            try {
                for (int i = 0; i < addedIndex; i++) {
                    String url = downloadUrls.getString(i);
                    partDownload(url, i, 0);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public S3Downloader(String key, JSONArray ranges, JSONArray partPositions, int parallelDownloadCount, String function, String contentType, Uri uri, Context context) {
            this.partPositions = partPositions;
            this.ranges = ranges;
            this.key = key;
            this.function = function;
            this.contentType = contentType;
            this.uri = uri;
            this.context = context;
            totalParts = partPositions.length();
            pendingDownloads = totalParts;
            addedIndex = Math.min(totalParts, parallelDownloadCount);
            threadPoolSize = Math.min(addedIndex, 5); // Based on OkHttp, maxRequestsPerHost is set to 5, the maximum value.
            this.rangeExecutor = Executors.newFixedThreadPool(threadPoolSize);
            try {
                for (int i = 0; i< addedIndex; i++) {
                    String range = ranges.getString(i);
                    RangeDownload rd = new RangeDownload(i);
                    rd.executeOnExecutor(rangeExecutor, key, range);
//                    rd.execute(key, range);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        private void openFile() {
            if (function!=null) {
                webView.loadUrl("javascript: " + function + "(true)");
            }
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, contentType != null && contentType != "null" ? contentType : "*/*");
            // Set the flags for permissions
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            // Take persistable URI permissions
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                final int takeFlags = (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                context.getContentResolver().takePersistableUriPermission(uri, takeFlags);
            }
            PackageManager packageManager = getActivity().getPackageManager();
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent);
            } else {
                Toast.makeText(getActivity(), R.string.no_app_for_file, Toast.LENGTH_SHORT).show();
            }
        }

        private void sendError() {
            if (function!=null) {
                webView.loadUrl("javascript: " + function + "(false,'"+"Download failed"+"')");
            }
        }

        private void partDownload(String url, int part, int retryCount) {
            Executors.newSingleThreadExecutor().execute(() -> {
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("https://s3.ap-northeast-2.amazonaws.com/")
                        .build();
                FileDownloadService fdsApi = retrofit.create(FileDownloadService.class);
                int bufferSize = 1024*4;
                Call<ResponseBody> call = fdsApi.downloadFileWithDynamicUrlSync(url);
                try {
                    Response<ResponseBody> response = call.execute();
                    ResponseBody responseBody = response.body();
                    if (responseBody == null) {
                        failed(retryCount, part);
                        return;
                    }
                    BufferedInputStream inputStream = new BufferedInputStream(responseBody.byteStream(), bufferSize);
                    writeAtPositionFromStream(context, uri, inputStream, partPositions.getInt(part), bufferSize);
                    handler.post(() -> {
                        pendingDownloads--;
                        if (pendingDownloads == 0) {
                            S3Downloader.this.openFile();
                        } else if (addedIndex < totalParts) {
                            try {
                                partDownload(downloadUrls.getString(addedIndex), addedIndex, 0);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                if (totalParts > 0) {
                                    totalParts = 0;
                                    sendError();
                                    FlexFragment.this.deleteFileFromContentUri(context, uri);
                                }
                            }
                            addedIndex++;
                        }
                    });
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    failed(retryCount, part);
                } catch (IOException e) {
                    e.printStackTrace();
                    failed(retryCount, part);
                } catch (JSONException e) {
                    e.printStackTrace();
                    failed(retryCount, part);
                }
            });
        }

        public void writeAtPositionFromStream(Context context, Uri uri, BufferedInputStream inputStream, long position, int bufferSize)  throws IOException {
            boolean success = true;
            ParcelFileDescriptor pfd = null;
            FileChannel fileChannel = null;
            try {
                pfd = context.getContentResolver().openFileDescriptor(uri, "rw");
                if (pfd != null) {
                    fileChannel = new FileOutputStream(pfd.getFileDescriptor()).getChannel();
                    fileChannel.position(position);
                    // ByteBuffer for incremental reading and writing
                    ByteBuffer buffer = ByteBuffer.allocate(bufferSize);
                    int bytesRead;
                    byte[] data = new byte[bufferSize];
                    while ((bytesRead = inputStream.read(data)) != -1) {
                        buffer.clear(); // Prepare the buffer to be written
                        buffer.put(data, 0, bytesRead); // Fill the buffer with data
                        buffer.flip(); // Flip the buffer to prepare it for writing
                        while (buffer.hasRemaining()) {
                            fileChannel.write(buffer); // Write data to file
                        }
                    }
                }
            } catch (IOException e) {
                throw e;
            } finally {
                try {
                    if (fileChannel != null) {
                        fileChannel.close();
                    }
                    if (pfd != null) {
                        pfd.close();
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (IOException e) {
                    throw e;
                }
            }
        }

        private void failed(int retryCount, int part) {
            if (retryCount < 4) {
                retryCount++;
                try {
                    partDownload(downloadUrls.getString(part), part, retryCount);
                } catch (JSONException e) {
                    totalParts = 0;
                    sendError();
                    FlexFragment.this.deleteFileFromContentUri(context, uri);
                    e.printStackTrace();
                }
            } else if (totalParts > 0) {
                totalParts = 0;
                sendError();
                FlexFragment.this.deleteFileFromContentUri(context, uri);
            }
        }

        class RangeDownload extends AsyncTask<String, String, Boolean> {
            int part;
            int retryCount;
            public RangeDownload(int part) {
                this.part = part;
            }
            public RangeDownload(int part, int retryCount) {
                this.part = part;
                this.retryCount = retryCount;
            }
            @Override
            protected Boolean doInBackground(String... strings) {
                String range = strings[1];
                String key = strings[0];
                try {
                    URL url = new URL("https://service.flextudio.com/flexfile/downloadRange");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setUseCaches(false);
                    JSONObject params = new JSONObject();
                    params.put("range", range);
                    params.put("key", key);
                    try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
                        dos.writeBytes(params.toString());
                    }
                    StringBuilder result = new StringBuilder();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    if (totalParts == 0) {
                        return false;
                    }
                    String line;
                    while ((line = rd.readLine()) != null) {
                        result.append(line+ "\n");
                    }
                    rd.close();
                    JSONObject resultJson = new JSONObject(result.toString());
                    byte[] decoded = Base64.decode(resultJson.getString("data"), Base64.DEFAULT);
                    return writeAtPosition(decoded, partPositions.getInt(part));
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    return false;
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return false;
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }

            @Override
            protected void onPostExecute(Boolean aBoolean) {
                super.onPostExecute(aBoolean);
                if (aBoolean) {
                    pendingDownloads--;
                    if (pendingDownloads == 0) {
                        shutdownRangeExecutor();
                        S3Downloader.this.openFile();
                    } else if (addedIndex < totalParts) {
                        RangeDownload rd = new RangeDownload(addedIndex);
                        try {
//                            rd.execute(key, ranges.getString(addedIndex));
                            rd.executeOnExecutor(rangeExecutor, key, ranges.getString(addedIndex));
                        } catch (JSONException e) {
                            shutdownRangeExecutor();
                            e.printStackTrace();
                        }
                        addedIndex++;
                    }
                } else {
                    if (retryCount < 4) {
                        retryCount++;
                        RangeDownload rd = new RangeDownload(part, retryCount);
                        try {
                            rd.execute(key, ranges.getString(part));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else if (totalParts > 0) {
                        totalParts = 0;
                        sendError();
                        FlexFragment.this.deleteFileFromContentUri(context, uri);
                    }
                }
            }

            public boolean writeAtPosition(byte[] data, long position) {
                boolean success = true;
                ParcelFileDescriptor pfd = null;
                FileChannel fileChannel = null;
                try {
                    pfd = context.getContentResolver().openFileDescriptor(uri, "rw");
                    if (pfd != null) {
                        fileChannel = new FileOutputStream(pfd.getFileDescriptor()).getChannel();
                        fileChannel.position(position);
                        fileChannel.write(ByteBuffer.wrap(data));
                    }
                } catch (IOException e) {
                    success = false;
                } finally {
                    try {
                        if (fileChannel != null) {
                            fileChannel.close();
                        }
                        if (pfd != null) {
                            pfd.close();
                        }
                    } catch (IOException e) {
                        success  = false;
                    }
                    return success;
                }
            }
        }

        private void shutdownRangeExecutor() {
            if (rangeExecutor != null && !rangeExecutor.isShutdown()) {
                rangeExecutor.shutdownNow();
            }
        }

    }

    interface DownloadResult {
        void onSuccess();
        void onError(String error);
    }

    class ChromeClient extends WebChromeClient {
        public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
            if (mFilePathCallback != null && mFilePathCallback != filePathCallback) {
                mFilePathCallback.onReceiveValue(null);
            }
            mFilePathCallback = filePathCallback;
            mFileChooserParams = fileChooserParams;
            if (hasCameraPermission()) {
                return fileCameraChooser(mFileChooserParams, true);
            }
            return true;
    }

         @Override
         public void onPermissionRequest(PermissionRequest request) {
             boolean audioCapture = false;
             for (String res : request.getResources()) {
                 if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) {
                     audioCapture = true;
                     break;
                 }
             }
             if (audioCapture) {
                 if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                     request.grant(request.getResources());
                 } else if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                     Snackbar.make(webView, R.string.audio_record_permission_info, Snackbar.LENGTH_INDEFINITE)
                             .setAction(R.string.ok, new View.OnClickListener() {
                                 @Override
                                 public void onClick(View view) {
                                     Intent intent = new Intent();
                                     intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                     Uri uri = Uri.fromParts("package", getActivity().getPackageName(), null);
                                     intent.setData(uri);
                                     startActivity(intent);
                                 }
                             }).show();
                 } else {
                     wkAudioRequest = request;
                     micPermissionReq.launch(new String[]{ Manifest.permission.RECORD_AUDIO });
                 }

             } else {
                 request.deny();
             }
         }
     }

    private boolean fileCameraChooser(WebChromeClient.FileChooserParams fileChooserParams, boolean showCamera) {
        Intent intentCamera = null;
        if (showCamera) {
            File path = new File(getContext().getExternalCacheDir(), "camera");
            if (!path.exists()) {
                path.mkdirs();
            }
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
            String currentTimeStamp = dateFormat.format(new Date());
            File file = new File(path, "capture_" + currentTimeStamp + ".png");
            intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            Uri cameraImageUri = FileProvider.getUriForFile(getContext(), getContext().getApplicationContext().getPackageName() + ".fileprovider", file);
            mCameraPhotoPath = cameraImageUri+"";
            mCurrentPhotoAbsolutePath = file.getAbsolutePath();
            intentCamera.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
        }

        String[] acceptTypes = fileChooserParams != null ? fileChooserParams.getAcceptTypes() : new String[]{ "*/*" };
        String mimeType = "*/*";
        if (acceptTypes != null && acceptTypes.length > 0 && acceptTypes[0] != null && !acceptTypes[0].isEmpty()) {
            mimeType = acceptTypes[0];
            if (mimeType.equals("*")) mimeType = "*/*";
        }
        Intent baseIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        baseIntent.addCategory(Intent.CATEGORY_OPENABLE);
        baseIntent.setType(mimeType);

        Intent intentFileExplorer = new Intent(Intent.ACTION_GET_CONTENT);
        intentFileExplorer.addCategory(Intent.CATEGORY_OPENABLE);
        intentFileExplorer.setType(mimeType);
        if (fileChooserParams != null && fileChooserParams.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
            baseIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            intentFileExplorer.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }

        Intent chooserIntent = Intent.createChooser(baseIntent, "파일을 가져올 방법을 선택하세요.");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentCamera == null ? new Parcelable[]{intentFileExplorer} : new Parcelable[]{intentCamera, intentFileExplorer});

        try {
            fileChooserActivityResultLauncher.launch(chooserIntent);
            return true;
        } catch (ActivityNotFoundException e) {
            mFilePathCallback = null;
            mFileChooserParams = null;
            Toast.makeText(getContext(), "Cannot Open File Chooser", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    class GPSUtil {
        private Context context;
        private SettingsClient mSettingsClient;
        private LocationSettingsRequest mLocationSettingsRequest;
        private LocationManager locationManager;
        private LocationRequest locationRequest;

        public GPSUtil(Context context) {
            this.context = context;
            locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            mSettingsClient = LocationServices.getSettingsClient(context);
        }

        // method for turn on GPS
        public void turnGPSOn(GPSTracker.GPSResult gpsResult, boolean isAccurate) {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                getCurrentLocation(gpsResult, isAccurate);
            } else {
                locationRequest = LocationRequest.create();
                locationRequest.setPriority(isAccurate ? LocationRequest.PRIORITY_HIGH_ACCURACY : LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
                locationRequest.setInterval((isAccurate ? 10 : 5) * 1000);
                locationRequest.setFastestInterval((isAccurate ? 2 : 1) * 1000);
                LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                        .addLocationRequest(locationRequest);
                mLocationSettingsRequest = builder.build();
                builder.setAlwaysShow(true);
                mSettingsClient.checkLocationSettings(mLocationSettingsRequest)
                        .addOnSuccessListener((Activity) context, new OnSuccessListener<LocationSettingsResponse>() {
                            @SuppressLint("MissingPermission")
                            @Override
                            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                                //  GPS is already enable
                                getCurrentLocation(gpsResult, isAccurate);
                            }
                        })
                        .addOnFailureListener((Activity) context, new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                int statusCode = ((ApiException) e).getStatusCode();
                                switch (statusCode) {
                                    case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                        try {
                                            // Show the dialog by calling startResolutionForResult(), and check the
                                            // result in onActivityResult().
                                            ResolvableApiException rae = (ResolvableApiException) e;
                                            FlexFragment.this.gpsResult = gpsResult;
                                            FlexFragment.this.isGPSAccurate = isAccurate;
                                            FlexFragment.this.startIntentSenderForResult(rae.getResolution().getIntentSender(), GPS_REQUEST, null, 0, 0, 0, null);

                                        } catch (IntentSender.SendIntentException sie) {
                                            Log.i(TAG, "PendingIntent unable to execute request.");
                                            gpsResult.OnGPSReturnVal(0, 0, false, ERROR_GPS_OFF);
                                        }
                                        break;
                                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                    default:
                                        Log.e(TAG, "Location settings are inadequate, and cannot be fixed here. Fix in Settings.");
                                        gpsResult.OnGPSReturnVal(0, 0, false, ERROR_GPS_OFF);
                                }
                            }
                        });
            }
        }
    }

    public interface ScannerResult {
        public void OnScannerResult(boolean success, String code, String errMessage);

    }

    private static class FileSession {
        final Uri uri;
        final ParcelFileDescriptor pfd;
        final FileOutputStream out;
        FileSession(Uri uri, ParcelFileDescriptor pfd, FileOutputStream out) {
            this.uri = uri;
            this.pfd = pfd;
            this.out = out;
        }
    }
}
