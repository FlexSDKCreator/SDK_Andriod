package kr.co.ksystem.companity.controls;

import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import androidx.annotation.Nullable;
import kr.co.ksystem.companity.R;

public class LoadingView extends View implements AnimatorUpdateListener {
	private int CURRENT_STARTING_INDEX = 0;
	Resources res = getContext().getResources();
	private int colorList[] = { res.getColor(R.color.ylw_loadingView_red), res.getColor(R.color.ylw_loadingView_green),
			res.getColor(R.color.ylw_loadingView_gray) };
	private Paint paint;
	private int nextIndex;
	private ValueAnimator anim;
	private float prevValue = 1;

	public LoadingView(Context context) {
		super(context);
		init();
	}

	public LoadingView(Context context, @Nullable AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public LoadingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		init();
	}

	public LoadingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
		super(context, attrs, defStyleAttr, defStyleRes);
		init();
	}

	private void init() {
		paint = new Paint();
		paint.setAntiAlias(true);
		paint.setStyle(Paint.Style.FILL);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		int displayWidth = getWidth();
		int displayHeight = getHeight();
		// center for central circle
		float centerX = displayWidth / 2;
		float centerY = displayHeight / 2;
		float radius = displayWidth / 7;
		// calculation for for 2nd circles of first and third row
		float sideX = (float) (((centerX - radius)) * 0.5); // multiplied by
															// value of cos60=
															// 0.5
		float sideY = (float) (((centerY - radius)) * 0.866); // value of sin60
																// = 0.866

		paint.setColor(colorList[2]);
		// draw central circle
		canvas.drawCircle(centerX, centerY, radius, paint);
		// first circle of first row
		paint.setColor(colorList[CURRENT_STARTING_INDEX]);
		canvas.drawCircle(-sideX + centerX, -sideY + centerY, radius, paint);
		// draw second circle of first row
		nextIndex = getNextIndex(CURRENT_STARTING_INDEX);
		paint.setColor(colorList[nextIndex]);
		canvas.drawCircle(sideX + centerX, -sideY + centerY, radius, paint);
		// 3rd circle of 2nd row
		nextIndex = getNextIndex(nextIndex);
		paint.setColor(colorList[nextIndex]);
		canvas.drawCircle(centerX + (centerX - radius), centerY, radius, paint);
		// 2nd circle of third row
		nextIndex = getNextIndex(nextIndex);
		paint.setColor(colorList[nextIndex]);
		canvas.drawCircle(sideX + centerX, sideY + centerY, radius, paint);
		// 1st circle of third row
		nextIndex = getNextIndex(nextIndex);
		paint.setColor(colorList[nextIndex]);
		canvas.drawCircle(-sideX + centerX, sideY + centerY, radius, paint);
		// 1st circle of 2nd row
		nextIndex = getNextIndex(nextIndex);
		paint.setColor(colorList[nextIndex]);
		canvas.drawCircle(centerX - (centerX - radius), centerY, radius, paint);

	}// end of onDraw() method

	private int getNextIndex(int index) {
		if (index == 2)
			return 0;
		else
			return (index + 1);
	}

	@Override
	public void onAnimationUpdate(ValueAnimator animation) {

		float newValue = ((Float) animation.getAnimatedValue("translate"));
		if (newValue < prevValue) {
			CURRENT_STARTING_INDEX = getNextIndex(CURRENT_STARTING_INDEX);
			invalidate();
		}
		prevValue = newValue;
	}

	public void animateView() {
		if (anim != null) {
			anim.cancel();
		}
		PropertyValuesHolder translate = PropertyValuesHolder.ofFloat("translate", 0, 1);
		anim = ValueAnimator.ofPropertyValuesHolder(translate);
		anim.setInterpolator(new DecelerateInterpolator());
		anim.setRepeatCount(ValueAnimator.INFINITE);
		anim.setRepeatMode(ValueAnimator.RESTART);
		anim.setDuration(250);
		anim.addUpdateListener(this);
		anim.start();
	}

	public void stopAnimation() {
		if (anim != null) {
			anim.cancel();
		}
	}
}
