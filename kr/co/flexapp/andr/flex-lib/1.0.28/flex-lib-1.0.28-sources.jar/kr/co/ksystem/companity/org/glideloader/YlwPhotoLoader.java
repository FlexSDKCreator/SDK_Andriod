package kr.co.ksystem.companity.org.glideloader;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Priority;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.Key;
import com.bumptech.glide.load.Options;
import com.bumptech.glide.load.data.DataFetcher;
import com.bumptech.glide.load.model.ModelLoader;
import com.bumptech.glide.load.model.ModelLoaderFactory;
import com.bumptech.glide.load.model.MultiModelLoaderFactory;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.MessageDigest;

import kr.co.ksystem.companity.svc.base.BaseUserValue;
import kr.co.ksystem.companity.svc.consts.Const;

/**
 * Created by Subhaye on 27-Jun-18.
 */
public class YlwPhotoLoader implements ModelLoader<YlwPhotoDto, InputStream> {

    private static final String TAG = "YlwPhotoLoader";

    public static class Factory implements ModelLoaderFactory<YlwPhotoDto, InputStream> {

        @Override
        public ModelLoader<YlwPhotoDto, InputStream> build(MultiModelLoaderFactory factory) {
            return new YlwPhotoLoader();
        }

        @Override
        public void teardown() {
            // No-op
        }
    }

    @Nullable
    @Override
    public LoadData<InputStream> buildLoadData(@NonNull YlwPhotoDto ylwPhotoDto, int width, int height, @NonNull Options options) {
        return new LoadData<>(new YlwPhotoKey(ylwPhotoDto), new YlwPhotoFetcher(ylwPhotoDto));
    }

    @Override
    public boolean handles(@NonNull YlwPhotoDto ylwPhotoDto) {
        return true;
    }

    private static class YlwPhotoKey implements Key {

        private YlwPhotoDto mYlwPhotoDto;

        public YlwPhotoKey(YlwPhotoDto ylwPhotoDto) {
            mYlwPhotoDto = ylwPhotoDto;
        }

        @Override
        public void updateDiskCacheKey(MessageDigest digest) {
            digest.update((mYlwPhotoDto.getCategory()+"_"+mYlwPhotoDto.getFileName()).getBytes(Charset.defaultCharset()));
        }
    }

    private static class YlwPhotoFetcher implements DataFetcher<InputStream> {

        private YlwPhotoDto mYlwPhotoDto;
        private InputStream mInputStream;

        public YlwPhotoFetcher(YlwPhotoDto ylwPhotoDto) {
            mYlwPhotoDto = ylwPhotoDto;
        }

        @Override
        public void loadData(@NonNull Priority priority, @NonNull DataCallback<? super InputStream> callback) {
            String serverPath= BaseUserValue.FileServerDir.replace("\\","\\\\");
            if (mYlwPhotoDto.getCategory().equals(Const.THUMB)) {
                serverPath += Const.FILESERVICE_ORG_THUMB_UPLOAD_PATH;
            } else if (mYlwPhotoDto.getCategory().equals(Const.PROFILE)) {
                serverPath += Const.FILESERVICE_ORG_PROFILE_UPLOAD_PATH;
            } else if (mYlwPhotoDto.getCategory().equals(Const.BACKGROUND)) {
                serverPath += Const.FILESERVICE_ORG_BACKGROUND_UPLOAD_PATH;
            }
            serverPath += File.separator + mYlwPhotoDto.getFileName();

            String fileData = "<FileData xmlns= 'MobileFileService'>";
            fileData += "<type>download</type>";
            fileData += "<path>" + serverPath + "</path>";
            fileData += "</FileData>";


            try {
                URL serverAddress = new URL(mYlwPhotoDto.getFileSvcUrl());
                HttpURLConnection connection = (HttpURLConnection) serverAddress.openConnection();
                connection.setDoOutput(true);
                connection.setDoInput(true);
                connection.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
                connection.setRequestMethod("POST");
                connection.getOutputStream().write(fileData.getBytes("UTF8"));
                connection.connect();
                int status = connection.getResponseCode();
                Log.d("Status line", "" + status);
                // 200 Success
                if (status == HttpURLConnection.HTTP_OK) {
                    mInputStream = connection.getInputStream();
                    callback.onDataReady(mInputStream);
                } else {
                    callback.onLoadFailed(new Exception("Status " + status));
                }
            } catch (MalformedURLException mex) {
                callback.onLoadFailed(mex);
            } catch (ProtocolException pe) {
                callback.onLoadFailed(pe);
            } catch (IOException ioe) {
                callback.onLoadFailed(ioe);
            }
        }

        @Override
        public void cleanup() {
            // Close stream if possible
            if (mInputStream != null) {
                try {
                    mInputStream.close();
                    mInputStream = null;
                } catch (IOException e) {
                    Log.w(TAG, "Could not close stream", e);
                }
            }
        }

        @Override
        public void cancel() {

        }

        @NonNull
        @Override
        public Class<InputStream> getDataClass() {
            return InputStream.class;
        }

        @NonNull
        @Override
        public DataSource getDataSource() {
            return DataSource.REMOTE;
        }
    }
}
