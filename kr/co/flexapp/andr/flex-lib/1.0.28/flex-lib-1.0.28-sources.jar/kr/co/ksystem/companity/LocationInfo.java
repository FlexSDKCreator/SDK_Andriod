package kr.co.ksystem.companity;

/**
 * Created by tn-acr-005 on 9/15/2017.
 */
import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;

/**
 * Created by tn-acr-005 on 4/25/2017.
 */

public class LocationInfo implements Serializable {

    private transient LatLng latLng;
    private String locality;
    private String addressLine;

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public LatLng getLatLng() {
        return latLng;
    }

    public void setLatLng(LatLng latLng) {
        this.latLng = latLng;
    }

    public String getAddressLine() {
        return addressLine;
    }

    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }


    @Override
    public String toString() {
        String location = getLocality() + "," + getAddressLine()+","+getLatLng().latitude+","+getLatLng().longitude;
        return location;
    }
}
