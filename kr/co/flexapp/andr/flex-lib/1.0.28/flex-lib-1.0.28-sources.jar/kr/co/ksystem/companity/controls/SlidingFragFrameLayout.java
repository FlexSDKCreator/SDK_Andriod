package kr.co.ksystem.companity.controls;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class SlidingFragFrameLayout extends FrameLayout {

	public SlidingFragFrameLayout(Context context) {
		super(context);
	}
	
	public SlidingFragFrameLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public SlidingFragFrameLayout(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	public void setXFraction(float fraction) {
		int width = getWidth();
		float translationX =  (width == 0? getResources().getDisplayMetrics().widthPixels : width) * fraction;
		setTranslationX(translationX);
	}

	public void setYFraction(float fraction) {
		int height = getHeight();
		float translationY =  (height == 0? getResources().getDisplayMetrics().heightPixels : height) * fraction;
        setTranslationY(translationY);
    }

}
