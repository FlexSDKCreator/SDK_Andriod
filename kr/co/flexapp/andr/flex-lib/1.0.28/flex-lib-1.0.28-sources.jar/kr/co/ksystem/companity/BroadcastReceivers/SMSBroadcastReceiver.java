package kr.co.ksystem.companity.BroadcastReceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;

import kr.co.ksystem.companity.consts.CompanityConstants;

public class SMSBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            Status status = (Status) extras.get(SmsRetriever.EXTRA_STATUS);

            switch(status.getStatusCode()) {
                case CommonStatusCodes.SUCCESS:
                    // Get SMS message contents
                    String message = (String) extras.get(SmsRetriever.EXTRA_SMS_MESSAGE);
                    Log.e("Sms Receiver", message);
                    // Extract one-time code from the message and complete verification
                    // by sending the code back to your server.
                    int codeIndex = message.indexOf("Code");
                    if (codeIndex != -1) {
                        int codeBegin = message.indexOf(":", codeIndex);
                        if (codeBegin  == -1) {
                            codeBegin = message.indexOf(" ", codeIndex);
                        }
                        codeBegin++;
                        int codeEnd = message.indexOf(" ", codeBegin);
                        if (codeEnd != -1) {
                            Intent codeIntent = new Intent(CompanityConstants.SMS_CODE_BROADCAST);
                            codeIntent.putExtra("code", message.substring(codeBegin, codeEnd).trim());
                            LocalBroadcastManager.getInstance(context.getApplicationContext()).sendBroadcast(codeIntent);
                        }
                    }
                    break;
                case CommonStatusCodes.TIMEOUT:
                    Log.e("Sms Receiver", "timeout");
                    // Waiting for SMS timed out (5 minutes)
                    // Handle the error ...
                    break;
            }
        }
    }
}
