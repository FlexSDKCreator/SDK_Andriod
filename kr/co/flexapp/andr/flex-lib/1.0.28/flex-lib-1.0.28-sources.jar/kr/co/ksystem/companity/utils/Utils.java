package kr.co.ksystem.companity.utils;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;

import org.json.JSONException;
import org.json.JSONObject;

import kr.co.ksystem.companity.R;
import kr.co.ksystem.companity.consts.CommonConstants;
import kr.co.ksystem.companity.svc.consts.Const;
import kr.co.ksystem.companity.svc.utils.SharedPreferenceUtil;
import okhttp3.FormBody;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Utils {
	private static final AtomicInteger sNextGeneratedId = new AtomicInteger(1);
	public static  float defaulltDensityDIP=0;
	/**
	 * Generate a value suitable for use in {@link #setId(int)}. This value will
	 * not collide with ID values generated at build time by aapt for R.id.
	 * 
	 * @return a generated ID value
	 */
	public static int generateIdForView() {
		for (;;) {
			final int result = sNextGeneratedId.get();
			// aapt-generated IDs have the high byte nonzero; clamp to the range
			// under that.
			int newValue = result + 1;
			if (newValue > 0x00FFFFFF)
				newValue = 1; // Roll over to 1, not 0.
			if (sNextGeneratedId.compareAndSet(result, newValue)) {
				return result;
			}
		}
	}

	public static String getFileName(SharedPreferenceUtil pref, String pgmSeq) {
		return pref.getValue(Const.KEY_USERSEQ, "") + "_" + pgmSeq + "_"
				+ pref.getValue(Const.KEY_DSN, "");
	}

	public static String getFormattedNumberResult(String value,
			int decimalPointLength) {
		try {
			DecimalFormat format = new DecimalFormat(
					getFormat(decimalPointLength));
			format.setRoundingMode(RoundingMode.DOWN);
			value = value.replaceAll(",", "");
			String formattedValue = format.format(new BigDecimal(value));
			return formattedValue;
		} catch (Exception e) {
			// TODO: handle exception
			return "";
		}
	}

	private static String getFormat(int decimalPointLength) {
		StringBuilder format = new StringBuilder();
		format.append("#,##0");
		if (decimalPointLength != 0) {
			format.append(".");
		}
		for (int i = 0; i < decimalPointLength; i++) {
			format.append("0");
		}
		return format.toString();
	}

	private static String getReturnFormat(int decimalPointLength) {
		StringBuilder format = new StringBuilder();
		format.append("####");
		if (decimalPointLength != 0) {
			format.append(".");
		}
		for (int i = 0; i < decimalPointLength; i++) {
			format.append("#");
		}
		return format.toString();
	}

	public static boolean isNumeric(String str) {
		try {
			Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	public static boolean isYYYYMMDDText(String text) {
		SimpleDateFormat inputDateFormat = new SimpleDateFormat(
				"yyyy-MM-dd (E)", Locale.getDefault());
		inputDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyyMMdd",
				Locale.getDefault());
		try {
			outputDateFormat.format(inputDateFormat.parse(text));
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	public static boolean isYYYYMMText(String text) {
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM",
				Locale.getDefault());
		inputDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyyMM",
				Locale.getDefault());
		try {
			outputDateFormat.format(inputDateFormat.parse(text));
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	public static String getYYYYMMDDValue(String text) {
		SimpleDateFormat inputDateFormat = new SimpleDateFormat(
				"yyyy-MM-dd (E)", Locale.getDefault());
		inputDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyyMMdd",
				Locale.getDefault());
		try {
			String rawValue = outputDateFormat.format(inputDateFormat
					.parse(text));
			return rawValue;
		} catch (ParseException e) {
			return text;
		}
	}

	public static String getYYYYMMDDText(String value) {
		// if value is in yyyyMMdd format (value comes from dataSet) then change
		// to yyyy-MM-dd (E) for displaying
		// else show as it is
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyyMMdd",
				Locale.getDefault());
		inputDateFormat.setLenient(false);
		try {
			// 17.06.15 dpjang - not used day of week removed (E)
			SimpleDateFormat outputDateFormat = new SimpleDateFormat(
					"yyyy-MM-dd", Locale.getDefault());
			return outputDateFormat.format(inputDateFormat.parse(value));
		} catch (ParseException e) {
			return value;
		}
	}

	public static String getYYYYMMValue(String text) {
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM",
				Locale.getDefault());
		inputDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyyMM",
				Locale.getDefault());
		try {
			String rawValue = outputDateFormat.format(inputDateFormat
					.parse(text));
			return rawValue;
		} catch (ParseException e) {
			return text;
		}
	}

	public static String getYYYYMMText(String value) {
		// if value is in yyyyMM format (value comes from dataSet) then change
		// to yyyy-MM (E) for displaying
		// else show as it is
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyyMM",
				Locale.getDefault());
		inputDateFormat.setLenient(false);
		try {
			SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM",
					Locale.getDefault());
			return outputDateFormat.format(inputDateFormat.parse(value));
		} catch (ParseException e) {
			return value;
		}
	}

	// 18.07.24 dpjang add case hhmmss
	public static String getYYYYMMHHMMSSText(String value) {
		// if value is in yyyyMM format (value comes from dataSet) then change
		// to yyyy-MM (E) for displaying
		// else show as it is
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",
				Locale.getDefault());
		inputDateFormat.setLenient(false);
		try {
			SimpleDateFormat outputDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
					Locale.getDefault());
			return outputDateFormat.format(inputDateFormat.parse(value));
		} catch (ParseException e) {
			return value;
		}
	}

	/**
	 *
	 * @param value is numberValue
	 * @param decLength is decimal length
	 * @return rounded number with decLength and decimal zeroes are omitted
	 */
	public static String getReturnValueForNumber(String value, int decLength) {
		BigDecimal decimalValue = new BigDecimal(value).setScale(decLength, RoundingMode.HALF_UP);
		DecimalFormat format = new DecimalFormat(getReturnFormat(decLength));
		return format.format(decimalValue);
	}

	public static int getColor(Context context, int attributeId) {
		TypedValue a = new TypedValue();
		context.getTheme().resolveAttribute(attributeId, a, true);
		// windowBackground is a color
		return a.data;
	}

	public static int getDrawable(Context context, int attributeId) {
		// windowBackground is not a color, probably a drawable
		TypedValue a = new TypedValue();
		context.getTheme().resolveAttribute(attributeId, a, true);
		return a.resourceId;

	}

	public static Bitmap getCircularBitmap(Bitmap bitmap) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		// canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		canvas.drawCircle(bitmap.getWidth() / 2, bitmap.getHeight() / 2, Math.min(bitmap.getWidth(), bitmap.getHeight()) / 2, paint);
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);
		// bitmap.recycle();
		return output;
	}

	public static Bitmap getScaledBitmap(Bitmap originalImage, int size) {
		Bitmap background = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
		float originalWidth = originalImage.getWidth(), originalHeight = originalImage.getHeight();
		Canvas canvas = new Canvas(background);
		float scale;
		float xTranslation;
		float yTranslation;
		if (originalHeight > originalWidth) {
			scale = size / originalWidth;
			xTranslation = 0.0f;
			yTranslation = (size - originalHeight * scale) / 2.0f;
		} else {
			scale = size / originalHeight;
			yTranslation = 0.0f;
			xTranslation = (size - originalWidth * scale) / 2.0f;
		}

		Matrix transformation = new Matrix();
		transformation.postTranslate(xTranslation, yTranslation);
		transformation.preScale(scale, scale);
		Paint paint = new Paint();
		paint.setFilterBitmap(true);
		canvas.drawBitmap(originalImage, transformation, paint);
		return background;
	}

	public static void calculateTextSize(Context context) {
		Resources res = context.getResources();
		if (defaulltDensityDIP == 0) {
			defaulltDensityDIP = res.getConfiguration().densityDpi;
		}
		float fontsize = 1f;
		float densitySize = 1f;
		SharedPreferences sharedpreferences = context.getSharedPreferences(
				CommonConstants.MyPREFERENCES, Context.MODE_PRIVATE);
		String textDefVal = sharedpreferences
				.getString(
						CommonConstants.TEXT_SIZE,
						context.getResources().getString(
								R.string.setting_defaultTxtsize_value));
		if (sharedpreferences.getString(CommonConstants.TEXT_SIZE, textDefVal)
				.equalsIgnoreCase(res.getString(R.string.textsize_extrasmall))) {
			fontsize = .6f;
			densitySize = .65f;
		} else if (sharedpreferences.getString(CommonConstants.TEXT_SIZE,
				textDefVal).equalsIgnoreCase(
				res.getString(R.string.textsize_small))) {
			fontsize = .65f;
			densitySize = .7f;
		} else if (sharedpreferences.getString(CommonConstants.TEXT_SIZE,
				textDefVal).equalsIgnoreCase(
				res.getString(R.string.textsize_normal))) {
			fontsize = 0.7f;
			densitySize = 0.8f;
		} else if (sharedpreferences.getString(CommonConstants.TEXT_SIZE,
				textDefVal).equalsIgnoreCase(
				res.getString(R.string.textsize_big))) {
			fontsize = 0.87f;
			densitySize = 0.85f;

		} else if (sharedpreferences.getString(CommonConstants.TEXT_SIZE,
				textDefVal).equalsIgnoreCase(
				res.getString(R.string.textsize_extrabig))) {
			fontsize = 1f;
			densitySize = 1f;
		}
		DisplayMetrics metrics1 = res.getDisplayMetrics();
		android.content.res.Configuration config1 = res.getConfiguration();
		config1.densityDpi = (int) (densitySize * defaulltDensityDIP);
		config1.fontScale = fontsize * defaulltDensityDIP
				/ config1.densityDpi;
		res.updateConfiguration(config1, metrics1);

	}

	public static void setTheme(Context context) {
        //int theme = context.getSharedPreferences(CommonConstants.MyPREFERENCES, Context.MODE_PRIVATE).getInt(CommonConstants.COLOR_SET, 2);
		context.setTheme(R.style.GreenTheme);
    }

	public static boolean deleteTempFiles(File file) {
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			if (files != null) {
				for (File f : files) {
					if (f.isDirectory()) {
						deleteTempFiles(f);
					} else {
						f.delete();
					}
				}
			}
		}
		return file.delete();
	}

	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap
				.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);

		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);

		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		canvas.drawRoundRect(rectF, pixels, pixels, paint);

		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);

		return output;
	}

	public static  int getLayoutMargin(Context context) {
		SharedPreferences sharedpreferences = context.getSharedPreferences(CommonConstants.MyPREFERENCES, Context.MODE_PRIVATE);
		int viewWidth = sharedpreferences.getInt(CommonConstants.ENTIRE_VIEW_WIDTH, 0);
		int viewHeight =
				sharedpreferences.getInt(CommonConstants.ENTIRE_VIEW_HEIGHT, 0);
		return (int) (0.03 * Math.min(viewWidth, viewHeight));
	}

	public static  int getComponentMargin(Context context) {
		SharedPreferences sharedpreferences = context.getSharedPreferences(CommonConstants.MyPREFERENCES, Context.MODE_PRIVATE);
		int viewWidth = sharedpreferences.getInt(CommonConstants.ENTIRE_VIEW_WIDTH, 0);
		int viewHeight =
				sharedpreferences.getInt(CommonConstants.ENTIRE_VIEW_HEIGHT, 0);
		return (int) (0.02 * Math.min(viewWidth, viewHeight));
	}

	public static String readFromFile(String filename, Context context) {

		String ret = "";

		try {
			File internalCache = context.getFilesDir();
			File file = new File((internalCache + File.separator + "json" + File.separator + filename));
			if (file != null && file.exists()) {
				InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file));
				BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
				String receiveString = "";
				StringBuilder stringBuilder = new StringBuilder();

				while ( (receiveString = bufferedReader.readLine()) != null ) {
					stringBuilder.append(receiveString);
				}

				inputStreamReader.close();
				ret = stringBuilder.toString();
			} else {
				ret = null;
			}
		}
		catch (FileNotFoundException e) {
			Log.e("login activity", "File not found: " + e.toString());
		} catch (IOException e) {
			Log.e("login activity", "Can not read file: " + e.toString());
		}

		return ret;
	}

	public static void saveToFile(String value, String fileName, Context context) {
		File internalCache = context.getFilesDir();
		File folder = new File((internalCache + File.separator + "json" + File.separator));
		if (!folder.exists()) {
			folder.mkdirs();
		}
		File file = new File(folder, fileName);
		try {
			OutputStreamWriter streamWriter = new OutputStreamWriter(new FileOutputStream(file));
			try {
				streamWriter.write(value);
				streamWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static void deleteFile(String fileName, Context context) {
		File internalCache = context.getFilesDir();
		File folder = new File((internalCache + File.separator + "json" + File.separator));
		if (folder.exists()) {
			File file = new File(folder, fileName);
			if (file.exists()) {
				file.delete();
			}
		}
	}

	public static String getFlexLinkParams(Intent i) {
		String linkParam = null;
		if (i.hasExtra("actionJson")) {
			try {
				JSONObject actionJson = new JSONObject(i.getStringExtra("actionJson"));
				if (actionJson.has("linkParam")) {
					linkParam = actionJson.getString("linkParam");
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return linkParam;
	}

	public static OkHttpClient getClientWithCookies(final String cookieHeader) {
		return new OkHttpClient.Builder().addInterceptor(new Interceptor() {
			@Override
			public Response intercept(Chain chain) throws IOException {
				Request originalRequest = chain.request();
				Request requestWithCookies = originalRequest.newBuilder()
						.header("Cookie", cookieHeader)
						.build();
				return chain.proceed(requestWithCookies);
			}
		}).build();
	}

	public static void logout() {
		CookieManager cookieManager = CookieManager.getInstance();
		String cookieHeader = cookieManager.getCookie("https://flextudio.com");
		Map<String, String> cookiesMap = getCookiesMap(cookieHeader);
		String sessionID = cookiesMap.get("FlexApp-SessionID");
		if (sessionID != null) {
            cookieManager.removeAllCookies(new ValueCallback<Boolean>() {
                @Override
                public void onReceiveValue(Boolean aBoolean) {
                    cookieManager.flush();
                }
            });
            OkHttpClient client = getClientWithCookies(cookieHeader);
			RequestBody formBody = new FormBody.Builder()
					.add("sessionId", sessionID)
					.build();
			Request request = new Request.Builder()
					.url("https://app.flextudio.com/logout")
					.post(formBody)
					.build();
			new Thread(() -> {
				try (Response response = client.newCall(request).execute()) {
					if (!response.isSuccessful()) {
						Log.e("logout fail: ", response.toString());
					}
					System.out.println("Response body: " + response.body().string());
				} catch (IOException e) {
					Log.e("logout exception: ", e.getMessage());
				}
			}).start();
		}
	}

	private static Map<String, String> getCookiesMap(String cookieHeader) {
		Map<String, String> cookieMap = new HashMap<>();
		if (cookieHeader == null) return cookieMap;
		String[] pairs = cookieHeader.split(";");
		for (String pair : pairs) {
			String[] parts = pair.split("=", 2);
			String name = parts[0].trim();
			String value = parts.length > 1 ? parts[1] : "";
			cookieMap.put(name, value);
		}
		return cookieMap;
	}
}
