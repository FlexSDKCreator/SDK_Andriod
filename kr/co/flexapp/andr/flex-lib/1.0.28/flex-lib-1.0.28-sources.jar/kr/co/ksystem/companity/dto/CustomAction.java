package kr.co.ksystem.companity.dto;

import java.util.HashMap;
import java.util.Map;

public class CustomAction {
    private String action;
    private Map<String, Object> param = new HashMap<>();

    public CustomAction(String action) {
        this.action = action;
    }
    public String getAction() {
        return action;
    }

    public Map<String, Object> getParam() {
        return param;
    }

}
