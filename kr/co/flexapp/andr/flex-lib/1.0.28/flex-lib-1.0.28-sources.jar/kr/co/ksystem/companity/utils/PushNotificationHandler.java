package kr.co.ksystem.companity.utils;

import android.content.Context;

import com.google.firebase.messaging.RemoteMessage;

public interface PushNotificationHandler {
    boolean handleMessage(Context context, RemoteMessage remoteMessage);
    Class<?> getTargetActivity(RemoteMessage remoteMessage);

}
