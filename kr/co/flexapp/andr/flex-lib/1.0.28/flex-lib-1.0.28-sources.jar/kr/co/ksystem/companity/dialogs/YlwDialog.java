package kr.co.ksystem.companity.dialogs;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import kr.co.ksystem.companity.main.YlwLooperException;

public class YlwDialog implements ResultPasserInterface {
	private Context context;
	private int dialogResult;
	CommonYLWDialog dlg;
	private static Handler handler = new Handler() {
		@Override
		public void handleMessage(Message mesg) {
			throw new YlwLooperException();
		}
	};

	public YlwDialog(Context context) {
		this.context = context;
	}

	public int ShowDialog(String message, String title, String msgBoxType) {
		dlg = new CommonYLWDialog(context);
		dlg.setInterface(this);
		dlg.setMessageBoxType(msgBoxType);
		dlg.setMessage(message);
		dlg.setDialogTitle(title);
		dlg.showDialog(context);
		
		dlg.setDialogCancelable(false);
		try {
			Looper.loop();
		} catch (YlwLooperException e) {
		}
		return dialogResult;
	}

	public CommonYLWDialog getDlg() {
		return dlg;
	}

	@Override
	public void setResultValue(int resultValue) {
		this.dialogResult = resultValue;
		handler.sendMessage(handler.obtainMessage());
	}

}
