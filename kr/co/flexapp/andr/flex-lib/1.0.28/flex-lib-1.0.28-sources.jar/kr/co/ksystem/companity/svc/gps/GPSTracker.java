package kr.co.ksystem.companity.svc.gps;



import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;
import kr.co.ksystem.companity.R;

public class GPSTracker {

	String result = "";
	GPSResult mGpsResult;
	Context mC;

	int millis = 1;
	int distance = 1;

	Location location;

	boolean isNetworkEnabled = false;
	boolean isGPSEnabled = false;

	LocationManager locationManager;

	LocationListener myLocationListener;

	boolean isLocationChanged = false;



	public interface GPSResult {
		public void OnGPSReturnVal(double latitude, double longitude, boolean is, String errType);

	}

	public GPSTracker(Context context, GPSResult gpsResult) {
		// TODO Auto-generated constructor stub

		Log.i("testLog1", "GPSTracker()");

		mGpsResult = gpsResult;
		mC = context;
		locationManager = (LocationManager) mC
				.getSystemService(Context.LOCATION_SERVICE);
		myLocationListener = new MyLocationListener();

		// getGPSLocation();
		// locationManager.
	}

	public void getGPSLocation() {

		// 이전에 실행 시킨 항목들을 제거한다.
		locationManager.removeUpdates(myLocationListener);
		isGPSEnabled = locationManager.isProviderEnabled("gps");
		isNetworkEnabled = locationManager.isProviderEnabled("network");

		// 15.07.31 added Manoj Karki
		// #### START ####
		if (!isGPSEnabled && !isNetworkEnabled) {
			locationManager.removeUpdates(myLocationListener);
			mGpsResult.OnGPSReturnVal(0, 0, false, "noAuth");
			// notify user
			AlertDialog.Builder dialog = new AlertDialog.Builder(mC);
			dialog.setMessage(mC.getResources().getString(
					R.string.gps_network_not_enabled));
			dialog.setPositiveButton(
					mC.getResources()
							.getString(R.string.open_location_settings),
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(
								DialogInterface paramDialogInterface,
								int paramInt) {

							Intent myIntent = new Intent(
									Settings.ACTION_LOCATION_SOURCE_SETTINGS);
							mC.startActivity(myIntent);
						}
					});
			dialog.setNegativeButton(mC.getString(R.string.Cancel),
					new DialogInterface.OnClickListener() {

						@Override
						public void onClick(
								DialogInterface paramDialogInterface,
								int paramInt) {
//
						}
					});
			dialog.setCancelable(false);
			dialog.show();

		}

		if (!isNetworkAvailable(mC)) {
			Toast.makeText(mC, "Network not available", Toast.LENGTH_SHORT)
					.show();
			locationManager.removeUpdates(myLocationListener);
			mGpsResult.OnGPSReturnVal(0, 0, false, "offlineMsg");
//			mGpsResult.OnGPSReturnVal(0, 0, false);
			return;
		}
		// ####### END ######
		if (isGPSEnabled) {
			Log.i("testLog1", "GPSTracker() isGPSEnabled");

			locationManager.requestLocationUpdates("gps", millis, distance,
					myLocationListener);
//			if (locationManager != null) {
//
//				location = locationManager.getLastKnownLocation("gps");
//
//				Log.i("testLog1",
//						"GPSTracker() locationManager.getLastKnownLocation(gps)");

//			}
		}
		if (isNetworkEnabled) {
			Log.i("testLog1", "GPSTracker() isNetworkEnabled");
			locationManager.requestLocationUpdates("network", millis, distance,
					myLocationListener);

//			if (locationManager != null) {
//
//				location = locationManager.getLastKnownLocation("network");
//				Log.i("testLog1",
//						"GPSTracker() locationManager.getLastKnownLocation(gps)");
//			}
		}



		// 카운트 시작.. 이후 20초 동안 반응이 없으면 GPS 상태 확인 메세지 START

		// END

//		if (location != null) {
			Log.e("testLog1", "location != null");
			// result = location.getLatitude() + " " + location.getLongitude();

			// 15.07.31 Manoj Karki - added "true" value
//			mGpsResult.OnGPSReturnVal(location.getLatitude(),
//					location.getLongitude(), true);

//		}
		// else {
		// Toast.makeText(mC, "GPS정보를 업데이트 중 입니다.", Toast.LENGTH_SHORT).show();
		// }

//		 Log.i("testLog1", "GPSTracker() result : " + result);
	}

	private boolean isNetworkAvailable(Context appcontext) {
		ConnectivityManager connectivityManager = (ConnectivityManager) appcontext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

	// 위치 정보를 감지하는 리스너
	public class MyLocationListener implements LocationListener {

		// 위치 정보가 변경되었을 때 호출된다.
		@Override
		public void onLocationChanged(Location loc) {
			String text = loc.getLatitude() + " " + loc.getLongitude();

			Log.i("testLog1", "onLocationChanged() :" + text);

			// 위치추적 off 및 핸들러 취소.
			locationManager.removeUpdates(myLocationListener);

			// 위치 정보 보냄
			mGpsResult.OnGPSReturnVal(loc.getLatitude(), loc.getLongitude(),
					true,"");

			// locationManager.removeUpdates(myLocationListener);
		}

		// 위치 제공자가 변경되었을 때 호출된다.
		@Override
		public void onProviderDisabled(String provider) {
			Toast.makeText(mC.getApplicationContext(), "GPS 이용 불가",
					Toast.LENGTH_SHORT).show();
			mGpsResult.OnGPSReturnVal(0,0,false,"noGPSData");
		}

		// 위치 제공자가 활성화되었을 때 호출된다.
		@Override
		public void onProviderEnabled(String provider) {
//			Toast.makeText(mC.getApplicationContext(), "GPS 이용 가능",
//					Toast.LENGTH_SHORT).show();
			getGPSLocation();
		}

		// 위치 제공자의 상태가 변경되었을 때 호출된다.
		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {

		}
	}



}
