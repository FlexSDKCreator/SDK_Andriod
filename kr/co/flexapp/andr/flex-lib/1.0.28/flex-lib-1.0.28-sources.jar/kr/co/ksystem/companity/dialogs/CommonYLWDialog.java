package kr.co.ksystem.companity.dialogs;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import kr.co.ksystem.companity.R;

public class CommonYLWDialog {

	private Dialog commonYLWDialog;

	private TextView contentsText;
	private TextView titleText;
	private String message;
	private String msgBoxType;
	private int result;
	private String dialogTitle;
	private ResultPasserInterface resultInterface;

	public CommonYLWDialog(Context context) {
		commonYLWDialog = new Dialog(context, kr.co.ksystem.companity.R.style.FullDialogTheme);
		commonYLWDialog.setCanceledOnTouchOutside(false);
		commonYLWDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
	}

	public void showDialog(Context context) {
		LayoutInflater inflater = (LayoutInflater) ((Activity) context)
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		View view = null;
		Button positiveButton;
		Button negativeButton;

		if (msgBoxType.equals("MsgBoxTypeOK")) {
			view = inflater.inflate(kr.co.ksystem.companity.R.layout.common_msgbox_ok, null, false);
			contentsText = (TextView) view.findViewById(kr.co.ksystem.companity.R.id.dialogContents);
			addTitle(view);

			contentsText.setText(message);
			positiveButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.okBtn);
			positiveButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					if (resultInterface != null) {
						result = 1;
						resultInterface.setResultValue(result);
					}
					commonYLWDialog.dismiss();

				}
			});

		} else if (msgBoxType.equals("MsgBoxTypeYesNo")) {
			view = inflater.inflate(kr.co.ksystem.companity.R.layout.common_msgbox_yes_no, null, false);
			contentsText = (TextView) view.findViewById(kr.co.ksystem.companity.R.id.dialogContents);
			contentsText.setText(message);
			addTitle(view);
			negativeButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.noBtn);
			positiveButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.yesBtn);
			positiveButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 1;
                    commonYLWDialog.dismiss();
                    resultInterface.setResultValue(result);

				}
			});
			negativeButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 0;
                    commonYLWDialog.dismiss();
                    resultInterface.setResultValue(result);
				}
			});
		}else if (msgBoxType.equals("MsgBoxTypeConfirmCancel")) {
			view = inflater.inflate(kr.co.ksystem.companity.R.layout.common_msgbox_yes_no, null, false);
			contentsText = (TextView) view.findViewById(kr.co.ksystem.companity.R.id.dialogContents);
			contentsText.setText(message);
			addTitle(view);
			negativeButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.noBtn);
			positiveButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.yesBtn);
			negativeButton.setText(kr.co.ksystem.companity.R.string.cancel);
			positiveButton.setText(kr.co.ksystem.companity.R.string.confirm);
			positiveButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 1;
					commonYLWDialog.dismiss();
					resultInterface.setResultValue(result);

				}
			});
			negativeButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 0;
					commonYLWDialog.dismiss();
					resultInterface.setResultValue(result);
				}
			});
		} else if (msgBoxType.equals("MsgBoxTypeYesNoCancel")) {
			view = inflater.inflate(kr.co.ksystem.companity.R.layout.common_msg_yes_no_cancel, null, false);
			contentsText = (TextView) view.findViewById(kr.co.ksystem.companity.R.id.dialogContents);
			contentsText.setText(message);
			addTitle(view);
			Button neutralButton;
			positiveButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.yesBtn);
			negativeButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.noBtn);
			neutralButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.cancelBtn);
			positiveButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 1;
                    commonYLWDialog.dismiss();
                    resultInterface.setResultValue(result);

				}
			});
			negativeButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 0;
                    commonYLWDialog.dismiss();
                    resultInterface.setResultValue(result);
				}
			});

			neutralButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 2;
                    commonYLWDialog.dismiss();
                    resultInterface.setResultValue(result);
				}
			});
		} else {
			view = inflater.inflate(kr.co.ksystem.companity.R.layout.common_msgbox_ok_cancel, null, false);
			contentsText = (TextView) view.findViewById(kr.co.ksystem.companity.R.id.dialogContents);
			contentsText.setText(message);
			addTitle(view);
			positiveButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.okBtn);
			negativeButton = (Button) view.findViewById(kr.co.ksystem.companity.R.id.cancelBtn);
			positiveButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 1;
                    commonYLWDialog.dismiss();
                    resultInterface.setResultValue(result);

				}
			});

			negativeButton.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					result = 2;
                    commonYLWDialog.dismiss();
                    resultInterface.setResultValue(result);
				}
			});
		}
		contentsText.setMovementMethod(new ScrollingMovementMethod());

		commonYLWDialog.setContentView(view);
		commonYLWDialog.show();

	}

	private void addTitle(View view) {
		titleText = (TextView) view.findViewById(kr.co.ksystem.companity.R.id.dialogTitle);
		if (dialogTitle != null && !dialogTitle.isEmpty())
			titleText.setText(dialogTitle);
		else
			titleText.setVisibility(View.INVISIBLE);
	}

	public void setMessageBoxType(String type) {
		this.msgBoxType = type;
	}

	public void setMessage(String msg) {
		this.message = msg;
	}

	public void setInterface(ResultPasserInterface inter) {
		this.resultInterface = inter;
	}

	public void setDialogTitle(String title) {
		this.dialogTitle = title;
	}

	public void setDialogCancelable(boolean isCancelable) {
		commonYLWDialog.setCancelable(isCancelable);
	}

	public Dialog getCommonYLWDialog() {
		return commonYLWDialog;
	}
}
