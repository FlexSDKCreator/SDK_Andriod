package kr.co.ksystem.companity;

import android.app.NotificationChannel;
import android.os.Build;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import androidx.core.app.NotificationManagerCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import kr.co.ksystem.companity.consts.CompanityConstants;
import kr.co.ksystem.companity.utils.PushNotificationConfig;
import kr.co.ksystem.companity.utils.PushNotificationHandler;

/**
 * Created by Subhaye on 22-Nov-17.
 */

public class YlwFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManagerCompat.IMPORTANCE_MAX;
            NotificationChannel mChannel = new NotificationChannel(CompanityConstants.NOTI_CHANNEL_ID, CompanityConstants.NOTI_CHANNEL_ID, importance);
            mChannel.enableLights(true);
            mChannel.enableVibration(true);
            //NotificationManager notifyMgr = context.getSystemService(NotificationManager.class);
            NotificationManagerCompat notifyMgr =  NotificationManagerCompat.from(this);
            notifyMgr.createNotificationChannel(mChannel);
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        PushNotificationHandler pushNotificationHandler = PushNotificationConfig.getPushNotificationHandler();
        if (pushNotificationHandler == null) {
            CompanityUtils.notification(this, remoteMessage, null);
        } else if (!pushNotificationHandler.handleMessage(this, remoteMessage)){
            Class<?> intentClass = pushNotificationHandler.getTargetActivity(remoteMessage);
            CompanityUtils.notification(this, remoteMessage, intentClass);
        }
    }

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        Log.e("token", "refresh " + String.valueOf(token));
    }
}
