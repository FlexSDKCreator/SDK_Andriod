package kr.co.ksystem.companity.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.CountDownTimer;
import android.util.Log;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class BluetoothHelper {
    private Activity activity;
    private BluetoothResults bluetoothResults;
    private String interfaceId;
    private String searchCallbackFn;
    private String connectCallbackFn;

    private String disconnectCallbackFn;
    private String receiveMessageFn;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner bluetoothLeScanner;
    private BluetoothDevice bluetoothDevice;
    private BluetoothSocket bluetoothSocket;
    private String Self_UUID = "00001101-0000-1000-8000-00805f9b34fb";//
    public static String CLIENT_CHARACTERISTIC_CONFIG = "00002902-0000-1000-8000-00805f9b34fb";// 00002902-0000-1000-8000-00805f9b34fb
    private OutputStream outputStream;

    private InputStream inputStream;

    private boolean isListening = false;
    private BluetoothGatt bluetoothGatt;
    private BluetoothGattCharacteristic writeCharacteristic;
    private BluetoothGattCharacteristic readCharacteristic;

    private HashMap<String, String> discovery = new HashMap<>();
    private HashMap<String, String> scanLE = new HashMap<>();
    private Integer scanLeError = null;
    private boolean discoverySuccess;
    private CountDownTimer leOnlyTimer;
    private int connectionStatus = -1;
    private String connectedDeviceName = null;

    private final BroadcastReceiver btDiscoveryReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                String deviceName = device.getName();
                String deviceAddress = device.getAddress();
                int btType = device.getType();
                if (btType == BluetoothDevice.DEVICE_TYPE_CLASSIC && !discovery.containsKey(deviceAddress)) {
                    discovery.put(deviceAddress, deviceName);
                }
                /*if (Objects.equals(deviceName,"HC-05")) {//"BT05"
                    ParcelUuid[] parcelUuid = device.getUuids();
                    btdeviceAddress = deviceAddress;
                }*/
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                Log.e("ACTION_DISCOVERY_FINISHED", "stop???0");
                stopBluetoothDiscovery();
            }
        }
    };

    /*private final BroadcastReceiver pairingRequestReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothDevice.ACTION_PAIRING_REQUEST.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
     ma           int pairingVariant = intent.getIntExtra(BluetoothDevice.EXTRA_PAIRING_VARIANT, BluetoothDevice.ERROR);
                if (pairingVariant == BluetoothDevice.PAIRING_VARIANT_PIN) {
                     //device.setPin("1234".getBytes());
                     //device.setPairingConfirmation(true);
                }
            }
        }
    };*/

    private final ScanCallback leScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            //Log.e("LE callbackType: ", callbackType + ": " + (ScanSettings.CALLBACK_TYPE_MATCH_LOST == callbackType ? "Lost" : "Check value"));
            collectConnectibleLe(result);
        }

        @SuppressLint("MissingPermission")
        private void collectConnectibleLe(ScanResult result) {
            if (result.isConnectable()) {
                BluetoothDevice device = result.getDevice();
                String deviceName = device.getName();
                String deviceAddress = device.getAddress();
                int btType = device.getType();
                if ((btType == BluetoothDevice.DEVICE_TYPE_DUAL || btType == BluetoothDevice.DEVICE_TYPE_LE) && !scanLE.containsKey(deviceAddress)) {
                    scanLE.put(deviceAddress, deviceName);
                }
            }
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            super.onBatchScanResults(results);
            for (ScanResult result : results) {
                collectConnectibleLe(result);
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            // Handle scan failure
            scanLeError = errorCode;
            Log.e("ScanLE fail", "errorCode: "+errorCode);
            if (!discoverySuccess) {
                stopBluetoothDiscovery();
            }
        }
    };

    private final BluetoothGattCallback bluetoothGattCallback = new BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    connectedDeviceName = bluetoothDevice.getName();
                    bluetoothGatt.discoverServices();
                    connectionStatus = 2;
                    if (bluetoothResults != null) {
                        bluetoothResults.onResult(interfaceId, connectCallbackFn, null);
                    }
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    connectionStatus = -1;
                    bluetoothGatt = null;
                    writeCharacteristic = null;
                    readCharacteristic = null;
                    bluetoothResults.onResult(interfaceId, disconnectCallbackFn, null);
                }
            } else {
                bluetoothGatt.close();
                bluetoothGatt = null;
                if (bluetoothResults != null) {
                    bluetoothResults.onResult(interfaceId, connectCallbackFn, "Failed to connect to the GATT server, status: " + status);
                }
            }
        }
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            //super.onServicesDiscovered(gatt, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                for (BluetoothGattService service : gatt.getServices()) {
                    for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
                        if (isWritableCharacteristic(characteristic)) {
                            writeCharacteristic = characteristic;
                        }
                        if (isReadableCharacteristic(characteristic)) {
                            readCharacteristic = characteristic;
                            setCharacteristicNotification(readCharacteristic, true);
                        }
                    }
                }
            }
        }

        @Override
        public void onCharacteristicChanged(@NonNull BluetoothGatt gatt, @NonNull BluetoothGattCharacteristic characteristic, @NonNull byte[] value) {
            //super.onCharacteristicChanged(gatt, characteristic, value);
            byte[] data = characteristic.getValue();
            String dataString = new String(data);
            if (bluetoothResults != null && receiveMessageFn != null) {
                bluetoothResults.onMessage(interfaceId, receiveMessageFn, dataString, characteristic.getUuid().toString());
            }
        }
    };
    private ScheduledExecutorService scheduler;
    public BluetoothHelper(Activity activity, BluetoothResults bluetoothResults, String interfaceId) {
        this.activity = activity;
        this.bluetoothResults = bluetoothResults;
        this.interfaceId = interfaceId;
        BluetoothManager bluetoothManager = activity.getSystemService(BluetoothManager.class);
        bluetoothAdapter = bluetoothManager.getAdapter();
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }

    @SuppressLint("MissingPermission")
    private void startBluetoothDiscovery(Activity activity) {
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        this.activity.registerReceiver(btDiscoveryReceiver, filter);
        filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        this.activity.registerReceiver(btDiscoveryReceiver, filter);
        if (bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
        bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
        discoverySuccess = bluetoothAdapter.startDiscovery();
        bluetoothLeScanner.startScan(leScanCallback);
        if (!discoverySuccess) {
            startTimer();
        }
    }
    private void startTimer() {
        if (leOnlyTimer == null) {
            leOnlyTimer = new CountDownTimer(5000, 5000) {

                @Override
                public void onTick(long l) {
                }

                @Override
                public void onFinish() {
                    leOnlyTimer = null;
                    stopBluetoothDiscovery();
                }
            }.start();
        } else {
            leOnlyTimer.cancel();
            leOnlyTimer.start();
        }
    }

    private boolean isWritableCharacteristic(BluetoothGattCharacteristic characteristic) {
        return (characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_WRITE) > 0;
    }

    private boolean isReadableCharacteristic(BluetoothGattCharacteristic characteristic) {
        return (characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) > 0;
    }

    @SuppressLint("MissingPermission")
    private void setCharacteristicNotification(BluetoothGattCharacteristic characteristic, boolean enabled) {
        bluetoothGatt.setCharacteristicNotification(characteristic, enabled);
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG));
        if (descriptor!=null) {
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            bluetoothGatt.writeDescriptor(descriptor);
        }
    }

    public void bluetoothSearch(String searchCallbackFn) {
        this.searchCallbackFn = searchCallbackFn;
        startBluetoothDiscovery(activity);
    }

    @SuppressLint("MissingPermission")
    public void connect(String btdeviceAddress, String connectCallbackFn, String receiveMessageFn) {
        if (connectionStatus != -1) {
            bluetoothResults.onResult(interfaceId, connectCallbackFn, "Already connected to "+ connectedDeviceName);
            return;
        }
        this.receiveMessageFn = receiveMessageFn;
        try {
            bluetoothDevice = bluetoothAdapter.getRemoteDevice(btdeviceAddress);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            bluetoothResults.onResult(interfaceId, connectCallbackFn, e.getMessage());
            return;
        }
        int deviceType = bluetoothDevice.getType();
        if (deviceType == BluetoothDevice.DEVICE_TYPE_LE ||deviceType == BluetoothDevice.DEVICE_TYPE_DUAL) {
            // Handle LE devices
            this.connectCallbackFn = connectCallbackFn;
            bluetoothGatt = bluetoothDevice.connectGatt(activity, false, bluetoothGattCallback);
        } else if (deviceType == BluetoothDevice.DEVICE_TYPE_CLASSIC) {
            new Thread(new Runnable() {
                @SuppressLint("MissingPermission")
                @Override
                public void run() {
                    try {
                        bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(UUID.fromString(Self_UUID));
                        bluetoothSocket.connect();
                        outputStream = bluetoothSocket.getOutputStream();
                        inputStream = bluetoothSocket.getInputStream();
                        connectionStatus = 1;
                        connectedDeviceName = bluetoothDevice.getName();
                        startListening();
                        if (bluetoothResults != null) {
                            bluetoothResults.onResult(interfaceId, connectCallbackFn, null);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        if (bluetoothResults != null) {
                            bluetoothResults.onResult(interfaceId, connectCallbackFn, e.getMessage());
                        }
                    }
                    //activity.unregisterReceiver(pairingRequestReceiver);
                }
            }).start();
        } else {
            bluetoothResults.onResult(interfaceId, connectCallbackFn, "device type not recognized");
        }
    }

    @SuppressLint("MissingPermission")
    public void send(String data, String sendCallbackFn) {
        if (connectionStatus == -1) {
            if (bluetoothResults != null) {
                bluetoothResults.onResult(interfaceId, sendCallbackFn, "connection hasn't been made");
            }
        } else if (connectionStatus == 1) {
            if (outputStream != null) {
                try {
                    outputStream.write(data.getBytes());
                    bluetoothResults.onResult(interfaceId, sendCallbackFn, null);
                } catch (IOException e) {
                    e.printStackTrace();
                    bluetoothResults.onResult(interfaceId, sendCallbackFn, e.getMessage());
                }
            } else {
                bluetoothResults.onResult(interfaceId, sendCallbackFn, "no outputStream");
            }
        }  else if (connectionStatus == 2) {
            if (writeCharacteristic != null) {
                writeCharacteristic.setValue(data.getBytes());
                if (bluetoothGatt.writeCharacteristic(writeCharacteristic)) {
                    bluetoothResults.onResult(interfaceId, sendCallbackFn, null);
                } else {
                    bluetoothResults.onResult(interfaceId, sendCallbackFn, "failed");
                }
            } else {
                bluetoothResults.onResult(interfaceId, sendCallbackFn, "no outputStream");
            }
        } else {
            bluetoothResults.onResult(interfaceId, sendCallbackFn, "invalid connection status");
        }
    }

    @SuppressLint("MissingPermission")
    public void disconnect(String disconnectCallbackFn) {
        this.disconnectCallbackFn = disconnectCallbackFn;
        //stopBluetoothDiscovery();
        if (bluetoothGatt != null) {
            bluetoothGatt.disconnect();
        }
        if (bluetoothSocket != null) {
            try {
                isListening = false;
                bluetoothSocket.close();
                bluetoothSocket = null;
                outputStream = null;
                inputStream = null;
                bluetoothResults.onResult(interfaceId, disconnectCallbackFn, null);
            } catch (IOException e) {
                e.printStackTrace();
                bluetoothResults.onResult(interfaceId, disconnectCallbackFn, e.getMessage());
            }
        } else if (connectionStatus == -1) {
            bluetoothResults.onResult(interfaceId, disconnectCallbackFn, null);
        }
        bluetoothDevice = null;
        connectionStatus = -1;
        connectedDeviceName = null;
    }

    public void startListening() {
        if (connectionStatus == 1 && inputStream != null) {
            isListening = true;
            listenForData();
        } else if (inputStream == null) {
            //bluetoothResults.onResult(interfaceId, disconnectCallbackFn, "no input stream");
        }
    }
    private void listenForData() {
        new Thread(() -> {
            byte[] buffer = new byte[1024];  // Buffer for storing incoming data
            int bytes;
            while (isListening) {
                try {
                    if (inputStream.available() > 0) {
                        // Read from the InputStream
                        bytes = inputStream.read(buffer);
                        if (bytes > 0) {
                            String data = new String(buffer, 0, bytes);
                            if (bluetoothResults != null && receiveMessageFn != null) {
                                bluetoothResults.onMessage(interfaceId, receiveMessageFn, data, null);
                            }
                        }
                    } else {
                        isListening = false;
                        scheduler.schedule(this::startListening, 1, TimeUnit.SECONDS);
                    }
                } catch (IOException e) {
                    isListening = false;
                    scheduler.schedule(this::startListening, 1, TimeUnit.SECONDS);
                }
            }
        }).start();
    }

    public void stopListening() {
        isListening = false;
    }
    @SuppressLint("MissingPermission")
    private void stopBluetoothDiscovery() {
        if (leOnlyTimer != null) {
            leOnlyTimer.cancel();
            leOnlyTimer = null;
        }
        if (bluetoothAdapter != null && bluetoothAdapter.isDiscovering()) {
            bluetoothAdapter.cancelDiscovery();
        }
        if (bluetoothLeScanner != null) {
            bluetoothLeScanner.stopScan(leScanCallback);
        }
        unregisterBluetoothReceiver(activity);
        if (bluetoothResults  != null) {
            String error = null;
            if (discovery.size() + scanLE.size() == 0 && (scanLeError != null || !discoverySuccess)) {
                error = (scanLeError != null ? "LE scan error: " + scanLeError + (discoverySuccess ? "" : ", Classic discovery failed"): "Classic discovery failed");
            }
            bluetoothResults.onSearchResult(interfaceId, searchCallbackFn, error, scanLE, discovery);
        }
        scanLE.clear();
        discovery.clear();
    }
    private void unregisterBluetoothReceiver(Context activity) {
        try {
            activity.unregisterReceiver(btDiscoveryReceiver);
        } catch (IllegalArgumentException e) {
            // Receiver was not registered
        }
    }

    public interface BluetoothResults {
        void onSearchResult(String interfaceId, String callbackFn, String error, HashMap<String, String> le, HashMap<String, String> classic);
        void onResult(String interfaceId, String callbackFn, String error);

        void onMessage(String interfaceId, String callbackFn, String data, String uuid);
    }

}
