package kr.co.ksystem.companity;

/**
 * Created by tn-acr-005 on 1/3/2018.
 */

public interface IOnBackPressed {
boolean onBackPressed();
}
