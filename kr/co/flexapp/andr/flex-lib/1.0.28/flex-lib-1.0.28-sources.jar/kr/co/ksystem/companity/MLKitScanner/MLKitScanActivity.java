package kr.co.ksystem.companity.MLKitScanner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.core.UseCaseGroup;
import androidx.camera.core.ViewPort;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.resolutionselector.ResolutionStrategy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.LifecycleCameraController;
import androidx.camera.view.PreviewView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.util.Rational;
import android.util.Size;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.Toast;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.ZoomSuggestionOptions;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import kr.co.ksystem.companity.R;


public class MLKitScanActivity extends AppCompatActivity{
    private static final String TAG = "MLKit Barcode";
    private static final int PERMISSION_CODE = 1001;
    private static final String CAMERA_PERMISSION = Manifest.permission.CAMERA;
    private PreviewView previewView;
    private CameraSelector cameraSelector;
    private ProcessCameraProvider cameraProvider;
    private Preview previewUseCase;
    private ImageAnalysis analysisUseCase;
    private Camera cameraX;
    private int lensFacing;

    private GraphicOverlay graphicOverlay;

    private boolean needUpdateGraphicOverlayImageSourceInfo;
    private boolean needUpdateGraphicOverlay;
    private Size size;

    private SeekBar seekBar;

    private float maxZoomRatio;
    private LifecycleCameraController cameraController;
    Vibrator vibrator = null;
    private boolean isMulti;
    private int height = 0;
    private int width = 0;
    private boolean isHeightPer = false;
    private boolean isWidthPer = false;
    int portWidth, portHeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mlkit_scanner);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        Intent intent = getIntent();
        isMulti = intent.getBooleanExtra("isMulti", false);
        height = intent.getIntExtra("height", 0);
        width = intent.getIntExtra("width", 0);
        isHeightPer = intent.getBooleanExtra("isHeightPer", false);
        isWidthPer = intent.getBooleanExtra("isWidthPer", false);
        boolean isUserFacing = intent.getBooleanExtra("isUserFacing", false);
        boolean closeBtnOnVideo = intent.getBooleanExtra("closeBtnOnVideo", false);
        boolean isQR =  intent.getBooleanExtra("isQR", false);
        previewView = findViewById(R.id.previewView);
        graphicOverlay = findViewById(R.id.graphic_overlay);
        lensFacing = isUserFacing ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK;
        seekBar = findViewById(R.id.zoomSeekBar);
        seekBar.setProgress(seekBar.getProgress());
        ConstraintLayout constraintLayout = findViewById(R.id.ScannerTouch);
        if (closeBtnOnVideo) {
            ConstraintSet constraintSet = new ConstraintSet();
            constraintSet.clone(constraintLayout);
            constraintSet.clear(R.id.scannerClose, ConstraintSet.TOP);
            constraintSet.clear(R.id.scannerClose, ConstraintSet.END);
            constraintSet.connect(R.id.scannerClose, ConstraintSet.END, R.id.previewView, ConstraintSet.END);
            constraintSet.connect(R.id.scannerClose, ConstraintSet.BOTTOM, R.id.previewView, ConstraintSet.TOP);
            constraintSet.setMargin(R.id.scannerClose, ConstraintSet.BOTTOM, 0);

            constraintSet.applyTo(constraintLayout);
        }
        View closeBtn = findViewById(R.id.scannerClose);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_CANCELED);
                cameraProvider.unbindAll();
                finish();
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.white));
        }
        seekBar.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    cameraX.getCameraControl().setLinearZoom(progress/100f);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        CameraCharacteristics cameraCharacteristics =
                getCameraCharacteristics(this, lensFacing);
        String[] entries;
        if (cameraCharacteristics != null) {
            StreamConfigurationMap map = cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size[] outputSizes = map.getOutputSizes(SurfaceTexture.class);
            Size iSize;
            float megaPixel;
            for (int i = outputSizes.length - 1; i >= 0; i--) {
                iSize = outputSizes[i];
                megaPixel = iSize.getHeight() * iSize.getWidth() / 1000000f;
                this.size = iSize;
                if (Math.ceil(megaPixel) >= 2) {
                    this.size = outputSizes[i];
                    break;
                }
            }
        }
        if (size == null) {
            size = new Size(960, 720);
        }
        constraintLayout.post(new Runnable() {
            @Override
            public void run() {
        int screenHeight = constraintLayout.getMeasuredHeight();
        int screenWidth = constraintLayout.getMeasuredWidth();
        int selectedWidth = size.getWidth();
        int selectedHeight = size.getHeight();
        /*if (isLandscape) {
            // If the device is in landscape, ensure width > height
            if (selectedHeight > selectedWidth) {
                int temp = selectedWidth;
                selectedWidth = selectedHeight;
                selectedHeight = temp;
            }
        } else {
            // If the device is in portrait, ensure height > width
            if (selectedWidth > selectedHeight) {
                int temp = selectedWidth;
                selectedWidth = selectedHeight;
                selectedHeight = temp;
            }
        }*/
        float density = getResources().getDisplayMetrics().density;
        int height = (int) (MLKitScanActivity.this.height * density);
        int width = (int) (MLKitScanActivity.this.width * density);
        if (isWidthPer) {
            if (width > 100) {
                width = screenWidth;
            } else {
                width = screenWidth * MLKitScanActivity.this.width / 100;
            }
        }
        if (isHeightPer) {
            if (height > 100) {
                height = screenHeight;
            } else {
                height = screenHeight * MLKitScanActivity.this.height / 100;
            }
        }
        height = height > 0 ? height :  screenHeight;
        width = width > 0 ? width : screenWidth;
        if (isQR) {
            height = Math.min(height, width);
            width = height;
        }
        adjustViewDimensionsToAspectRatio(previewView, width, height, selectedWidth, selectedHeight);
                previewView.post(new Runnable() {
                    @Override
                    public void run() {
                        if (closeBtn.getY() < 0) {
                            ConstraintSet constraintSet = new ConstraintSet();
                            constraintSet.clone(constraintLayout);
                            constraintSet.clear(R.id.scannerClose, ConstraintSet.BOTTOM);
                            constraintSet.connect(R.id.scannerClose, ConstraintSet.TOP, R.id.previewView, ConstraintSet.TOP);
                            constraintSet.setMargin(R.id.scannerClose, ConstraintSet.BOTTOM, 0);
                            constraintSet.applyTo(constraintLayout);
                        }
                    }
                });
        /*Rational aspectRatio = new Rational(size.getWidth(), size.getHeight());
        ViewPort viewPort = new ViewPort.Builder(aspectRatio, previewView.getDisplay().getRotation())
                .setScaleType(ViewPort.FILL_CENTER)
                .build();

// Create a UseCaseGroup.Builder and add the use cases
        UseCaseGroup.Builder useCaseGroupBuilder = new UseCaseGroup.Builder()
                .setViewPort(viewPort);*/
//
//        previewView.setPreferredImplementationMode(PreviewView.ImplementationMode.PERFORMANCE);
//        previewView.setPreferredFrameSize(new Size(4, 3));


        /////////alpha
        /*cameraController = new LifecycleCameraController(this);
        cameraController.bindToLifecycle((LifecycleOwner) this);
        cameraController.setCameraSelector(CameraSelector.DEFAULT_BACK_CAMERA);
        // Link it to the PreviewView
        previewView.setController(cameraController);
        //
        BarcodeScannerOptions options =
                new BarcodeScannerOptions.Builder()
                        //.setBarcodeFormats(Barcode.FORMAT_DATA_MATRIX)
                        .setZoomSuggestionOptions(
                                new ZoomSuggestionOptions.Builder(zoomCallback)
                                        .setMaxSupportedZoomRatio(cameraController.getZoomState().getValue().getMaxZoomRatio())
                                        .build()) // Optional
                        .build();

        BarcodeScanner barcodeScanner = BarcodeScanning.getClient();
        Executor executor = ContextCompat.getMainExecutor(this);
        cameraController.setImageAnalysisAnalyzer(executor,
                new MlKitAnalyzer(List.of(barcodeScanner), COORDINATE_SYSTEM_VIEW_REFERENCED,
                        executor, result -> {
                    // The value of result.getResult(barcodeScanner) can be used directly for drawing UI overlay.
                }));*/
            }
        });
    }

    public void adjustViewDimensionsToAspectRatio(View view, int maxWidth, int maxHeight, int aspectWidth, int aspectHeight) {
        // Calculate the optimal dimensions based on aspect ratio and maximum allowed dimensions
        float widthRatio = (float)maxWidth / aspectWidth;
        float heightRatio = (float)maxHeight / aspectHeight;
        float ratio = Math.min(widthRatio, heightRatio);
        int newWidth = Math.round(aspectWidth * ratio);
        int newHeight = Math.round(aspectHeight * ratio);

        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = newWidth;
        params.height = newHeight;
        portWidth = newWidth;
        portHeight = newHeight;
        view.setLayoutParams(params);

        ViewGroup.LayoutParams params2 = graphicOverlay.getLayoutParams();
        params2.width = newWidth;
        params2.height = newHeight;
        graphicOverlay.setLayoutParams(params2);
    }
    public static CameraCharacteristics getCameraCharacteristics(Context context, Integer lensFacing) {
        CameraManager cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        try {
            List<String> cameraList = Arrays.asList(cameraManager.getCameraIdList());
            for (String availableCameraId : cameraList) {
                CameraCharacteristics availableCameraCharacteristics = cameraManager.getCameraCharacteristics(availableCameraId);
                Integer availableLensFacing = availableCameraCharacteristics.get(CameraCharacteristics.LENS_FACING);
                if (availableLensFacing == null) {
                    continue;
                }
                if (availableLensFacing.equals(lensFacing)) {
                    return availableCameraCharacteristics;
                }
            }
        } catch (CameraAccessException e) {
            // Accessing camera ID info got error
        }
        return null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        previewView.post(new Runnable() {
            @Override
            public void run() {
                startCamera();
            }
        });
    }

    public void startCamera() {

        if(ContextCompat.checkSelfPermission(this, CAMERA_PERMISSION) == PackageManager.PERMISSION_GRANTED) {
            setupCamera();
        } else {
            getPermissions();
        }
    }

    private void getPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{CAMERA_PERMISSION}, PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, int[] grantResults) {
        for (int r : grantResults) {
            if (r == PackageManager.PERMISSION_DENIED) {
                setResult(RESULT_CANCELED);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("message", getString(R.string.camera_permission_info));
                finish();
                return;
            }
        }

        if (requestCode == PERMISSION_CODE) {
            setupCamera();
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void setupCamera() {
        final ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);
        cameraSelector = new CameraSelector.Builder().requireLensFacing(lensFacing).build();

        cameraProviderFuture.addListener(() -> {
            try {
                cameraProvider = cameraProviderFuture.get();
                //StreamConfigurationMap.getOutputSizes()
                //cameraProvider.getAvailableCameraInfos().get(1).hasFlashUnit();
                bindAllCameraUseCases();
            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "cameraProviderFuture.addListener Error", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindAllCameraUseCases() {
        if (cameraProvider != null) {
            cameraProvider.unbindAll();
            ResolutionSelector resolutionSelector = new ResolutionSelector.Builder()
                    .setResolutionStrategy(new ResolutionStrategy(size, ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
                    .build();
            bindPreviewUseCase(resolutionSelector);
            bindAnalysisUseCase(resolutionSelector);
        }
    }

    private void bindPreviewUseCase(ResolutionSelector resolutionSelector) {
        if (cameraProvider == null) {
            return;
        }

        if (previewUseCase != null) {
            cameraProvider.unbind(previewUseCase);
        }

        int rotation = getRotation();
        boolean isLandscape = rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270;
        Preview.Builder builder = new Preview.Builder();
        builder.setResolutionSelector(resolutionSelector);
        //builder.setTargetRotation(rotation);
        //builder.setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST);
        //builder.setTargetResolution(isLandscape ? size : new Size(size.getHeight(), size.getWidth()));// Approx. 2MP (1600x1200 = 1.92MP)
        //builder.setTargetResolution(size);
        //previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        previewUseCase = builder.build();
        previewUseCase.setSurfaceProvider(previewView.getSurfaceProvider());

        try {
            /*ImageCapture imageCaptureConfig = new ImageCapture.Builder()
                    .setTargetResolution(new Size(1600, 1200))  // Approx. 2MP (1600x1200 = 1.92MP)
                    .build();*/
            //cameraX = cameraProvider.bindToLifecycle(this, cameraSelector, previewUseCase);//, imageCaptureConfig);
            Rational customAspectRatio = new Rational(size.getWidth(), size.getHeight());

            ViewPort viewPort = new ViewPort.Builder(customAspectRatio, rotation)
                    .setScaleType(ViewPort.FILL_CENTER)
                    .build();
            UseCaseGroup useCaseGroup = new UseCaseGroup.Builder()
                    .addUseCase(previewUseCase)
                    .setViewPort(viewPort)
                    .build();

            cameraX = cameraProvider.bindToLifecycle(this, cameraSelector, useCaseGroup);
        } catch (Exception e) {
            Log.e(TAG, "Error when bind preview", e);
        }
    }
    BarcodeScanner barcodeScanner;
    private void bindAnalysisUseCase(ResolutionSelector resolutionSelector) {
        if (cameraProvider == null) {
            return;
        }
        maxZoomRatio = cameraX.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();
        if (analysisUseCase != null) {
            cameraProvider.unbind(analysisUseCase);
        }
        cameraX.getCameraControl().setLinearZoom(seekBar.getProgress()/100f);
        BarcodeScannerOptions options =
                new BarcodeScannerOptions.Builder()
                        //.setBarcodeFormats(Barcode.FORMAT_DATA_MATRIX)
                        .setZoomSuggestionOptions(
                                new ZoomSuggestionOptions.Builder(zoomCallback)
                                        .setMaxSupportedZoomRatio(maxZoomRatio)
                                        .build()) // Optional
                        .build();

        barcodeScanner = BarcodeScanning.getClient(options);


        int rotation = getRotation();
        boolean isLandscape = rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270;
        Executor cameraExecutor = Executors.newSingleThreadExecutor();
        ImageAnalysis.Builder builder = new ImageAnalysis.Builder();
        builder.setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST);
        //builder.setTargetRotation(rotation);
        //builder.setTargetResolution(isLandscape ? size : new Size(size.getHeight(), size.getWidth()));// Approx. 2MP (1600x1200 = 1.92MP)
        //builder.setTargetResolution(size);
        builder.setResolutionSelector(resolutionSelector);

        analysisUseCase = builder.build();
        needUpdateGraphicOverlayImageSourceInfo = true;
        analysisUseCase.setAnalyzer(cameraExecutor, this::analyze);


        try {
            Rational customAspectRatio = new Rational(size.getWidth(), size.getHeight());

            ViewPort viewPort = new ViewPort.Builder(customAspectRatio, rotation)
                    .setScaleType(ViewPort.FILL_CENTER)
                    .build();

            UseCaseGroup useCaseGroup = new UseCaseGroup.Builder()
                    .addUseCase(previewUseCase)
                    .addUseCase(analysisUseCase)
                    .setViewPort(viewPort)
                    .build();

            cameraX = cameraProvider.bindToLifecycle(this, cameraSelector, useCaseGroup);
            //cameraX = cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase);
        } catch (Exception e) {
            Log.e(TAG, "Error when bind analysis", e);
        }
    }

    protected int getRotation() throws NullPointerException {
       /* WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        int rotation = display.getRotation();*/
        return previewView.getDisplay().getRotation();
    }
    ZoomSuggestionOptions.ZoomCallback zoomCallback = new ZoomSuggestionOptions.ZoomCallback() {
        @Override
        public boolean setZoom(float zoomRatio) {
            if (cameraController != null) {
                cameraController.getCameraControl().setZoomRatio(zoomRatio);
                return true;
            }
            if (cameraX == null) {
                return false;
            }
            cameraX.getCameraControl().setZoomRatio(zoomRatio);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                seekBar.setProgress((int) (zoomRatio * 100/maxZoomRatio), true);
            } else {
                seekBar.setProgress((int) (zoomRatio * 100/maxZoomRatio));
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                VibrationEffect vibrationEffect1 = VibrationEffect.createOneShot(150, VibrationEffect.EFFECT_TICK);
                vibrator.cancel();
                vibrator.vibrate(vibrationEffect1);
            } else {
                vibrator.vibrate(150);
            }
            Log.e(TAG, "zoom: "+ zoomRatio);
            return true;
        }
    };

    @SuppressLint("UnsafeOptInUsageError")
    private void analyze(@NonNull ImageProxy imageProxy) {
        if (imageProxy.getImage() == null) return;

        if (needUpdateGraphicOverlayImageSourceInfo) {
            boolean isImageFlipped = lensFacing == CameraSelector.LENS_FACING_FRONT;
            int rotationDegrees = imageProxy.getImageInfo().getRotationDegrees();
            if (rotationDegrees == 0 || rotationDegrees == 180) {
                graphicOverlay.setImageSourceInfo(
                        imageProxy.getWidth(), imageProxy.getHeight(), isImageFlipped);
            } else {
                graphicOverlay.setImageSourceInfo(
                        imageProxy.getHeight(), imageProxy.getWidth(), isImageFlipped);
            }
            needUpdateGraphicOverlayImageSourceInfo = false;
        }
        int rotationDegrees = imageProxy.getImageInfo().getRotationDegrees();

        int imageWidth, imageHeight;
        if (rotationDegrees == 0 || rotationDegrees == 180) {
            imageWidth = imageProxy.getWidth();
            imageHeight = imageProxy.getHeight();
        } else {
            imageWidth = imageProxy.getHeight();
            imageHeight = imageProxy.getWidth();
        }
        float widthRatio = (float)  imageWidth/portWidth;
        float heightRatio = (float) imageHeight/portHeight;
        float ratio = Math.min(widthRatio, heightRatio);


        float left = (imageWidth - portWidth * ratio) / 2f;
        float top = (imageHeight - portHeight * ratio) / 2f;
        float right = left + portWidth * ratio;
        float bottom = top + portHeight * ratio;

        RectF viewPortRect = new RectF(left, top, right, bottom);
        Image image = imageProxy.getImage();

        InputImage inputImage = InputImage.fromMediaImage(
                image,
                imageProxy.getImageInfo().getRotationDegrees()
        );

        Log.e(TAG, "analyze: "+ imageProxy.getImageInfo().toString());
        barcodeScanner.process(inputImage)
                .addOnSuccessListener(barcodes -> {
                    String scanResult = null;
                    ArrayList<Barcode> barcodeGraphicArr = new ArrayList<>();
                    int resultSize = barcodes.size();
                    if (resultSize > 0) {
                        Barcode barcode;
                        JSONArray list = new JSONArray();
                        for (int i = 0; i < resultSize; i++) {
                            barcode = barcodes.get(i);
                            barcodeGraphicArr.add(barcode);
                            if (viewPortRect.contains(new RectF(barcode.getBoundingBox())))
                                if (isMulti) {
                                    list.put(barcode.getRawValue());
                                } else {
                                    barcodeGraphicArr.add(barcode);
                                    scanResult = barcode.getRawValue();
                                    break;
                                }
                        }
                        if (list.length() > 0) {
                            scanResult = list.toString();
                        }
                    }
                    if (scanResult != null) {
                        Bitmap bitmap = BitmapUtils.getBitmap(imageProxy);
                        needUpdateGraphicOverlay = true;
                        cameraProvider.unbind(analysisUseCase);
                        cameraProvider.unbind(previewUseCase);
                        barcodeScanner.close();
                        graphicOverlay.clear();
                        graphicOverlay.add(new CameraImageGraphic(graphicOverlay, bitmap));
                        for (int i = 0; i < barcodeGraphicArr.size(); i++) {
                            graphicOverlay.add(new BarcodeGraphic(graphicOverlay, barcodeGraphicArr.get(i)));
                        }
                        graphicOverlay.postInvalidate();
                        final VibrationEffect vibrationEffect1;

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            vibrationEffect1 = VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE);
                            vibrator.cancel();
                            vibrator.vibrate(vibrationEffect1);
                        } else {
                            vibrator.vibrate(250);
                        }

                        String finalScanResult = scanResult;
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Intent resultIntent = new Intent();
                                resultIntent.putExtra("rawvalue", finalScanResult);
                                setResult(RESULT_OK, resultIntent);
                                finish();
                            }
                        }, 400);

                    } else if (needUpdateGraphicOverlay) {
                        graphicOverlay.clear();
                        needUpdateGraphicOverlay = false;
                        graphicOverlay.postInvalidate();
                    }
                })
                .addOnFailureListener(e -> Log.e(TAG, "Barcode process failure", e))
                .addOnCompleteListener(task -> imageProxy.close());
    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        cameraProvider.unbindAll();
        finish();
    }

    private void onSuccessListener(List<Barcode> barcodes) {
        int resultSize = barcodes.size();
        if (resultSize > 0) {
            //Toast.makeText(this, barcodes.get(0).getDisplayValue(), Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "success: "+ barcodes.get(0).getDisplayValue());
            //barcodeScanner.close();

            needUpdateGraphicOverlay = true;
            //cameraProvider.unbind(analysisUseCase);
            //cameraProvider.unbind(previewUseCase);
            graphicOverlay.clear();
            for (int i = 0; i<resultSize; i++) {
                graphicOverlay.add(new BarcodeGraphic(graphicOverlay, barcodes.get(i)));
            }

            graphicOverlay.postInvalidate();

            try {
                //cameraX = cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase);
//                cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase);
//                cameraProvider.bindToLifecycle(this, cameraSelector, previewUseCase);
            } catch (Exception e) {
                Log.e(TAG, "Error when bind analysis", e);
            }
        } else if (needUpdateGraphicOverlay) {
            graphicOverlay.clear();
            needUpdateGraphicOverlay = false;
            graphicOverlay.postInvalidate();
        }
    }
}