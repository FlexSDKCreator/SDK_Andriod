package kr.co.ksystem.companity.utils.automaticlogout;


import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.IBinder;

import kr.co.ksystem.companity.consts.CommonConstants;

public class TimeoutService extends Service {
	private BroadcastReceiver mIntentReceiver;
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		mIntentReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();
				
				if ( action.equals(CommonConstants.TIMEOUT) ) {
					timeout(context);
				}
			}
		};
		
		IntentFilter filter = new IntentFilter();
		filter.addAction(CommonConstants.TIMEOUT);
		registerReceiver(mIntentReceiver, filter);
		return super.onStartCommand(intent, flags, startId);
	}

	private void timeout(Context context) {
		CommonConstants.relock = true;
		
		NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		nm.cancelAll();
		
		stopSelf();
	}
	
	@Override
	public void onDestroy() {
		if(!CommonConstants.lockcancel) {
			CommonConstants.relock = true;
		}
		try {
			unregisterReceiver(mIntentReceiver);
		} catch (IllegalArgumentException e) {
			// receiver already unregistered
		}
		super.onDestroy();
	}

	public class TimeoutBinder extends Binder {
		public TimeoutService getService() {
			return TimeoutService.this;
		}
	}
	
	private final IBinder mBinder = new TimeoutBinder();
	
	@Override
	public IBinder onBind(Intent intent) {
		return mBinder;
	}
	
}