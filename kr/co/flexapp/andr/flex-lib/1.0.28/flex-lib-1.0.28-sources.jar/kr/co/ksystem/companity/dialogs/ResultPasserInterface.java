package kr.co.ksystem.companity.dialogs;

public interface ResultPasserInterface {
	void setResultValue(int resultValue);

}
