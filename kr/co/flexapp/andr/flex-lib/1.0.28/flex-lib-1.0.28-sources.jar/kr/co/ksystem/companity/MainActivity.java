package kr.co.ksystem.companity;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.nfc.NfcAdapter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.ValueCallback;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import kr.co.ksystem.companity.consts.CompanityConstants;
import kr.co.ksystem.companity.dialogs.CommonYLWDialog;
import kr.co.ksystem.companity.org.glideloader.YlwPhotoDto;
import kr.co.ksystem.companity.utils.Utils;
import kr.co.ksystem.companity.svc.base.BaseFormClass;
import kr.co.ksystem.companity.svc.base.BaseUserValue;
import kr.co.ksystem.companity.svc.consts.Const;
import kr.co.ksystem.companity.svc.utils.SharedPreferenceUtil;
import kr.co.ksystem.companity.svc.webservice.AwsApiTask;

public class MainActivity extends AppCompatActivity implements FlexFragment.WebViewBack {


    private BaseFormClass _base;
    private ConstraintSet menuConstrainset;

    private int previousMenuIndex = 0;
    private static int timeOut = 20;
    boolean close_flag = false;
    private CustomFrag flexFragment;
    private OnBackPressedCallback backPressedCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent i = getIntent();
        String linkParam = Utils.getFlexLinkParams(i);

        Utils.calculateTextSize(this);
        Utils.setTheme(this);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        setContentView(R.layout.companity_news_feed);
        //int emp_menu_Width = (int) (getResources().getDimension(R.dimen.emp_menu_btnwidth));
        int entireMinSize = Math.min(
                getResources().getDisplayMetrics().heightPixels, getResources()
                        .getDisplayMetrics().widthPixels);
        final FrameLayout formHolder = (FrameLayout) findViewById(R.id.fragment_news_feed);
        _base = getLoginBaseForm();
        /*NewsFeedFragment newsFeedFragment = new NewsFeedFragment();
        newsFeedFragment.setDrawerInterface(menuBtnClicked);
        getSupportFragmentManager().beginTransaction().add(R.id.fragment_news_feed, newsFeedFragment, "newsfeed").commit();*/

        /*if (BaseUserValue.SESSION_ID.isEmpty()) {
            // set BaseUserValue.SESSION_ID on activity restart after permission change
            String sessionInfo = Utils.readFromFile("sessionInfo", MainActivity.this);
            if (sessionInfo != null) {
                try {
                    JSONObject sessionObject = new JSONObject(sessionInfo);
                    BaseUserValue.SESSION_ID = sessionObject.getString("sessionID");
                    startAppPage();
                } catch (JSONException e) {
                    e.printStackTrace();
                    startActivity(new Intent(MainActivity.this, Login.class));
                    finish();
                }
            } else {
                startActivity(new Intent(MainActivity.this, Login.class));
                finish();
            }
        } else {*/
            startAppPage(linkParam);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#ffffff"));
        }
        formHolder.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        backPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleBackPressed();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, backPressedCallback);
       // }
    }

    private void startAppPage(String linkParam) {
        flexFragment = new CustomFrag();
        Bundle bundle = new Bundle();
        if (linkParam != null) {
            bundle.putString("linkParam", linkParam);
        }
        flexFragment.setArguments(bundle);
        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(R.animator.activity_slide_up, R.animator.exit_from_bottom, R.animator.exit_from_bottom, R.animator.enter_from_bottom)
                .replace(R.id.fragment_news_feed, flexFragment).commit();
    }

    private BaseFormClass getLoginBaseForm() {
        Gson gson = new Gson();
        SharedPreferenceUtil pref = new SharedPreferenceUtil(this);
        String origin_base = pref.getValue(Const.BEGINNING_INFO, "");
        return gson.fromJson(origin_base, BaseFormClass.class);
    }

    public static Bitmap blurRenderScript(Context context, Bitmap smallBitmap, int radius) {
        try {
            smallBitmap = RGB565toARGB888(smallBitmap);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Bitmap bitmap = Bitmap.createBitmap(
                smallBitmap.getWidth(), smallBitmap.getHeight(),
                Bitmap.Config.ARGB_8888);
        RenderScript renderScript = RenderScript.create(context);

        Allocation blurInput = Allocation.createFromBitmap(renderScript, smallBitmap);
        Allocation blurOutput = Allocation.createFromBitmap(renderScript, bitmap);

        ScriptIntrinsicBlur blur = ScriptIntrinsicBlur.create(renderScript,
                Element.U8_4(renderScript));
        blur.setInput(blurInput);
        blur.setRadius(radius); // radius must be 0 < r <= 25
        blur.forEach(blurOutput);

        blurOutput.copyTo(bitmap);
        renderScript.destroy();

        return bitmap;

    }


    private static Bitmap RGB565toARGB888(Bitmap img) throws Exception {
        int numPixels = img.getWidth() * img.getHeight();
        int[] pixels = new int[numPixels];

        //Get JPEG pixels.  Each int is the color values for one pixel.
        img.getPixels(pixels, 0, img.getWidth(), 0, 0, img.getWidth(), img.getHeight());

        //Create a Bitmap of the appropriate format.
        Bitmap result = Bitmap.createBitmap(img.getWidth(), img.getHeight(), Bitmap.Config.ARGB_8888);

        //Set RGB pixels.
        result.setPixels(pixels, 0, result.getWidth(), 0, 0, result.getWidth(), result.getHeight());
        return result;
    }

    private void logout() {
        AwsApiTask awsApiTask = new AwsApiTask(new AwsApiTask.AwsApiResult() {
            @Override
            public void onAwsResult(String result) {
                if (result == null) {
                    Toast.makeText(MainActivity.this, "Unsuccessful", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        JSONObject resultJson = new JSONObject(result);
                        if (resultJson.has("error")) {
                            CommonYLWDialog dlg = new CommonYLWDialog(MainActivity.this);
                            dlg.setMessageBoxType("MsgBoxTypeOK");
                            dlg.setMessage(resultJson.get("error").toString());
                            dlg.showDialog(MainActivity.this);
                            dlg.setDialogCancelable(true);
                        } else {
                            clearSessionData();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        String sessionInfo = Utils.readFromFile("sessionInfo", MainActivity.this);
        if (sessionInfo != null) {
            try {
                JSONObject sessionObject = new JSONObject(sessionInfo);
                JSONObject requestObject = new JSONObject();
                requestObject.put("baseCompanyId", sessionObject.getString("baseCompanyID"));
                requestObject.put("baseUserId", sessionObject.getString("baseUserID"));
                requestObject.put("sessionId", sessionObject.getString("sessionID"));
                awsApiTask.execute("logOut", requestObject.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void clearSessionData() {
        SharedPreferenceUtil pref = new SharedPreferenceUtil(MainActivity.this);
        pref.remove(Const.DEVICE_TOKEN);
        pref.remove(CompanityConstants.SAVED_TOKEN);
        pref.remove(Const.USER_INFO_LASTDATETIME);

        Utils.deleteFile("sessionInfo", MainActivity.this);
        CookieManager cookieManager = CookieManager.getInstance();
        if (cookieManager.hasCookies()) {
            cookieManager.removeAllCookies(new ValueCallback<Boolean>() {
                @Override
                public void onReceiveValue(Boolean aBoolean) {
                    /*startActivity(new Intent(MainActivity.this, Login.class));
                    finish();*/
                    startAppPage(null);
                }
            });
        } else {
            /*startActivity(new Intent(MainActivity.this, Login.class));
            finish();*/
            startAppPage(null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void handleBackPressed() {
        Fragment orgFrag = getSupportFragmentManager().findFragmentById(R.id.fragment_news_feed);
        if (orgFrag instanceof FlexFragment) {

           ((FlexFragment) orgFrag).moveToBackStep();

        }else if (!close_flag) {
            exitCheck();
        } else {
            finish();
        }
    }

    @Override
    protected void onPause() {
        flushCookies();
        super.onPause();
    }

    @Override
    protected void onStop() {
        flushCookies();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        flushCookies();
        super.onDestroy();
    }

    private void flushCookies() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().flush();
        } else {
            CookieSyncManager.getInstance().sync();
        }
    }

    @Override
    public void onWebViewBackPressed() {
        if (!close_flag) {
            exitCheck();
        } else {
            finish();
        }
    }

    @Override
    public void onLoadScenarioFail() {
    }

    @Override
    public void onWebLogout() {
        logout();
    }

    @Override
    public void onWebNoSession() {
        clearSessionData();
    }

    private void exitCheck() {
        flushCookies();
        Toast.makeText(this, R.string.exit_toast,
                Toast.LENGTH_LONG).show();
        close_flag = true;
        m_close_handler.sendEmptyMessageDelayed(0, 2000);
        backPressedCallback.setEnabled(false);
    }

    Handler m_close_handler = new Handler() {
        public void handleMessage(Message msg) {
            close_flag = false;
            backPressedCallback.setEnabled(true);
        }
    };


    @Override
    protected void onNewIntent(@NotNull Intent intent) {
        super.onNewIntent(intent);
        String action = intent.getAction();
        if (flexFragment != null && (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_TECH_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_TAG_DISCOVERED.equals(action))) {
            flexFragment.onNewIntent(intent);
        }
    }
}


