package kr.co.ksystem.companity.main;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import kr.co.ksystem.companity.R;

public class InvitationActivity extends AppCompatActivity {
    private RecyclerView invitationRV;
    private InvitationAdapter invitationAdapter;
    private JSONArray invitations;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            invitations = new JSONArray(getIntent().getStringExtra("invites"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.empseq_login_background));
        }
        setContentView(R.layout.invite_login);
        ((TextView) findViewById(R.id.message)).setText(getIntent().getStringExtra("phoneNo") + getString(R.string.checkInvites));
        invitationRV = findViewById(R.id.invitationList);
        invitationRV.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        invitationAdapter = new InvitationAdapter();
        invitationRV.setAdapter(invitationAdapter);
        //invitationRV.addItemDecoration(new CenterAlignDecorator());
    }


    class InvitationAdapter extends RecyclerView.Adapter<InvitationAdapter.InviteDetailAdapter> {
        @NonNull
        @Override
        public InviteDetailAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new InviteDetailAdapter(LayoutInflater.from(parent.getContext()).inflate(R.layout.invitation_card, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull InviteDetailAdapter holder, int position) {
            try {
                JSONObject invitation = invitations.getJSONObject(position);
                holder.app.setText(invitation.getString(invitation.has("appName") ? "appName" : "fAppID"));
                holder.company.setText(invitation.getString("name"));
                if (invitation.has("fInvitedDate")) {
                    Date date = new Date(invitation.getLong("fInvitedDate"));
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd", Locale.US);
                    String formattedDate = sdf.format(date);
                    if (invitation.has("userName")) {
                        formattedDate += " - " + invitation.getString("userName");
                    }
                    holder.date.setText(formattedDate);
                } else {
                    holder.date.setText(null);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemCount() {
            return (invitations == null ? 0 : invitations.length());
        }

        class InviteDetailAdapter extends RecyclerView.ViewHolder {
            TextView company;
            TextView date;
            TextView app;

            public InviteDetailAdapter(View itemView) {
                super(itemView);
                company = itemView.findViewById(R.id.companyName);
                date = itemView.findViewById(R.id.date);
                app = itemView.findViewById(R.id.appLbl);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        v.setSelected(true);
                        Intent intent = new Intent();
                        try {
                            intent.putExtra("selectedInvite", invitations.getJSONObject(getAdapterPosition()).toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        setResult(Activity.RESULT_OK, intent);
                        finish();
                    }
                });
            }
        }
    }

    class CenterAlignDecorator extends RecyclerView.ItemDecoration {
        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            int widthSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            view.measure(widthSpec, heightSpec);
            int itemSize = view.getMeasuredWidth() + view.getPaddingStart() + view.getPaddingEnd();
            parent.measure(widthSpec, heightSpec);
            int padding = (parent.getMeasuredWidth() -itemSize) / 2;
            outRect.set(padding, 0, 0, 0);
        }
    }
}
