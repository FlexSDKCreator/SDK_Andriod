package kr.co.ksystem.companity.controls;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.target.Target;

import kr.co.ksystem.companity.GlideApp;
import kr.co.ksystem.companity.R;
import kr.co.ksystem.companity.utils.Utils;

public class LoadingViewGif extends androidx.appcompat.widget.AppCompatImageView {
    private Paint paint;

    public LoadingViewGif(Context context) {
        super(context);
        init();
    }

    public LoadingViewGif(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public LoadingViewGif(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Utils.getColor(getContext(), R.attr.theme_color));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float midPoint = ((float) getWidth()) / 2;
        canvas.drawCircle(midPoint, midPoint, midPoint, paint);
        super.onDraw(canvas);
    }

    public void removeBgColor() {
        paint.setColor(ContextCompat.getColor(getContext(), R.color.company_selected));
        invalidate();
    }

    public void animateView() {
        GlideApp.with(getContext())
                .asGif()
                .format(DecodeFormat.PREFER_ARGB_8888)
                .load(R.drawable.loading_anim)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .override(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)
                .into(this);
    }

    public void stopAnimation() {
        setImageDrawable(null);
    }

}
